export type GameMode =
  | 'arena'
  | 'campaign'
  | 'academy'
  | 'bestiary'
  | 'deck'
  | 'tournaments'
  | 'profile'
  | 'marketplace';

export type CardCategory = 'reading' | 'defense' | 'decision' | 'protocol';

export interface SignalCard {
  id: string;
  name: string;
  category: CardCategory;
  categoryName: string;
  description: string;
  principle: string;
  cryptoContext: string;
  tone: 'cyan' | 'amber' | 'violet' | 'green' | 'red';
  icon: string;
  bonus: string;
  unlockedLevel: number;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary';
  flavorQuote: string;
}

export interface MarketEntity {
  id: string;
  name: string;
  title: string;
  category: 'signals' | 'emotions' | 'noise' | 'risk' | 'web3';
  categoryLabel: string;
  image: string;
  threatLevel: number;
  cognitiveTrap: string;
  marketBehavior: string;
  counterMeasures: string[];
  recommendedCards: string[];
  quote: string;
  defeatedCount: number;
}

export type DecisionType = 'reduce_risk' | 'stay_out' | 'wait_confirmation' | 'aggressive_entry';

export interface DecisionOption {
  id: DecisionType;
  title: string;
  subtitle: string;
  rationale: string;
  processScore: number; // 0 to 100
  riskImpact: 'high_defense' | 'optimal' | 'cautious' | 'reckless';
  isCorrectProcess: boolean;
  explanation: string;
}

export interface ChartCandle {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  isFuture?: boolean;
}

export interface ScenarioTabContent {
  chartData: {
    symbol: string;
    timeframe: string;
    candles: ChartCandle[];
    levels: { price: number; label: string; type: 'support' | 'resistance' | 'invalidation' }[];
    notes: string[];
  };
  onChain: {
    whaleExchangeFlow: string;
    exchangeReserveChange: string;
    smartMoneyDivergence: string;
    gasSpike: string;
    notableTransfers: string[];
    riskScore: number;
  };
  orderBook: {
    bidAskRatio: string;
    fundingRate: string;
    openInterestTrend: string;
    liquidationWall: string;
    depthImbalance: string;
  };
  newsNarrative: {
    mainHeadline: string;
    sourceReliability: 'Высокая' | 'Сомнительная' | 'Слухи / Инфошум';
    sentiment: 'Экстремальная жадность' | 'Паника / FUD' | 'Умеренный';
    articles: { time: string; title: string; tag: string }[];
  };
  socialFunding: {
    fearGreedIndex: number; // 0-100
    socialVolumeSpike: string;
    longRatio: number; // e.g. 74%
    twitterHype: string;
  };
  positionHistory?: {
    entryPrice?: number;
    currentUnrealizedPnL?: string;
    timeInPosition?: string;
    initialPlan?: string;
    maxAllowedDrawdown?: string;
  };
}

export interface CryptoScenario {
  id: string;
  title: string;
  epoch: string;
  year: string;
  difficulty: 'Новичок' | 'Аналитик' | 'Профи' | 'Грандмастер';
  difficultyLevel: number;
  asset: string;
  situationType: 'before_entry' | 'in_position';
  situationTypeLabel: string;
  summary: string;
  keyQuestion: string;
  activeEntityId: string;
  activeProtocol: {
    id: string;
    title: string;
    rule: string;
  };
  equippedCards: string[];
  tabs: ScenarioTabContent;
  decisions: DecisionOption[];
  secondStep?: {
    prompt: string;
    type: 'invalidation' | 'evidence_select' | 'pause_duration';
    options: { id: string; label: string; isOptimal: boolean; note: string }[];
  };
  historicalFact: {
    whatHappened: string;
    actualPriceMove: string;
    date: string;
    verifiedSource: string;
  };
  learningTakeaway: string;
}

export interface AcademyLesson {
  id: string;
  treeId: string;
  treeName: string;
  treeIcon: string;
  level: number;
  title: string;
  category: 'basics' | 'structure' | 'onchain' | 'risk' | 'psychology' | 'institutional';
  summary: string;
  estimatedMinutes: number;
  isCompleted: boolean;
  xpReward: number;
  theorySections: {
    heading: string;
    body: string;
    bulletPoints?: string[];
    diagramNote?: string;
  }[];
  quiz: {
    question: string;
    options: { text: string; isCorrect: boolean; feedback: string }[];
  };
  linkedScenarioId: string;
}

export interface PlayerProfile {
  name: string;
  handle: string;
  level: number;
  currentXp: number;
  nextLevelXp: number;
  title: string;
  league: string;
  leagueRank: number;
  totalDecisions: number;
  averagePQS: number; // Process Quality Score 0-100
  disciplineStreak: number;
  crystals: number;
  arenaTokens: number;
  isPremium: boolean;
  theme: string;
  avatar: string;
  skills: {
    marketStructure: number;
    riskManagement: number;
    psychologyControl: number;
    onChainReading: number;
    disciplineProtocol: number;
    macroSynthesis: number;
  };
  cognitiveBiasesAudit: {
    name: string;
    trapRate: number; // percentage of times fell for it
    status: 'Контролируется' | 'Требует внимания' | 'Критическая уязвимость';
  }[];
}

export interface TournamentMatch {
  id: string;
  title: string;
  badge: string;
  endTime: string;
  participantsCount: number;
  scenarioId: string;
  topScore: number;
  playerRank?: number;
  playerScore?: number;
  rewards: { crystals: number; tokens: number; badgeTitle: string };
  isEntered: boolean;
}

export interface MarketItem {
  id: string;
  name: string;
  category: 'pro' | 'profile_theme' | 'card_skin' | 'campaign_pack' | 'avatar';
  price: number;
  currency: 'crystals' | 'tokens' | 'usd';
  priceUsd?: string;
  description: string;
  features: string[];
  imageIcon: string;
  isOwned?: boolean;
  rarity?: 'Common' | 'Rare' | 'Epic' | 'Legendary';
}
