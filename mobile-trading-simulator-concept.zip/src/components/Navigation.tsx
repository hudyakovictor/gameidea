import {
  Swords,
  Map,
  BookOpen,
  Layers,
  Skull,
  Trophy,
  UserCheck,
  ShoppingBag
} from 'lucide-react';
import { GameMode } from '../types/game';
import { soundManager } from '../utils/audio';

interface NavigationProps {
  currentMode: GameMode;
  onSelectMode: (mode: GameMode) => void;
}

export function Navigation({ currentMode, onSelectMode }: NavigationProps) {
  const modes: { id: GameMode; label: string; icon: React.ElementType; badge?: string }[] = [
    { id: 'arena', label: 'Арена', icon: Swords },
    { id: 'campaign', label: 'Кампания', icon: Map },
    { id: 'academy', label: 'Академия', icon: BookOpen, badge: 'Duolingo' },
    { id: 'deck', label: 'Колода', icon: Layers, badge: '40+' },
    { id: 'bestiary', label: 'Угрозы', icon: Skull },
    { id: 'tournaments', label: 'Турниры', icon: Trophy, badge: 'Live' },
    { id: 'profile', label: 'Профиль & Радар', icon: UserCheck },
    { id: 'marketplace', label: 'Маркет & GameFi', icon: ShoppingBag }
  ];

  const handleSelect = (mode: GameMode) => {
    soundManager.playCardClick();
    onSelectMode(mode);
  };

  return (
    <>
      {/* Desktop Sub-Nav Bar */}
      <nav aria-label="Основная навигация" className="sticky top-16 z-30 hidden border-b border-white/[0.08] bg-[#071322]/80 backdrop-blur-md lg:block">
        <div className="mx-auto flex max-w-[1520px] items-center justify-between px-6">
          <div className="flex items-center gap-1">
            {modes.map((m) => {
              const Icon = m.icon;
              const isActive = currentMode === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => handleSelect(m.id)}
                  className={`group relative flex items-center gap-2 px-4 py-3.5 text-xs font-bold transition-all ${
                    isActive
                      ? 'text-cyan-300'
                      : 'text-slate-400 hover:bg-white/[0.03] hover:text-slate-200'
                  }`}
                >
                  <Icon size={16} className={isActive ? 'text-cyan-400' : 'text-slate-500 group-hover:text-slate-300'} />
                  <span>{m.label}</span>
                  {m.badge && (
                    <span className={`rounded-full px-1.5 py-0.2 text-[9px] font-mono font-bold ${
                      m.badge === 'Live'
                        ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                        : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                    }`}>
                      {m.badge}
                    </span>
                  )}
                  {isActive && (
                    <div className="absolute inset-x-0 bottom-0 h-0.5 bg-gradient-to-r from-cyan-400 to-emerald-400 shadow-[0_0_10px_rgba(34,211,238,0.8)]" />
                  )}
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
            <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Сезон 01: Архив Паники</span>
          </div>
        </div>
      </nav>

      {/* Mobile Bottom Fixed Nav Bar */}
      <nav aria-label="Мобильная навигация" className="fixed inset-x-0 bottom-0 z-40 border-t border-cyan-500/20 bg-[#06101c]/95 backdrop-blur-xl lg:hidden">
        <div className="grid grid-cols-4 gap-1 p-1 sm:grid-cols-8">
          {modes.map((m) => {
            const Icon = m.icon;
            const isActive = currentMode === m.id;
            return (
              <button
                key={m.id}
                onClick={() => handleSelect(m.id)}
                className={`flex flex-col items-center justify-center py-2 px-1 rounded-lg transition-all ${
                  isActive
                    ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 shadow-[0_0_12px_rgba(34,211,238,0.2)]'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon size={18} className={isActive ? 'text-cyan-400' : 'text-slate-500'} />
                <span className="mt-1 text-[10px] font-bold tracking-tight truncate max-w-full">
                  {m.label.split(' ')[0]}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
