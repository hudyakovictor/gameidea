import {
  UserCheck,
  BrainCircuit,
  ShieldCheck,
  Scale,
  Award,
  Crown,
  History,
  TrendingUp
} from 'lucide-react';
import { PlayerProfile } from '../types/game';

interface ProfileJournalViewProps {
  profile: PlayerProfile;
}

export function ProfileJournalView({ profile }: ProfileJournalViewProps) {
  const skillsList = [
    { label: 'Структура рынка', value: profile.skills.marketStructure, icon: TrendingUp, color: '#22d3ee' },
    { label: 'Управление риском (EV)', value: profile.skills.riskManagement, icon: Scale, color: '#f59e0b' },
    { label: 'Психология & Тильт', value: profile.skills.psychologyControl, icon: BrainCircuit, color: '#a855f7' },
    { label: 'On-Chain чтение', value: profile.skills.onChainReading, icon: ShieldCheck, color: '#34d399' },
    { label: 'Дисциплина системы', value: profile.skills.disciplineProtocol, icon: Award, color: '#f87171' },
    { label: 'Макро-синтез', value: profile.skills.macroSynthesis, icon: UserCheck, color: '#60a5fa' }
  ];

  // SVG Radar Polygon math
  const size = 260;
  const center = size / 2;
  const radius = center * 0.75;
  const numAxes = skillsList.length;

  const points = skillsList.map((skill, i) => {
    const angle = (Math.PI * 2 / numAxes) * i - Math.PI / 2;
    const r = (skill.value / 100) * radius;
    return {
      x: center + r * Math.cos(angle),
      y: center + r * Math.sin(angle)
    };
  });

  const polygonPath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ') + ' Z';

  return (
    <div className="mx-auto max-w-[1520px] px-3 py-6 sm:px-6">
      
      {/* Profile Top Dossier Banner */}
      <div className="mb-6 rounded-2xl border border-cyan-500/20 bg-gradient-to-r from-cyan-950/50 via-[#071322] to-[#0a1828] p-5 sm:p-7 shadow-2xl">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-center">
          
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-tr from-cyan-500 to-emerald-400 font-display text-2xl font-black text-slate-950 shadow-[0_0_25px_rgba(34,211,238,0.4)]">
                {profile.level}
              </div>
              {profile.isPremium && (
                <div className="absolute -top-1.5 -right-1.5 grid h-6 w-6 place-items-center rounded-full bg-amber-400 text-slate-950 shadow-md">
                  <Crown size={14} strokeWidth={2.5} />
                </div>
              )}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display text-2xl font-black uppercase text-white sm:text-3xl">
                  {profile.name}
                </h1>
                <span className="rounded bg-cyan-950 px-2 py-0.5 font-mono text-xs font-bold text-cyan-400 border border-cyan-500/30">
                  {profile.handle}
                </span>
              </div>
              <div className="mt-1 text-sm font-medium text-slate-300">
                {profile.title} • {profile.league}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 border-t border-white/10 pt-4 md:border-t-0 md:pt-0">
            <div className="rounded-xl border border-white/10 bg-[#040a14] p-3 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Process Score</span>
              <div className="font-display text-2xl font-black text-cyan-300">{profile.averagePQS}</div>
            </div>
            <div className="rounded-xl border border-white/10 bg-[#040a14] p-3 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Ранг в Лиге</span>
              <div className="font-display text-2xl font-black text-amber-400">#{profile.leagueRank}</div>
            </div>
            <div className="rounded-xl border border-white/10 bg-[#040a14] p-3 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Серия Дней</span>
              <div className="font-display text-2xl font-black text-emerald-400">{profile.disciplineStreak}</div>
            </div>
          </div>

        </div>
      </div>

      {/* Main Grid: Radar Skills (Left) & Biases Audit / History (Right) */}
      <div className="grid gap-6 lg:grid-cols-[1fr_1.35fr]">
        
        {/* Radar Chart & Skills Profile */}
        <div className="rounded-2xl border border-white/10 bg-[#071322] p-5 sm:p-6 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
              Радар Торговых Навыков
            </span>
            <span className="font-mono text-xs text-slate-400">6 Осей Оценки</span>
          </div>

          {/* SVG Radar Chart */}
          <div className="grid place-items-center py-2">
            <svg width={size} height={size} className="select-none overflow-visible">
              {/* Concentric Web Rings */}
              {[0.25, 0.5, 0.75, 1].map((rRatio, i) => (
                <circle
                  key={i}
                  cx={center}
                  cy={center}
                  r={radius * rRatio}
                  fill="none"
                  stroke="rgba(255,255,255,0.08)"
                  strokeDasharray="2 2"
                />
              ))}

              {/* Axis lines */}
              {skillsList.map((_, i) => {
                const angle = (Math.PI * 2 / numAxes) * i - Math.PI / 2;
                const x2 = center + radius * Math.cos(angle);
                const y2 = center + radius * Math.sin(angle);
                return (
                  <line
                    key={i}
                    x1={center}
                    y1={center}
                    x2={x2}
                    y2={y2}
                    stroke="rgba(255,255,255,0.12)"
                  />
                );
              })}

              {/* Data Polygon Fill */}
              <path
                d={polygonPath}
                fill="rgba(34,211,238,0.22)"
                stroke="#22d3ee"
                strokeWidth="2.5"
                filter="drop-shadow(0 0 10px rgba(34,211,238,0.5))"
              />

              {/* Data Vertex Dots */}
              {points.map((p, i) => (
                <circle key={i} cx={p.x} cy={p.y} r="4" fill="#67e8f9" stroke="#06101c" strokeWidth="2" />
              ))}
            </svg>
          </div>

          {/* Skill Progress Sliders */}
          <div className="space-y-3 pt-2">
            {skillsList.map((sk, i) => {
              const Icon = sk.icon;
              return (
                <div key={i} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5 text-slate-300">
                      <Icon size={14} style={{ color: sk.color }} />
                      <span>{sk.label}</span>
                    </div>
                    <span className="font-mono font-bold text-white">{sk.value} / 100</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-[#040a14]">
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${sk.value}%`, background: sk.color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Cognitive Biases Audit & Decision History */}
        <div className="space-y-6">
          
          {/* Biases Audit Box */}
          <div className="rounded-2xl border border-white/10 bg-[#071322] p-5 sm:p-6 shadow-xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-300">
                Аудит Когнитивных Искажений (Bias Tracker)
              </span>
              <span className="font-mono text-xs text-slate-500">Авто-диагностика</span>
            </div>

            <div className="mt-4 space-y-3">
              {profile.cognitiveBiasesAudit.map((b, i) => (
                <div key={i} className="flex items-center justify-between rounded-xl border border-white/5 bg-[#040a14] p-3 text-xs">
                  <div>
                    <div className="font-bold text-slate-200">{b.name}</div>
                    <div className="mt-0.5 text-[11px] text-slate-400 font-mono">
                      Частота попадания в ловушку: {b.trapRate}%
                    </div>
                  </div>
                  <span className={`rounded-full px-2.5 py-0.5 font-mono text-[10px] font-bold ${
                    b.status === 'Контролируется'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}>
                    {b.status}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Decisions Log */}
          <div className="rounded-2xl border border-white/10 bg-[#071322] p-5 sm:p-6 shadow-xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <History size={16} className="text-cyan-400" />
                <span className="text-xs font-bold uppercase tracking-wider text-white">
                  Журнал последних решений
                </span>
              </div>
              <span className="font-mono text-xs text-slate-500">История сессий</span>
            </div>

            <div className="mt-4 space-y-2.5">
              {[
                { title: 'Terra LUNA: Спираль смерти', action: 'Остаться вне рынка (Скип)', pqs: 98, date: 'Сегодня 14:20', isOptimal: true },
                { title: 'Bitcoin ETF: Sell the News', action: 'Фиксация 70% прибыли', pqs: 96, date: 'Вчера 18:40', isOptimal: true },
                { title: 'FTX Collapse: Alameda Drain', action: 'Немедленный сброс позиции', pqs: 99, date: '2 дня назад', isOptimal: true }
              ].map((log, idx) => (
                <div key={idx} className="flex items-center justify-between rounded-xl border border-white/5 bg-[#040a14] p-3 text-xs">
                  <div>
                    <div className="font-bold text-slate-200">{log.title}</div>
                    <div className="mt-0.5 text-[11px] text-slate-400">{log.action}</div>
                  </div>
                  <div className="text-right font-mono">
                    <span className="font-bold text-emerald-400">+{log.pqs} PQS</span>
                    <div className="text-[9px] text-slate-500">{log.date}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
