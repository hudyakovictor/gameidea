import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Layers,
  Sparkles,
  Search
} from 'lucide-react';
import { allSignalCards } from '../data/cards';
import { SignalCard, CardCategory } from '../types/game';
import { soundManager } from '../utils/audio';

export function DeckView() {
  const [activeCategory, setActiveCategory] = useState<'all' | CardCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [inspectedCard, setInspectedCard] = useState<SignalCard | null>(null);

  const filteredCards = allSignalCards.filter((card) => {
    const matchesCat = activeCategory === 'all' || card.category === activeCategory;
    const matchesSearch =
      card.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      card.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      card.cryptoContext.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const categories: { id: 'all' | CardCategory; label: string; count: number }[] = [
    { id: 'all', label: 'Все карты', count: allSignalCards.length },
    { id: 'protocol', label: 'Протоколы (10)', count: 10 },
    { id: 'reading', label: 'Чтение контекста (10)', count: 10 },
    { id: 'defense', label: 'Защита капитала (10)', count: 10 },
    { id: 'decision', label: 'Принятие решений (10)', count: 10 }
  ];

  return (
    <div className="mx-auto max-w-[1520px] px-3 py-6 sm:px-6">
      
      {/* Header Banner */}
      <div className="mb-6 flex flex-col justify-between gap-4 rounded-2xl border border-cyan-500/20 bg-gradient-to-r from-[#071322] via-[#091b2c] to-[#0d1624] p-5 sm:p-6 shadow-xl md:flex-row md:items-center">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 rounded-full bg-cyan-500/20 px-3 py-0.5 text-[10px] font-mono font-bold uppercase tracking-wider text-cyan-300 border border-cyan-500/30">
              <Layers size={14} /> Картотека Навыков • 40 Протоколов
            </span>
          </div>
          <h1 className="font-display mt-2 text-2xl font-black uppercase tracking-tight text-white sm:text-3xl">
            Колода мышления трейдера
          </h1>
          <p className="mt-1 text-xs text-slate-300 sm:text-sm">
            Карты представляют законы анализа и защиты. Сила карты определяется контекстом ситуации на Арене, а не просто редкостью.
          </p>
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-72">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Поиск по картам и правилам..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-xl border border-white/10 bg-[#040a14] py-2 pl-9 pr-4 text-xs text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
          />
        </div>
      </div>

      {/* Category Tabs */}
      <div className="mb-6 flex flex-wrap gap-2">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => {
              setActiveCategory(cat.id);
              soundManager.playCardClick();
            }}
            className={`rounded-xl px-3.5 py-2 text-xs font-bold transition-all ${
              activeCategory === cat.id
                ? 'bg-cyan-400 text-slate-950 shadow-[0_0_15px_rgba(34,211,238,0.4)]'
                : 'border border-white/10 bg-[#071322] text-slate-400 hover:text-white'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Cards Grid */}
      <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
        {filteredCards.map((card) => {
          return (
            <motion.button
              key={card.id}
              whileHover={{ y: -6, scale: 1.02 }}
              onClick={() => {
                setInspectedCard(card);
                soundManager.playCardClick();
              }}
              className={`group relative flex min-h-[300px] flex-col justify-between rounded-2xl border p-4 text-left transition-all ${
                card.tone === 'cyan'
                  ? 'border-cyan-500/40 bg-gradient-to-b from-cyan-950/40 to-[#071422] text-cyan-300 shadow-[0_0_15px_rgba(34,211,238,0.12)]'
                  : card.tone === 'amber'
                  ? 'border-amber-500/40 bg-gradient-to-b from-amber-950/40 to-[#071422] text-amber-300 shadow-[0_0_15px_rgba(245,158,11,0.12)]'
                  : card.tone === 'violet'
                  ? 'border-violet-500/40 bg-gradient-to-b from-violet-950/40 to-[#071422] text-violet-300 shadow-[0_0_15px_rgba(168,85,247,0.12)]'
                  : 'border-emerald-500/40 bg-gradient-to-b from-emerald-950/40 to-[#071422] text-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.12)]'
              }`}
            >
              {/* Card Header */}
              <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-wider">
                <span className="rounded-full border border-current px-2 py-0.5">
                  {card.categoryName}
                </span>
                <span className="font-mono text-slate-400">Lv. {card.unlockedLevel}</span>
              </div>

              {/* Card Center Sigil Graphic */}
              <div className="my-4 grid place-items-center">
                <div className="grid h-16 w-16 place-items-center rounded-2xl border border-current/30 bg-current/10 shadow-[0_0_20px_currentColor] transition-transform group-hover:rotate-6">
                  <Sparkles size={28} />
                </div>
              </div>

              {/* Card Body */}
              <div>
                <h3 className="font-display text-base font-black uppercase leading-tight text-white group-hover:text-cyan-200">
                  {card.name}
                </h3>
                <p className="mt-1 text-[11px] leading-relaxed text-slate-300 line-clamp-2">
                  {card.description}
                </p>
              </div>

              {/* Card Footer */}
              <div className="mt-3 border-t border-current/20 pt-2 font-mono text-[10px] font-bold opacity-90">
                {card.bonus}
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Card Inspection Full Modal */}
      <AnimatePresence>
        {inspectedCard && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-lg rounded-2xl border border-cyan-400/50 bg-[#081524] p-6 shadow-2xl"
            >
              <button
                onClick={() => setInspectedCard(null)}
                className="absolute top-4 right-4 grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/5 text-slate-400 hover:text-white"
              >
                ✕
              </button>

              <div className="flex items-center gap-2">
                <span className="rounded-full bg-cyan-950 px-3 py-0.5 font-mono text-xs font-bold uppercase text-cyan-300 border border-cyan-500/30">
                  {inspectedCard.categoryName} • {inspectedCard.rarity}
                </span>
                <span className="font-mono text-xs text-slate-400">Открывается на {inspectedCard.unlockedLevel} уровне</span>
              </div>

              <h2 className="font-display mt-3 text-2xl font-black uppercase text-white sm:text-3xl">
                {inspectedCard.name}
              </h2>

              <p className="mt-2 text-sm leading-relaxed text-slate-300">
                {inspectedCard.description}
              </p>

              <div className="mt-5 space-y-3 rounded-xl border border-white/10 bg-[#040a14] p-4 text-xs">
                <div>
                  <div className="font-bold text-cyan-300 uppercase tracking-wider">Фундаментальный закон мышления:</div>
                  <div className="mt-1 text-slate-200">{inspectedCard.principle}</div>
                </div>
                <div>
                  <div className="font-bold text-amber-300 uppercase tracking-wider">Применение в реальной крипте:</div>
                  <div className="mt-1 text-slate-300">{inspectedCard.cryptoContext}</div>
                </div>
              </div>

              <blockquote className="mt-4 rounded-xl border-l-2 border-cyan-400 bg-cyan-500/10 p-3 text-xs italic text-cyan-200">
                {inspectedCard.flavorQuote}
              </blockquote>

              <div className="mt-5 flex items-center justify-between border-t border-white/10 pt-4">
                <span className="font-mono text-xs font-bold text-emerald-400">{inspectedCard.bonus}</span>
                <button
                  onClick={() => setInspectedCard(null)}
                  className="primary-button text-xs"
                >
                  Закрыть
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
