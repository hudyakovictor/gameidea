import { useState } from 'react';
import {
  Flame,
  Gem,
  Coins,
  Crown,
  Volume2,
  VolumeX,
  Bell,
  Sparkles,
  Zap,
  X
} from 'lucide-react';
import { PlayerProfile, GameMode } from '../types/game';
import { soundManager } from '../utils/audio';

interface HeaderProps {
  profile: PlayerProfile;
  currentMode: GameMode;
  onSelectMode: (mode: GameMode) => void;
  onOpenQuickScenario: () => void;
}

export function Header({
  profile,
  onSelectMode,
  onOpenQuickScenario
}: HeaderProps) {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [showNotifications, setShowNotifications] = useState(false);

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundManager.enabled = next;
    if (next) soundManager.playCardClick();
  };

  const notifications = [
    { id: 1, title: 'Турнир Недели стартовал!', desc: 'Квалификация в Лиге Аналитиков (Охота за ликвидациями 2022).', time: '10 мин назад', unread: true },
    { id: 2, title: 'Новый урок в Академии', desc: 'Раздел «On-Chain аналитика» разблокирован.', time: '2 часа назад', unread: true },
    { id: 3, title: 'Аудит когнитивных ловушек', desc: 'Ваша устойчивость к FOMO выросла до 88%!', time: 'Вчера', unread: false }
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-cyan-500/20 bg-[#06101c]/90 backdrop-blur-xl transition-all">
      <div className="mx-auto flex h-16 max-w-[1520px] items-center justify-between px-3 sm:px-6">
        
        {/* Left: Brand & Profile Snapshot */}
        <div className="flex items-center gap-3 sm:gap-6">
          <button
            onClick={() => onSelectMode('arena')}
            className="group flex items-center gap-2.5 text-left focus:outline-none"
          >
            <div className="relative grid h-10 w-10 place-items-center rounded-lg border border-cyan-400/40 bg-cyan-950/60 shadow-[0_0_15px_rgba(34,211,238,0.25)] transition-transform group-hover:scale-105">
              <svg viewBox="0 0 40 40" className="h-6 w-6">
                <path d="M6 25 L14 17 L21 24 L34 11" fill="none" stroke="#22d3ee" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M26 11 H34 V19" fill="none" stroke="#f59e0b" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                <circle cx="21" cy="24" r="2.5" fill="#a855f7" />
              </svg>
            </div>
            <div className="hidden xs:block sm:block leading-none">
              <div className="font-display text-base font-black tracking-wider text-white">
                SIGNAL <span className="text-cyan-400">ARENA</span>
              </div>
              <div className="mt-0.5 text-[9px] font-bold uppercase tracking-[0.25em] text-cyan-300/70">
                Crypto Decision Trainer
              </div>
            </div>
          </button>

          {/* Player Level & XP */}
          <button
            onClick={() => onSelectMode('profile')}
            className="hidden md:flex items-center gap-3 rounded-lg border border-white/10 bg-white/[0.03] px-3 py-1.5 transition-colors hover:border-cyan-400/40 hover:bg-white/[0.06]"
          >
            <div className="relative">
              <div className="grid h-8 w-8 place-items-center rounded-full bg-gradient-to-tr from-cyan-600 to-emerald-400 text-xs font-black text-slate-950 shadow-[0_0_10px_rgba(34,211,238,0.4)]">
                {profile.level}
              </div>
              {profile.isPremium && (
                <div className="absolute -top-1 -right-1 grid h-4 w-4 place-items-center rounded-full bg-amber-400 text-slate-950">
                  <Crown size={9} strokeWidth={3} />
                </div>
              )}
            </div>
            <div className="text-left">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-200">
                <span>{profile.name}</span>
                <span className="rounded bg-cyan-950/80 px-1 py-0.2 text-[9px] font-mono font-bold text-cyan-400 border border-cyan-500/30">
                  PQS {profile.averagePQS}
                </span>
              </div>
              <div className="mt-1 flex items-center gap-1.5">
                <div className="h-1.5 w-20 overflow-hidden rounded-full bg-slate-800">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-400 to-emerald-400"
                    style={{ width: `${(profile.currentXp / profile.nextLevelXp) * 100}%` }}
                  />
                </div>
                <span className="font-mono text-[9px] text-slate-400">
                  {profile.currentXp}/{profile.nextLevelXp} XP
                </span>
              </div>
            </div>
          </button>
        </div>

        {/* Center / Right: Resources & Global Stats */}
        <div className="flex items-center gap-2 sm:gap-4">
          
          {/* Discipline Streak */}
          <div
            className="flex items-center gap-1.5 rounded-lg border border-amber-500/20 bg-amber-500/[0.07] px-2.5 py-1.5 text-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.1)]"
            title="Дисциплинарная серия дней без тильта"
          >
            <Flame size={16} className="animate-pulse" fill="currentColor" />
            <span className="font-mono text-xs font-bold sm:text-sm">{profile.disciplineStreak}</span>
            <span className="hidden text-[10px] uppercase font-bold tracking-wider text-amber-300/80 lg:inline">дней</span>
          </div>

          {/* Crystals */}
          <div
            className="flex items-center gap-1.5 rounded-lg border border-violet-500/20 bg-violet-500/[0.07] px-2.5 py-1.5 text-violet-300 shadow-[0_0_10px_rgba(168,85,247,0.1)]"
            title="Кристаллы инсайта (за высокое качество анализа)"
          >
            <Gem size={15} fill="currentColor" />
            <span className="font-mono text-xs font-bold sm:text-sm">{profile.crystals.toLocaleString()}</span>
          </div>

          {/* Arena Tokens */}
          <div
            className="hidden sm:flex items-center gap-1.5 rounded-lg border border-cyan-500/20 bg-cyan-500/[0.07] px-2.5 py-1.5 text-cyan-300 shadow-[0_0_10px_rgba(34,211,238,0.1)]"
            title="Внутриигровые токены Арены (не торгуются за фиат)"
          >
            <Coins size={15} />
            <span className="font-mono text-xs font-bold sm:text-sm">{profile.arenaTokens.toLocaleString()}</span>
          </div>

          {/* Sound & Notifications */}
          <div className="flex items-center gap-1">
            <button
              onClick={toggleSound}
              className="grid h-9 w-9 place-items-center rounded-lg border border-white/10 bg-white/[0.02] text-slate-400 transition hover:border-cyan-400/40 hover:text-white"
              aria-label="Звуки"
              title={soundEnabled ? 'Звуковые эффекты включены' : 'Звуковые эффекты выключены'}
            >
              {soundEnabled ? <Volume2 size={16} className="text-cyan-400" /> : <VolumeX size={16} />}
            </button>

            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative grid h-9 w-9 place-items-center rounded-lg border border-white/10 bg-white/[0.02] text-slate-400 transition hover:border-cyan-400/40 hover:text-white"
                aria-label="Уведомления"
              >
                <Bell size={16} />
                <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
                <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-cyan-400" />
              </button>

              {/* Notifications Dropdown */}
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 rounded-xl border border-cyan-500/30 bg-[#081524] p-3 shadow-2xl z-50">
                  <div className="flex items-center justify-between border-b border-white/10 pb-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">Уведомления</span>
                    <button onClick={() => setShowNotifications(false)} className="text-slate-400 hover:text-white">
                      <X size={14} />
                    </button>
                  </div>
                  <div className="mt-2 space-y-2">
                    {notifications.map((n) => (
                      <div key={n.id} className="rounded-lg border border-white/5 bg-white/[0.02] p-2.5 text-left text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-200">{n.title}</span>
                          <span className="text-[9px] text-slate-500">{n.time}</span>
                        </div>
                        <p className="mt-1 text-slate-400 leading-snug">{n.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Quick Scenario CTA */}
          <button
            onClick={onOpenQuickScenario}
            className="flex items-center gap-1.5 rounded-lg border border-cyan-400/60 bg-gradient-to-r from-cyan-500 to-emerald-500 px-3 py-1.5 text-xs font-black uppercase tracking-wider text-slate-950 shadow-[0_0_18px_rgba(34,211,238,0.35)] transition-transform hover:scale-[1.03] active:scale-[0.98]"
          >
            <Zap size={14} fill="currentColor" />
            <span className="hidden sm:inline">Тренировка</span>
          </button>

          {/* PRO Pass Pill */}
          {profile.isPremium ? (
            <button
              onClick={() => onSelectMode('marketplace')}
              className="hidden xl:flex items-center gap-1.5 rounded-lg border border-amber-400/40 bg-amber-400/10 px-2.5 py-1.5 text-xs font-bold text-amber-300 hover:bg-amber-400/20"
            >
              <Crown size={13} className="text-amber-400" />
              <span>PRO PASS</span>
            </button>
          ) : (
            <button
              onClick={() => onSelectMode('marketplace')}
              className="hidden xl:flex items-center gap-1.5 rounded-lg border border-amber-500/40 bg-gradient-to-r from-amber-500/20 to-orange-500/20 px-2.5 py-1.5 text-xs font-bold text-amber-300 hover:border-amber-400"
            >
              <Sparkles size={13} />
              <span>Купить PRO</span>
            </button>
          )}

        </div>
      </div>
    </header>
  );
}
