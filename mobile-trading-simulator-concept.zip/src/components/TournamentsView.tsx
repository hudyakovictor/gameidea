import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Trophy,
  Users,
  Flame,
  Clock,
  Play
} from 'lucide-react';
import { activeTournaments, leaderboardPlayers } from '../data/tournaments';
import { TournamentMatch, CryptoScenario } from '../types/game';
import { soundManager } from '../utils/audio';

interface TournamentsViewProps {
  scenarios: CryptoScenario[];
  onStartScenario: (scenario: CryptoScenario) => void;
}

export function TournamentsView({ scenarios, onStartScenario }: TournamentsViewProps) {
  const [activeTab, setActiveTab] = useState<'tournaments' | 'leaderboard' | 'crowd_stats'>('tournaments');

  const handleEnterTournament = (tourney: TournamentMatch) => {
    soundManager.playSuccessChime();
    const scenario = scenarios.find((s) => s.id === tourney.scenarioId) || scenarios[0];
    onStartScenario(scenario);
  };

  const crowdDistribution = [
    {
      scenarioTitle: 'Terra LUNA: Спираль смерти $80 -> $0.00001',
      crowdChoice: [
        { label: 'Агрессивно ловить дно лонгом («Скидка 65%»)', percent: 64, isTrap: true },
        { label: 'Остаться вне рынка / Защитная пауза', percent: 24, isTrap: false },
        { label: 'Шорт с микро-риском (0.25%)', percent: 12, isTrap: false }
      ]
    },
    {
      scenarioTitle: 'Bitcoin ETF Launch: Sell the News $49k',
      crowdChoice: [
        { label: 'Лонг на все плечи на вершине новости', percent: 71, isTrap: true },
        { label: 'Фиксация прибыли & Сокращение позиций', percent: 21, isTrap: false },
        { label: 'Ждать закрепления выше $49,000', percent: 8, isTrap: false }
      ]
    }
  ];

  return (
    <div className="mx-auto max-w-[1520px] px-3 py-6 sm:px-6">
      
      {/* Header Banner */}
      <div className="mb-6 flex flex-col justify-between gap-4 rounded-2xl border border-amber-500/20 bg-gradient-to-r from-amber-950/40 via-[#071322] to-[#14120a] p-5 sm:p-6 shadow-xl md:flex-row md:items-center">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 rounded-full bg-amber-500/20 px-3 py-0.5 text-[10px] font-mono font-bold uppercase tracking-wider text-amber-300 border border-amber-500/30">
              <Trophy size={14} /> Социальный слой • Асинхронные Лиги
            </span>
            <span className="rounded bg-cyan-500/20 px-2 py-0.5 text-[10px] font-bold text-cyan-300">
              Рейтинг по качеству решений (Process Score), не по PnL!
            </span>
          </div>
          <h1 className="font-display mt-2 text-2xl font-black uppercase tracking-tight text-white sm:text-3xl">
            Лига Аналитиков & Состязания Дисциплины
          </h1>
          <p className="mt-1 text-xs text-slate-300 sm:text-sm">
            Все игроки ставятся в одинаковые исторические условия. Побеждает тот, кто следует системе и фильтрует шум.
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex gap-1.5 rounded-xl border border-white/10 bg-[#040a14] p-1">
          {[
            { id: 'tournaments', label: 'Турниры недели' },
            { id: 'leaderboard', label: 'Таблица Лиги' },
            { id: 'crowd_stats', label: 'Психология толпы' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as typeof activeTab);
                soundManager.playCardClick();
              }}
              className={`rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
                activeTab === tab.id
                  ? 'bg-amber-400 text-slate-950 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: Tournaments */}
      {activeTab === 'tournaments' && (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {activeTournaments.map((tourney) => (
            <div
              key={tourney.id}
              className="group relative flex flex-col justify-between rounded-2xl border border-white/10 bg-[#071322] p-5 shadow-xl transition-all hover:border-amber-400/40 hover:bg-[#08182b]"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="rounded bg-amber-500/20 px-2.5 py-0.5 font-mono text-[10px] font-bold text-amber-300 border border-amber-500/30">
                    {tourney.badge}
                  </span>
                  <div className="flex items-center gap-1 font-mono text-xs text-slate-400">
                    <Clock size={13} />
                    <span>{tourney.endTime}</span>
                  </div>
                </div>

                <h3 className="font-display mt-3 text-xl font-black uppercase text-white group-hover:text-amber-200">
                  {tourney.title}
                </h3>

                <div className="mt-4 space-y-2 rounded-xl border border-white/5 bg-[#040a14] p-3 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Участников:</span>
                    <span className="font-bold text-white">{tourney.participantsCount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Топ-скор недели:</span>
                    <span className="font-mono font-bold text-emerald-400">{tourney.topScore} PQS</span>
                  </div>
                  {tourney.playerScore && (
                    <div className="flex justify-between text-cyan-300 font-bold border-t border-white/5 pt-1.5">
                      <span>Твой результат:</span>
                      <span className="font-mono">#{tourney.playerRank} • {tourney.playerScore} PQS</span>
                    </div>
                  )}
                </div>

                <div className="mt-4 rounded-lg bg-amber-500/[0.06] p-2.5 text-xs text-amber-200">
                  <span className="font-bold">Награда:</span> {tourney.rewards.badgeTitle} (+{tourney.rewards.crystals} 💎)
                </div>
              </div>

              <div className="mt-5">
                <button
                  onClick={() => handleEnterTournament(tourney)}
                  className="primary-button w-full justify-center text-xs"
                >
                  <Play size={15} fill="currentColor" />
                  <span>{tourney.isEntered ? 'Переиграть сценарий' : 'Вступить в турнир'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 2: Leaderboard */}
      {activeTab === 'leaderboard' && (
        <div className="rounded-2xl border border-white/10 bg-[#071322] p-4 sm:p-6 shadow-2xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">Глобальный рейтинг качества</span>
              <h2 className="font-display mt-1 text-xl font-black uppercase text-white">Лига Аналитиков (Дивизион 1)</h2>
            </div>
            <span className="text-xs font-mono text-slate-500">Обновлено 5 мин назад</span>
          </div>

          <div className="mt-4 divide-y divide-white/5">
            {leaderboardPlayers.map((player) => (
              <motion.div
                key={player.handle}
                whileHover={{ x: 4 }}
                className={`flex items-center justify-between py-3.5 px-3 rounded-xl transition-colors ${
                  player.you
                    ? 'border border-cyan-400/40 bg-cyan-950/50 shadow-[0_0_15px_rgba(34,211,238,0.15)]'
                    : 'hover:bg-white/[0.02]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className={`grid h-7 w-7 place-items-center rounded-lg font-mono text-xs font-black ${
                    player.rank === 1
                      ? 'bg-amber-400 text-slate-950 shadow-[0_0_10px_rgba(245,158,11,0.5)]'
                      : player.rank === 2
                      ? 'bg-slate-300 text-slate-950'
                      : player.rank === 3
                      ? 'bg-amber-700 text-white'
                      : 'bg-white/10 text-slate-300'
                  }`}>
                    #{player.rank}
                  </span>

                  <div className="h-9 w-9 rounded-full grid place-items-center font-bold text-xs text-slate-950" style={{ background: player.avatarBg }}>
                    {player.name[0]}
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5 font-bold text-sm text-white">
                      <span>{player.name}</span>
                      {player.you && (
                        <span className="rounded bg-cyan-400 px-1.5 py-0.2 text-[9px] font-black text-slate-950">
                          ВЫ
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-400">{player.title}</div>
                  </div>
                </div>

                <div className="flex items-center gap-6 text-right">
                  <div className="hidden sm:block">
                    <div className="flex items-center gap-1 text-xs text-amber-400 font-bold justify-end">
                      <Flame size={14} fill="currentColor" />
                      <span>{player.streak} дн</span>
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">{player.decisionsCount} решений</div>
                  </div>

                  <div>
                    <div className="font-display text-lg font-black text-cyan-300 sm:text-xl">
                      {player.pqs}
                    </div>
                    <div className="text-[9px] uppercase font-bold text-slate-500">Avg PQS</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: Crowd Statistics */}
      {activeTab === 'crowd_stats' && (
        <div className="space-y-6">
          <div className="rounded-xl border border-cyan-500/20 bg-[#071322] p-5">
            <div className="flex items-center gap-2 font-bold text-cyan-300 text-sm">
              <Users size={18} />
              <span>Анатомия ошибок толпы в исторических сценариях</span>
            </div>
            <p className="mt-1 text-xs text-slate-400">
              Показывает процент игроков, которые попались в когнитивную ловушку в сравнении с хладнокровным системным меньшинством.
            </p>
          </div>

          <div className="grid gap-5 md:grid-cols-2">
            {crowdDistribution.map((item, idx) => (
              <div key={idx} className="rounded-2xl border border-white/10 bg-[#071322] p-5 shadow-xl">
                <h3 className="font-display text-base font-black uppercase text-white">
                  {item.scenarioTitle}
                </h3>

                <div className="mt-4 space-y-3">
                  {item.crowdChoice.map((ch, cIdx) => (
                    <div key={cIdx} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className={ch.isTrap ? 'text-red-300' : 'text-emerald-300'}>
                          {ch.label} {ch.isTrap && '⚠️ (Ловушка)'}
                        </span>
                        <span className="font-mono font-bold text-white">{ch.percent}%</span>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-[#040a14]">
                        <div
                          className={`h-full ${ch.isTrap ? 'bg-red-500' : 'bg-emerald-400'}`}
                          style={{ width: `${ch.percent}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
