import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Skull,
  ShieldAlert,
  Target,
  Layers
} from 'lucide-react';
import { marketEntities } from '../data/entities';
import { MarketEntity } from '../types/game';
import { allSignalCards } from '../data/cards';
import { soundManager } from '../utils/audio';

export function BestiaryView() {
  const [selectedEntity, setSelectedEntity] = useState<MarketEntity>(marketEntities[0]);
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'risk' | 'emotions' | 'noise' | 'signals' | 'web3'>('all');

  const filteredEntities = marketEntities.filter(
    (e) => categoryFilter === 'all' || e.category === categoryFilter
  );

  const getRecommendedCards = (cardIds: string[]) => {
    return allSignalCards.filter((c) => cardIds.includes(c.id));
  };

  return (
    <div className="mx-auto max-w-[1520px] px-3 py-6 sm:px-6">
      
      {/* Heading */}
      <div className="mb-6 flex flex-col justify-between gap-4 rounded-2xl border border-red-500/20 bg-gradient-to-r from-red-950/40 via-[#071322] to-[#120814] p-5 sm:p-6 shadow-xl md:flex-row md:items-center">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 rounded-full bg-red-500/20 px-3 py-0.5 text-[10px] font-mono font-bold uppercase tracking-wider text-red-300 border border-red-500/30">
              <Skull size={14} /> Бестиарий Угроз • Каталог Когнитивных Ловушек
            </span>
          </div>
          <h1 className="font-display mt-2 text-2xl font-black uppercase tracking-tight text-white sm:text-3xl">
            Рыночные сущности & Психологические демоны
          </h1>
          <p className="mt-1 text-xs text-slate-300 sm:text-sm">
            Сущности не «убиваются» силой клика. Они нейтрализуются хладнокровным распознаванием и протоколами защиты.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-1.5">
          {[
            { id: 'all', label: 'Все угрозы' },
            { id: 'risk', label: 'Риск & Плечи' },
            { id: 'emotions', label: 'Эмоции & FOMO' },
            { id: 'noise', label: 'FUD & Инфошум' },
            { id: 'signals', label: 'Ложные сигналы' },
            { id: 'web3', label: 'Web3 & Скамы' }
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setCategoryFilter(cat.id as typeof categoryFilter);
                soundManager.playCardClick();
              }}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-bold transition-all ${
                categoryFilter === cat.id
                  ? 'bg-red-400 text-slate-950 shadow-[0_0_12px_rgba(248,113,113,0.4)]'
                  : 'border border-white/10 bg-white/[0.03] text-slate-400 hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Showcase Grid */}
      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        
        {/* Entities Gallery Cards */}
        <div className="grid gap-4 sm:grid-cols-2">
          {filteredEntities.map((ent) => {
            const isSelected = selectedEntity.id === ent.id;
            return (
              <motion.button
                key={ent.id}
                whileHover={{ y: -3 }}
                onClick={() => {
                  setSelectedEntity(ent);
                  soundManager.playThreatAlert();
                }}
                className={`group relative flex flex-col overflow-hidden rounded-2xl border text-left transition-all ${
                  isSelected
                    ? 'border-red-400 bg-[#160a12] shadow-[0_0_25px_rgba(239,68,68,0.25)]'
                    : 'border-white/10 bg-[#071322] hover:border-white/20'
                }`}
              >
                <div className="relative h-44 w-full overflow-hidden">
                  <img
                    src={ent.image}
                    alt={ent.name}
                    className="h-full w-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#071322] via-transparent to-transparent" />
                  
                  <div className="absolute top-3 left-3 rounded bg-red-950/80 px-2 py-0.5 text-[9px] font-mono font-bold uppercase text-red-300 border border-red-500/30">
                    Опасность {ent.threatLevel}%
                  </div>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-red-400">{ent.categoryLabel}</span>
                    <h3 className="font-display text-lg font-black uppercase text-white group-hover:text-red-200">
                      {ent.name}
                    </h3>
                    <p className="mt-1 text-xs text-slate-400 line-clamp-2">
                      {ent.title}
                    </p>
                  </div>

                  <div className="mt-4 flex items-center justify-between border-t border-white/5 pt-2 text-[10px] font-mono text-slate-500">
                    <span>Нейтрализовано: {ent.defeatedCount} раз</span>
                    <span className="text-cyan-400 font-bold group-hover:translate-x-1 transition-transform">Досье →</span>
                  </div>
                </div>
              </motion.button>
            );
          })}
        </div>

        {/* Selected Entity Deep Dossier */}
        <div className="space-y-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedEntity.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="rounded-2xl border border-red-500/30 bg-gradient-to-b from-[#180914] via-[#0b101c] to-[#06101c] p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between">
                <span className="rounded-full bg-red-950 px-3 py-1 font-mono text-[10px] font-bold uppercase text-red-300 border border-red-500/40">
                  {selectedEntity.categoryLabel}
                </span>
                <span className="font-mono text-xs font-bold text-red-400">
                  Угроза: {selectedEntity.threatLevel} / 100
                </span>
              </div>

              <h2 className="font-display mt-3 text-2xl font-black uppercase text-white sm:text-3xl">
                {selectedEntity.name}
              </h2>
              <div className="text-sm text-slate-300 font-medium">
                {selectedEntity.title}
              </div>

              {/* Quote */}
              <blockquote className="mt-4 rounded-xl border-l-3 border-red-400 bg-red-500/10 p-3 text-xs italic text-red-200">
                {selectedEntity.quote}
              </blockquote>

              {/* Psychological Trap */}
              <div className="mt-5 rounded-xl border border-white/10 bg-[#040a14] p-4 text-xs space-y-1.5">
                <div className="flex items-center gap-1.5 font-bold uppercase text-amber-300 tracking-wider">
                  <ShieldAlert size={15} />
                  <span>Когнитивная ловушка:</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  {selectedEntity.cognitiveTrap}
                </p>
                <div className="mt-2 text-slate-400">
                  {selectedEntity.marketBehavior}
                </div>
              </div>

              {/* Counter-measures */}
              <div className="mt-4 rounded-xl border border-cyan-500/20 bg-cyan-950/20 p-4 text-xs">
                <div className="flex items-center gap-1.5 font-bold uppercase text-cyan-300 tracking-wider">
                  <Target size={15} />
                  <span>Контрмеры мышления:</span>
                </div>
                <ul className="mt-2 space-y-1.5 text-slate-300">
                  {selectedEntity.counterMeasures.map((cm, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-cyan-400 font-bold">🛡</span>
                      <span>{cm}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Recommended Cards */}
              <div className="mt-4">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Рекомендуемые карты навыков:
                </span>
                <div className="mt-2 flex flex-wrap gap-2">
                  {getRecommendedCards(selectedEntity.recommendedCards).map((card) => (
                    <span
                      key={card.id}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-cyan-500/30 bg-cyan-950/50 px-2.5 py-1 text-xs font-mono font-bold text-cyan-300"
                    >
                      <Layers size={13} />
                      {card.name}
                    </span>
                  ))}
                </div>
              </div>

            </motion.div>
          </AnimatePresence>
        </div>

      </div>

    </div>
  );
}
