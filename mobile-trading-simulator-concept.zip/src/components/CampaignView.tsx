import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Lock,
  CheckCircle2,
  Trophy,
  Play,
  Shield,
  ChevronRight
} from 'lucide-react';
import { CryptoScenario } from '../types/game';
import { soundManager } from '../utils/audio';

interface CampaignViewProps {
  scenarios: CryptoScenario[];
  onStartScenario: (scenario: CryptoScenario) => void;
}

export function CampaignView({ scenarios, onStartScenario }: CampaignViewProps) {
  const [selectedEpochIndex, setSelectedEpochIndex] = useState(0);

  const epochs = [
    {
      id: 'epoch_2014',
      title: '2014: Крах Mt.Gox & Первая Зима',
      desc: 'Потеря 850,000 BTC ведущей биржей мира. Первое масштабное испытание устойчивости Биткоина.',
      status: 'completed',
      stars: 3,
      scenarioId: 'scenario_luna_death_spiral_2022',
      difficulty: 'Базовый',
      color: '#34d399',
      bgGlow: 'from-emerald-950/40'
    },
    {
      id: 'epoch_2017',
      title: '2017: Бум ICO & Пузырь Альткоинов',
      desc: 'Эра токенсейлов на салфетках, пампы 100x и последующий ледяной обвал 2018 года на 90%.',
      status: 'completed',
      stars: 3,
      scenarioId: 'scenario_btc_etf_sell_news_2024',
      difficulty: 'Аналитик',
      color: '#22d3ee',
      bgGlow: 'from-cyan-950/40'
    },
    {
      id: 'epoch_2020',
      title: '2020: Black Thursday (Мартовский Крах)',
      desc: 'Падение Биткоина на 50% за 24 часа из-за глобального шока ликвидности в пандемию.',
      status: 'completed',
      stars: 2,
      scenarioId: 'scenario_luna_death_spiral_2022',
      difficulty: 'Профи',
      color: '#a855f7',
      bgGlow: 'from-purple-950/40'
    },
    {
      id: 'epoch_2021',
      title: '2021: Пик All-Time-High & Эйфория 100x',
      desc: 'Биткоин по $69,000, мемкоины с капитализацией миллиардов и ликвидационный водопад китайского бана.',
      status: 'active',
      stars: 1,
      scenarioId: 'scenario_btc_etf_sell_news_2024',
      difficulty: 'Профи',
      color: '#f59e0b',
      bgGlow: 'from-amber-950/40'
    },
    {
      id: 'epoch_2022',
      title: '2022: Terra LUNA & Крах Империи FTX',
      desc: 'Спираль смерти алгоритмического стейблкоина UST и банкротство второй биржи мира FTX.',
      status: 'active',
      stars: 0,
      scenarioId: 'scenario_ftx_collapse_2022',
      difficulty: 'Грандмастер',
      color: '#ef4444',
      bgGlow: 'from-red-950/40'
    },
    {
      id: 'epoch_2023',
      title: '2023: Банкопад Silicon Valley Bank',
      desc: 'Депег USDC до $0.87 из-за краха кастодиального банка и последующее институциональное восстановление.',
      status: 'locked',
      stars: 0,
      scenarioId: 'scenario_luna_death_spiral_2022',
      difficulty: 'Эксперт',
      color: '#64748b',
      bgGlow: 'from-slate-950/40'
    },
    {
      id: 'epoch_2024',
      title: '2024: Запуск Спотовых Биткоин ETF',
      desc: 'Институционализация Уолл-Стрит, Sell the News ловушки и мемкоин-мания на Solana.',
      status: 'locked',
      stars: 0,
      scenarioId: 'scenario_btc_etf_sell_news_2024',
      difficulty: 'Грандмастер',
      color: '#64748b',
      bgGlow: 'from-slate-950/40'
    },
    {
      id: 'epoch_2025',
      title: '2025+: Эпоха GameFi 2.0 & AI-Агентов',
      desc: 'Автономные ончейн-агенты, переход к Proof-of-Discipline и институциональное доминирование.',
      status: 'locked',
      stars: 0,
      scenarioId: 'scenario_ftx_collapse_2022',
      difficulty: 'Уровень 99',
      color: '#64748b',
      bgGlow: 'from-slate-950/40'
    }
  ];

  const currentEpoch = epochs[selectedEpochIndex];

  const handleStart = () => {
    soundManager.playCardClick();
    const scenario = scenarios.find((s) => s.id === currentEpoch.scenarioId) || scenarios[0];
    onStartScenario(scenario);
  };

  return (
    <div className="mx-auto max-w-[1520px] px-3 py-6 sm:px-6">
      
      {/* Heading */}
      <div className="mb-6 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
        <div>
          <div className="text-[10px] font-bold uppercase tracking-[0.25em] text-cyan-400">
            Мета-игра • Карта мира
          </div>
          <h1 className="font-display mt-1 text-2xl font-black uppercase tracking-tight text-white sm:text-3xl">
            Архив исторических кризисов крипты
          </h1>
          <p className="mt-1 text-xs text-slate-400 sm:text-sm">
            Пройди все 8 ключевых эпох крипторынка, восстанови хроники решений и открой статус Грандмастера.
          </p>
        </div>

        <div className="flex items-center gap-4 font-mono text-xs text-slate-300">
          <span className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#071322] px-3 py-1.5">
            <Trophy size={14} className="text-amber-400" />
            <span>Исследовано: 5 / 8 глав</span>
          </span>
        </div>
      </div>

      {/* World Map Layout (Grid of Epochs & Selected Epoch Card) */}
      <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        
        {/* Interactive Map Nodes Grid */}
        <div className="relative rounded-2xl border border-white/10 bg-[#06101c] p-4 sm:p-6 shadow-2xl">
          
          {/* Subtle Cyber Grid Background */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:32px_32px]" />
          
          <div className="relative z-10 grid gap-3 sm:grid-cols-2">
            {epochs.map((ep, idx) => {
              const isSelected = selectedEpochIndex === idx;
              return (
                <button
                  key={ep.id}
                  onClick={() => {
                    setSelectedEpochIndex(idx);
                    soundManager.playCardClick();
                  }}
                  className={`group relative flex flex-col justify-between rounded-xl border p-4 text-left transition-all ${
                    isSelected
                      ? 'border-cyan-400 bg-gradient-to-br from-cyan-950/60 to-[#071424] shadow-[0_0_20px_rgba(34,211,238,0.25)]'
                      : ep.status === 'locked'
                      ? 'border-white/5 bg-[#03070e]/80 opacity-50'
                      : 'border-white/10 bg-[#071322] hover:border-cyan-400/40 hover:bg-[#091b2c]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold" style={{ color: ep.color }}>
                      Эпоха 0{idx + 1}
                    </span>
                    <div className="flex items-center gap-1">
                      {ep.status === 'completed' && <CheckCircle2 size={15} className="text-emerald-400" />}
                      {ep.status === 'active' && <span className="h-2 w-2 rounded-full bg-amber-400 animate-ping" />}
                      {ep.status === 'locked' && <Lock size={14} className="text-slate-600" />}
                    </div>
                  </div>

                  <div className="my-3">
                    <h3 className="font-display text-base font-black uppercase text-white group-hover:text-cyan-200">
                      {ep.title}
                    </h3>
                    <p className="mt-1 text-xs text-slate-400 line-clamp-2">
                      {ep.desc}
                    </p>
                  </div>

                  <div className="flex items-center justify-between border-t border-white/5 pt-2 text-[10px] font-mono text-slate-500">
                    <span>{ep.difficulty}</span>
                    <div className="flex gap-0.5 text-amber-400">
                      {'★'.repeat(ep.stars)}{'☆'.repeat(3 - ep.stars)}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Epoch Detailed Dossier */}
        <div className="space-y-4">
          <motion.div
            key={currentEpoch.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className={`rounded-2xl border border-white/10 bg-gradient-to-b ${currentEpoch.bgGlow} to-[#071322] p-5 sm:p-6 shadow-xl`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-widest text-cyan-400">
                Досье исторической главы
              </span>
              <span className="rounded bg-white/10 px-2 py-0.5 font-mono text-[10px] font-bold text-white">
                {currentEpoch.difficulty}
              </span>
            </div>

            <h2 className="font-display mt-3 text-2xl font-black uppercase text-white">
              {currentEpoch.title}
            </h2>

            <p className="mt-2 text-xs leading-relaxed text-slate-300">
              {currentEpoch.desc}
            </p>

            <div className="mt-5 space-y-2.5 rounded-xl border border-white/10 bg-[#040a14] p-3.5 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Прогресс главы:</span>
                <span className="font-bold text-white">{currentEpoch.status === 'completed' ? '100% Завершено' : currentEpoch.status === 'active' ? 'В процессе' : 'Заблокировано'}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Награды за прохождение:</span>
                <span className="font-mono font-bold text-amber-300">+250 XP • 💎 120</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Связанная угроза:</span>
                <span className="font-bold text-red-400">Leverage Goblin & FUD Titan</span>
              </div>
            </div>

            <div className="mt-6">
              {currentEpoch.status !== 'locked' ? (
                <button
                  onClick={handleStart}
                  className="primary-button w-full justify-center"
                >
                  <Play size={16} fill="currentColor" />
                  <span>Войти в сценарий эпохи</span>
                  <ChevronRight size={16} />
                </button>
              ) : (
                <button
                  disabled
                  className="secondary-button w-full justify-center opacity-40 cursor-not-allowed"
                >
                  <Lock size={15} />
                  <span>Требуется завершить предыдущую главу</span>
                </button>
              )}
            </div>
          </motion.div>

          {/* Lore info card */}
          <div className="rounded-xl border border-white/10 bg-[#071322] p-4 text-xs text-slate-400">
            <div className="flex items-center gap-2 font-bold text-slate-200">
              <Shield size={16} className="text-cyan-400" />
              <span>Правило Архива Истории</span>
            </div>
            <p className="mt-1.5 leading-relaxed">
              Все сценарии основаны на реальных тиковых данных и исторических архивах ончейна. Задача — распознать паттерны, которые повторяются каждое десятилетие.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
}
