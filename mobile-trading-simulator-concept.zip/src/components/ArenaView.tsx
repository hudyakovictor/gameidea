import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  TrendingUp,
  Database,
  BarChart3,
  Newspaper,
  Users,
  Briefcase,
  AlertTriangle,
  ShieldCheck,
  Zap,
  CheckCircle2,
  XCircle,
  Play,
  Layers,
  Award,
  Crown,
  Share2,
  Eye,
  Info
} from 'lucide-react';
import { CryptoScenario, DecisionOption } from '../types/game';
import { marketEntities } from '../data/entities';
import { allSignalCards } from '../data/cards';
import { soundManager } from '../utils/audio';

interface ArenaViewProps {
  scenarios: CryptoScenario[];
  currentScenario: CryptoScenario;
  onSelectScenario: (scenario: CryptoScenario) => void;
  onCompleteScenario: (scenarioId: string, score: number) => void;
}

type BrowserTab = 'chart' | 'onchain' | 'orderbook' | 'news' | 'social' | 'position';

export function ArenaView({
  scenarios,
  currentScenario,
  onSelectScenario,
  onCompleteScenario
}: ArenaViewProps) {
  const [activeTab, setActiveTab] = useState<BrowserTab>('chart');
  const [selectedDecision, setSelectedDecision] = useState<DecisionOption | null>(null);
  const [selectedSecondStep, setSelectedSecondStep] = useState<string | null>(null);
  const [isRevealed, setIsRevealed] = useState(false);
  const [inspectedCardId, setInspectedCardId] = useState<string | null>(null);

  const activeEntity = marketEntities.find((e) => e.id === currentScenario.activeEntityId) || marketEntities[0];
  const equippedCardsList = allSignalCards.filter((c) => currentScenario.equippedCards.includes(c.id));
  const inspectedCard = allSignalCards.find((c) => c.id === inspectedCardId);

  const handleDecisionClick = (decision: DecisionOption) => {
    if (isRevealed) return;
    soundManager.playDecisionSelect();
    setSelectedDecision(decision);
  };

  const handleReveal = () => {
    if (!selectedDecision) return;
    setIsRevealed(true);
    if (selectedDecision.processScore >= 80) {
      soundManager.playSuccessChime();
    } else {
      soundManager.playThreatAlert();
    }
    onCompleteScenario(currentScenario.id, selectedDecision.processScore);
  };

  const handleNextScenario = () => {
    const currentIndex = scenarios.findIndex((s) => s.id === currentScenario.id);
    const nextIndex = (currentIndex + 1) % scenarios.length;
    setSelectedDecision(null);
    setSelectedSecondStep(null);
    setIsRevealed(false);
    setActiveTab('chart');
    onSelectScenario(scenarios[nextIndex]);
    soundManager.playCardClick();
  };

  const resetCurrent = () => {
    setSelectedDecision(null);
    setSelectedSecondStep(null);
    setIsRevealed(false);
    setActiveTab('chart');
    soundManager.playCardClick();
  };

  // Render SVG Chart for Scenario
  const renderChart = () => {
    const { candles, levels } = currentScenario.tabs.chartData;
    const visibleCandles = isRevealed ? candles : candles.filter((c) => !c.isFuture);
    const minPrice = Math.min(...visibleCandles.map((c) => c.low)) * 0.96;
    const maxPrice = Math.max(...visibleCandles.map((c) => c.high)) * 1.04;
    const priceRange = maxPrice - minPrice || 1;

    const chartHeight = 260;
    const chartWidth = 620;
    const candleWidth = Math.max(14, (chartWidth / (visibleCandles.length + 1)) * 0.65);

    return (
      <div className="relative rounded-xl border border-cyan-500/20 bg-[#040a14] p-3 sm:p-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-2.5 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-mono font-bold text-cyan-300">{currentScenario.tabs.chartData.symbol}</span>
            <span className="rounded bg-cyan-950 px-1.5 py-0.5 text-[10px] font-mono text-cyan-400 border border-cyan-500/30">
              {currentScenario.tabs.chartData.timeframe}
            </span>
          </div>
          <div className="flex items-center gap-3 text-[11px] font-mono text-slate-400">
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-emerald-400" /> Бычья свеча</span>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-red-400" /> Медвежья свеча</span>
            {isRevealed && <span className="flex items-center gap-1 text-amber-300 font-bold"><Eye size={12} /> Раскрыто будущее</span>}
          </div>
        </div>

        {/* SVG Candlestick Viewport */}
        <div className="relative mt-3 overflow-x-auto">
          <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full min-w-[540px] h-[240px] select-none">
            {/* Grid lines */}
            {[0.2, 0.4, 0.6, 0.8].map((ratio, i) => {
              const y = chartHeight * ratio;
              const priceLabel = (maxPrice - ratio * priceRange).toFixed(1);
              return (
                <g key={i}>
                  <line x1="0" y1={y} x2={chartWidth - 55} y2={y} stroke="rgba(255,255,255,0.06)" strokeDasharray="3 3" />
                  <text x={chartWidth - 50} y={y + 4} fill="#64748b" fontSize="9" fontFamily="monospace">
                    ${priceLabel}
                  </text>
                </g>
              );
            })}

            {/* Price Levels */}
            {levels.map((lvl, i) => {
              const y = chartHeight - ((lvl.price - minPrice) / priceRange) * chartHeight;
              if (y < 0 || y > chartHeight) return null;
              const color = lvl.type === 'resistance' ? '#f87171' : lvl.type === 'support' ? '#34d399' : '#f59e0b';
              return (
                <g key={i}>
                  <line x1="0" y1={y} x2={chartWidth - 55} y2={y} stroke={color} strokeWidth="1.5" strokeDasharray="4 2" />
                  <rect x="8" y={y - 12} width={lvl.label.length * 6 + 10} height="14" fill="#040a14" rx="2" stroke={color} strokeWidth="0.5" />
                  <text x="12" y={y - 2} fill={color} fontSize="8.5" fontWeight="bold">
                    {lvl.label} (${lvl.price})
                  </text>
                </g>
              );
            })}

            {/* Decision Point Vertical Cutoff */}
            {!isRevealed && (
              <g>
                <line x1={chartWidth - 140} y1="0" x2={chartWidth - 140} y2={chartHeight} stroke="#22d3ee" strokeWidth="2" strokeDasharray="5 3" />
                <rect x={chartWidth - 210} y="8" width="65" height="18" fill="#083344" rx="3" stroke="#22d3ee" strokeWidth="1" />
                <text x={chartWidth - 203} y="20" fill="#67e8f9" fontSize="9" fontWeight="bold" fontFamily="monospace">
                  Точка t₀
                </text>
              </g>
            )}

            {/* Candles */}
            {visibleCandles.map((candle, idx) => {
              const x = 30 + idx * ((chartWidth - 90) / visibleCandles.length);
              const isBullish = candle.close >= candle.open;
              const candleColor = candle.isFuture ? (isBullish ? '#10b981' : '#ef4444') : (isBullish ? '#34d399' : '#f87171');
              
              const yHigh = chartHeight - ((candle.high - minPrice) / priceRange) * chartHeight;
              const yLow = chartHeight - ((candle.low - minPrice) / priceRange) * chartHeight;
              const yOpen = chartHeight - ((candle.open - minPrice) / priceRange) * chartHeight;
              const yClose = chartHeight - ((candle.close - minPrice) / priceRange) * chartHeight;
              
              const bodyTop = Math.min(yOpen, yClose);
              const bodyHeight = Math.max(3, Math.abs(yClose - yOpen));

              return (
                <g key={idx} className="transition-opacity">
                  {/* High-Low Wick */}
                  <line x1={x} y1={yHigh} x2={x} y2={yLow} stroke={candleColor} strokeWidth="1.5" />
                  
                  {/* Candle Body */}
                  <rect
                    x={x - candleWidth / 2}
                    y={bodyTop}
                    width={candleWidth}
                    height={bodyHeight}
                    fill={isBullish ? (candle.isFuture ? '#059669' : '#065f46') : (candle.isFuture ? '#dc2626' : '#991b1b')}
                    stroke={candleColor}
                    strokeWidth="1.2"
                    rx="1"
                  />

                  {/* Future candle pulse indicator */}
                  {candle.isFuture && (
                    <circle cx={x} cy={yClose} r="3" fill="#f59e0b" className="animate-ping" opacity="0.4" />
                  )}

                  {/* Candle Time label */}
                  {idx % 2 === 0 && (
                    <text x={x} y={chartHeight - 4} fill="#64748b" fontSize="7.5" textAnchor="middle" fontFamily="monospace">
                      {candle.time.split(' ')[0]}
                    </text>
                  )}
                </g>
              );
            })}
          </svg>
        </div>

        {/* Chart notes */}
        <div className="mt-3 flex flex-wrap gap-2 border-t border-white/5 pt-2">
          {currentScenario.tabs.chartData.notes.map((note, i) => (
            <span key={i} className="inline-flex items-center gap-1 rounded bg-cyan-950/50 px-2 py-1 text-[11px] text-cyan-300/90 border border-cyan-500/20">
              <Info size={11} className="text-cyan-400" />
              {note}
            </span>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="mx-auto max-w-[1520px] px-3 py-6 sm:px-6">
      
      {/* Top Scenario Switcher & Meta Bar */}
      <div className="mb-6 flex flex-col justify-between gap-4 rounded-xl border border-white/10 bg-[#071322]/80 p-4 backdrop-blur-md md:flex-row md:items-center">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded bg-cyan-500/10 px-2.5 py-0.5 font-mono text-[11px] font-bold uppercase tracking-wider text-cyan-300 border border-cyan-500/30">
              {currentScenario.epoch} ({currentScenario.year})
            </span>
            <span className={`rounded px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wider ${
              currentScenario.difficulty === 'Грандмастер'
                ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                : currentScenario.difficulty === 'Профи'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
            }`}>
              Сложность: {currentScenario.difficulty} ({currentScenario.difficultyLevel}/99)
            </span>
            <span className="rounded bg-violet-500/20 px-2 py-0.5 text-[11px] font-bold text-violet-300 border border-violet-500/30">
              {currentScenario.situationTypeLabel}
            </span>
          </div>
          <h1 className="font-display mt-1.5 text-xl font-black uppercase tracking-tight text-white sm:text-2xl">
            {currentScenario.title}
          </h1>
        </div>

        {/* Scenario Switcher Carousel */}
        <div className="flex items-center gap-2">
          <span className="hidden text-xs text-slate-400 font-mono sm:inline">Сценарии:</span>
          <div className="flex gap-1.5 overflow-x-auto pb-1">
            {scenarios.map((sc, i) => (
              <button
                key={sc.id}
                onClick={() => {
                  soundManager.playCardClick();
                  onSelectScenario(sc);
                  setIsRevealed(false);
                  setSelectedDecision(null);
                }}
                className={`rounded-lg px-2.5 py-1.5 font-mono text-xs font-bold transition-all ${
                  sc.id === currentScenario.id
                    ? 'bg-cyan-400 text-slate-950 shadow-[0_0_12px_rgba(34,211,238,0.5)]'
                    : 'border border-white/10 bg-white/[0.03] text-slate-400 hover:border-cyan-400/40 hover:text-white'
                }`}
              >
                0{i + 1}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Grid: 2 Columns (Left: Browser Widget & Narrative, Right: Entity Threat & Decision Engine) */}
      <div className="grid gap-6 xl:grid-cols-[1.35fr_1fr]">
        
        {/* LEFT COLUMN: Modern Browser Model Interface */}
        <div className="space-y-6">
          
          {/* Situation Context Box */}
          <div className="rounded-xl border border-cyan-500/30 bg-gradient-to-r from-cyan-950/40 via-[#071524] to-[#071322] p-4 sm:p-5 shadow-lg">
            <div className="flex items-start gap-3">
              <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-cyan-400/10 text-cyan-300 border border-cyan-400/30">
                <Briefcase size={18} />
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-cyan-400">Ситуация перед решением</span>
                <p className="mt-1 text-sm font-medium leading-relaxed text-slate-200 sm:text-base">
                  {currentScenario.summary}
                </p>
                <div className="mt-3 flex items-center gap-2 font-mono text-xs font-bold text-amber-300">
                  <AlertTriangle size={15} />
                  <span>{currentScenario.keyQuestion}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Browser Widget with Functional Tabs */}
          <div className="overflow-hidden rounded-xl border border-white/10 bg-[#06111f] shadow-2xl">
            
            {/* Browser Top Bar & Tabs */}
            <div className="flex flex-wrap items-center justify-between border-b border-white/10 bg-[#040a14] px-3 pt-2">
              <div className="flex flex-wrap gap-1">
                
                {/* Tab: Chart */}
                <button
                  onClick={() => { setActiveTab('chart'); soundManager.playCardClick(); }}
                  className={`flex items-center gap-1.5 rounded-t-lg px-3 py-2 text-xs font-bold transition-colors ${
                    activeTab === 'chart'
                      ? 'border-t-2 border-cyan-400 bg-[#06111f] text-cyan-300'
                      : 'text-slate-400 hover:bg-white/[0.03] hover:text-slate-200'
                  }`}
                >
                  <TrendingUp size={14} className="text-cyan-400" />
                  <span>График</span>
                </button>

                {/* Tab: On-Chain */}
                <button
                  onClick={() => { setActiveTab('onchain'); soundManager.playCardClick(); }}
                  className={`flex items-center gap-1.5 rounded-t-lg px-3 py-2 text-xs font-bold transition-colors ${
                    activeTab === 'onchain'
                      ? 'border-t-2 border-cyan-400 bg-[#06111f] text-cyan-300'
                      : 'text-slate-400 hover:bg-white/[0.03] hover:text-slate-200'
                  }`}
                >
                  <Database size={14} className="text-cyan-400" />
                  <span>On-Chain</span>
                </button>

                {/* Tab: Order Book & Liquidity */}
                <button
                  onClick={() => { setActiveTab('orderbook'); soundManager.playCardClick(); }}
                  className={`flex items-center gap-1.5 rounded-t-lg px-3 py-2 text-xs font-bold transition-colors ${
                    activeTab === 'orderbook'
                      ? 'border-t-2 border-cyan-400 bg-[#06111f] text-cyan-300'
                      : 'text-slate-400 hover:bg-white/[0.03] hover:text-slate-200'
                  }`}
                >
                  <BarChart3 size={14} className="text-cyan-400" />
                  <span>Стакан & Фандинг</span>
                </button>

                {/* Tab: News */}
                <button
                  onClick={() => { setActiveTab('news'); soundManager.playCardClick(); }}
                  className={`flex items-center gap-1.5 rounded-t-lg px-3 py-2 text-xs font-bold transition-colors ${
                    activeTab === 'news'
                      ? 'border-t-2 border-cyan-400 bg-[#06111f] text-cyan-300'
                      : 'text-slate-400 hover:bg-white/[0.03] hover:text-slate-200'
                  }`}
                >
                  <Newspaper size={14} className="text-cyan-400" />
                  <span>Новости</span>
                </button>

                {/* Tab: Social */}
                <button
                  onClick={() => { setActiveTab('social'); soundManager.playCardClick(); }}
                  className={`flex items-center gap-1.5 rounded-t-lg px-3 py-2 text-xs font-bold transition-colors ${
                    activeTab === 'social'
                      ? 'border-t-2 border-cyan-400 bg-[#06111f] text-cyan-300'
                      : 'text-slate-400 hover:bg-white/[0.03] hover:text-slate-200'
                  }`}
                >
                  <Users size={14} className="text-cyan-400" />
                  <span>Сентимент</span>
                </button>

                {/* Tab: Position (if in_position) */}
                {currentScenario.tabs.positionHistory && (
                  <button
                    onClick={() => { setActiveTab('position'); soundManager.playCardClick(); }}
                    className={`flex items-center gap-1.5 rounded-t-lg px-3 py-2 text-xs font-bold transition-colors ${
                      activeTab === 'position'
                        ? 'border-t-2 border-amber-400 bg-[#06111f] text-amber-300'
                        : 'text-amber-400/70 hover:bg-white/[0.03] hover:text-amber-300'
                    }`}
                  >
                    <Briefcase size={14} className="text-amber-400" />
                    <span>Позиция</span>
                  </button>
                )}

              </div>

              <div className="hidden pb-2 font-mono text-[10px] text-slate-500 sm:block">
                Источников активно: 5
              </div>
            </div>

            {/* Browser Content Viewport */}
            <div className="p-4 sm:p-5">
              
              {/* TAB 1: Chart */}
              {activeTab === 'chart' && renderChart()}

              {/* TAB 2: On-Chain & Web3 */}
              {activeTab === 'onchain' && (
                <div className="space-y-4">
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="rounded-xl border border-white/10 bg-[#040a14] p-3.5">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Приток/Отток китов</span>
                      <p className="mt-1 font-mono text-sm font-bold text-red-400">{currentScenario.tabs.onChain.whaleExchangeFlow}</p>
                    </div>
                    <div className="rounded-xl border border-white/10 bg-[#040a14] p-3.5">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Биржевые резервы</span>
                      <p className="mt-1 font-mono text-sm font-bold text-amber-300">{currentScenario.tabs.onChain.exchangeReserveChange}</p>
                    </div>
                  </div>

                  <div className="rounded-xl border border-cyan-500/20 bg-[#040a14] p-4">
                    <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">Ключевые ончейн-транзакции & Смарт-контракты:</span>
                    <ul className="mt-2.5 space-y-2 text-xs text-slate-300">
                      {currentScenario.tabs.onChain.notableTransfers.map((tx, idx) => (
                        <li key={idx} className="flex items-start gap-2 font-mono">
                          <span className="text-cyan-400 font-bold">▶</span>
                          <span>{tx}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {/* TAB 3: Orderbook & Funding */}
              {activeTab === 'orderbook' && (
                <div className="space-y-4">
                  <div className="grid gap-3 sm:grid-cols-3">
                    <div className="rounded-xl border border-white/10 bg-[#040a14] p-3.5 text-center">
                      <span className="text-[10px] font-bold uppercase text-slate-400">Соотношение Bid/Ask</span>
                      <p className="mt-1 font-mono text-base font-black text-cyan-300">{currentScenario.tabs.orderBook.bidAskRatio}</p>
                    </div>
                    <div className="rounded-xl border border-white/10 bg-[#040a14] p-3.5 text-center">
                      <span className="text-[10px] font-bold uppercase text-slate-400">Ставка Funding (8h)</span>
                      <p className="mt-1 font-mono text-base font-black text-red-400">{currentScenario.tabs.orderBook.fundingRate}</p>
                    </div>
                    <div className="rounded-xl border border-white/10 bg-[#040a14] p-3.5 text-center">
                      <span className="text-[10px] font-bold uppercase text-slate-400">Открытый интерес (OI)</span>
                      <p className="mt-1 font-mono text-base font-black text-amber-300">{currentScenario.tabs.orderBook.openInterestTrend}</p>
                    </div>
                  </div>

                  <div className="rounded-xl border border-white/10 bg-[#040a14] p-4">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-300">Дисбаланс глубины стакана & Ликвидационные пулы:</span>
                    <p className="mt-2 text-xs leading-relaxed text-slate-400">{currentScenario.tabs.orderBook.liquidationWall}</p>
                    <p className="mt-1 text-xs leading-relaxed text-amber-300/90 font-mono">{currentScenario.tabs.orderBook.depthImbalance}</p>
                  </div>
                </div>
              )}

              {/* TAB 4: News & Narrative */}
              {activeTab === 'news' && (
                <div className="space-y-4">
                  <div className="rounded-xl border border-amber-500/30 bg-amber-500/[0.07] p-4">
                    <div className="flex items-center justify-between text-[11px] font-mono text-amber-300">
                      <span>Срочный заголовок</span>
                      <span className="rounded bg-amber-400/20 px-2 py-0.5 font-bold">
                        Надежность: {currentScenario.tabs.newsNarrative.sourceReliability}
                      </span>
                    </div>
                    <h3 className="mt-2 text-base font-bold text-white sm:text-lg">
                      {currentScenario.tabs.newsNarrative.mainHeadline}
                    </h3>
                  </div>

                  <div className="space-y-2">
                    {currentScenario.tabs.newsNarrative.articles.map((art, idx) => (
                      <div key={idx} className="flex items-center justify-between rounded-lg border border-white/5 bg-[#040a14] p-2.5 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="rounded bg-cyan-950 px-1.5 py-0.5 font-mono text-[9px] text-cyan-400 border border-cyan-500/20">{art.tag}</span>
                          <span className="text-slate-300">{art.title}</span>
                        </div>
                        <span className="font-mono text-[10px] text-slate-500">{art.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 5: Social Sentiment */}
              {activeTab === 'social' && (
                <div className="space-y-4">
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="rounded-xl border border-white/10 bg-[#040a14] p-4 text-center">
                      <span className="text-xs font-bold uppercase text-slate-400">Fear & Greed Index</span>
                      <div className="mt-2 flex items-center justify-center gap-2">
                        <span className="font-display text-3xl font-black text-amber-400">{currentScenario.tabs.socialFunding.fearGreedIndex}</span>
                        <span className="text-xs text-slate-400 font-mono">/ 100</span>
                      </div>
                      <span className="text-[10px] uppercase font-bold text-red-400">
                        {currentScenario.tabs.socialFunding.fearGreedIndex > 70 ? 'Экстремальная жадность' : 'Экстремальный страх'}
                      </span>
                    </div>

                    <div className="rounded-xl border border-white/10 bg-[#040a14] p-4 text-center">
                      <span className="text-xs font-bold uppercase text-slate-400">Long / Short Ratio</span>
                      <div className="mt-2 flex items-center justify-center gap-2">
                        <span className="font-display text-3xl font-black text-cyan-400">{currentScenario.tabs.socialFunding.longRatio}%</span>
                        <span className="text-xs text-slate-400 font-mono">Лонги</span>
                      </div>
                      <span className="text-[10px] uppercase font-bold text-amber-400">Толпа перегружена в одну сторону</span>
                    </div>
                  </div>

                  <div className="rounded-xl border border-white/10 bg-[#040a14] p-3.5">
                    <span className="text-[10px] font-bold uppercase text-slate-400">Настроения в X (Twitter) & Telegram:</span>
                    <p className="mt-1 text-xs italic text-slate-300">{currentScenario.tabs.socialFunding.twitterHype}</p>
                  </div>
                </div>
              )}

              {/* TAB 6: Position History */}
              {activeTab === 'position' && currentScenario.tabs.positionHistory && (
                <div className="space-y-4">
                  <div className="grid gap-3 sm:grid-cols-3">
                    <div className="rounded-xl border border-white/10 bg-[#040a14] p-3.5 text-center">
                      <span className="text-[10px] font-bold uppercase text-slate-400">Точка входа</span>
                      <p className="mt-1 font-mono text-base font-bold text-white">${currentScenario.tabs.positionHistory.entryPrice}</p>
                    </div>
                    <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-3.5 text-center">
                      <span className="text-[10px] font-bold uppercase text-red-400">Текущий PnL</span>
                      <p className="mt-1 font-mono text-base font-bold text-red-400">{currentScenario.tabs.positionHistory.currentUnrealizedPnL}</p>
                    </div>
                    <div className="rounded-xl border border-white/10 bg-[#040a14] p-3.5 text-center">
                      <span className="text-[10px] font-bold uppercase text-slate-400">Лимит риска</span>
                      <p className="mt-1 font-mono text-xs font-bold text-amber-300">{currentScenario.tabs.positionHistory.maxAllowedDrawdown}</p>
                    </div>
                  </div>

                  <div className="rounded-xl border border-amber-500/20 bg-[#040a14] p-4">
                    <span className="text-xs font-bold uppercase tracking-wider text-amber-300">Исходный тезис сделки:</span>
                    <p className="mt-1 text-xs text-slate-300">{currentScenario.tabs.positionHistory.initialPlan}</p>
                  </div>
                </div>
              )}

            </div>
          </div>

          {/* Equipped Skill Cards Carousel */}
          <div className="rounded-xl border border-white/10 bg-[#071322] p-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Layers size={16} className="text-cyan-400" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
                  Доступные карты навыков & Протоколы ({equippedCardsList.length})
                </span>
              </div>
              <span className="text-[10px] font-mono text-slate-500">Нажми на карту для подсказки</span>
            </div>

            <div className="mt-3 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
              {equippedCardsList.map((card) => {
                return (
                  <button
                    key={card.id}
                    onClick={() => {
                      setInspectedCardId(card.id);
                      soundManager.playCardClick();
                    }}
                    className={`group relative flex flex-col justify-between rounded-lg border p-2.5 text-left transition-all hover:scale-105 ${
                      card.tone === 'cyan'
                        ? 'border-cyan-500/40 bg-cyan-950/40 text-cyan-300 shadow-[0_0_12px_rgba(34,211,238,0.15)]'
                        : card.tone === 'amber'
                        ? 'border-amber-500/40 bg-amber-950/40 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.15)]'
                        : card.tone === 'violet'
                        ? 'border-violet-500/40 bg-violet-950/40 text-violet-300 shadow-[0_0_12px_rgba(168,85,247,0.15)]'
                        : 'border-emerald-500/40 bg-emerald-950/40 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.15)]'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[9px] font-black uppercase tracking-wider opacity-80">
                      <span>{card.categoryName}</span>
                      <span className="font-mono">★ {card.rarity[0]}</span>
                    </div>
                    <div className="my-1.5 font-display text-xs font-black uppercase leading-tight text-white group-hover:text-cyan-200">
                      {card.name}
                    </div>
                    <div className="text-[9px] font-mono text-slate-400 line-clamp-1">{card.bonus}</div>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: Active Entity Threat & 4 Decision Buttons */}
        <div className="space-y-6">
          
          {/* Active Threat Entity Showcase Card */}
          <div className="overflow-hidden rounded-xl border border-red-500/30 bg-gradient-to-b from-[#140b12] to-[#08101a] shadow-2xl">
            <div className="relative h-44 w-full overflow-hidden sm:h-52">
              <img
                src={activeEntity.image}
                alt={activeEntity.name}
                className="h-full w-full object-cover object-center transition-transform duration-700 hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#08101a] via-[#08101a]/40 to-transparent" />
              
              <div className="absolute top-3 left-3 rounded-md bg-red-950/80 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-red-300 border border-red-500/40">
                Угроза: Уровень {activeEntity.threatLevel}/100
              </div>
              
              <div className="absolute bottom-3 left-3 right-3">
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-red-400">{activeEntity.categoryLabel}</span>
                <h2 className="font-display text-xl font-black uppercase text-white sm:text-2xl drop-shadow-md">
                  {activeEntity.name}
                </h2>
                <div className="text-xs text-slate-300 drop-shadow">{activeEntity.title}</div>
              </div>
            </div>

            <div className="p-4 space-y-3">
              {/* Entity quote */}
              <blockquote className="rounded-lg border-l-2 border-red-400 bg-red-500/[0.06] p-2.5 text-xs italic text-red-200">
                {activeEntity.quote}
              </blockquote>

              {/* Active Protocol Warning */}
              <div className="rounded-lg border border-violet-500/30 bg-violet-500/10 p-3">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-violet-300">
                  <ShieldCheck size={16} />
                  <span>Активный Протокол: {currentScenario.activeProtocol.title}</span>
                </div>
                <p className="mt-1 text-xs text-slate-300">
                  {currentScenario.activeProtocol.rule}
                </p>
              </div>
            </div>
          </div>

          {/* 4 Standard Decision Buttons */}
          <div className="rounded-xl border border-white/10 bg-[#071322] p-4 sm:p-5 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">
                Выбери действие по системе (4 варианта)
              </span>
              <span className="font-mono text-[10px] text-slate-500">PQS Оценка</span>
            </div>

            <div className="mt-4 space-y-2.5">
              {currentScenario.decisions.map((dec, idx) => {
                const isSelected = selectedDecision?.id === dec.id;
                return (
                  <button
                    key={dec.id}
                    disabled={isRevealed}
                    onClick={() => handleDecisionClick(dec)}
                    className={`w-full rounded-xl border p-3 text-left transition-all ${
                      isSelected
                        ? isRevealed
                          ? dec.processScore >= 80
                            ? 'border-emerald-400 bg-emerald-950/70 text-emerald-200 shadow-[0_0_20px_rgba(52,211,153,0.3)]'
                            : 'border-red-500 bg-red-950/70 text-red-200 shadow-[0_0_20px_rgba(239,68,68,0.3)]'
                          : 'border-cyan-400 bg-cyan-950/70 text-white shadow-[0_0_15px_rgba(34,211,238,0.3)]'
                        : isRevealed
                        ? 'border-white/5 bg-white/[0.02] text-slate-500 opacity-50'
                        : 'border-white/10 bg-white/[0.03] text-slate-200 hover:border-cyan-400/40 hover:bg-white/[0.06]'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`grid h-6 w-6 shrink-0 place-items-center rounded font-mono text-xs font-bold ${
                        isSelected ? 'bg-cyan-400 text-slate-950' : 'bg-white/10 text-slate-300'
                      }`}>
                        {String.fromCharCode(65 + idx)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="font-bold text-sm text-white">{dec.title}</div>
                        <div className="mt-0.5 text-xs text-slate-400">{dec.subtitle}</div>
                      </div>
                      {isRevealed && isSelected && (
                        <div className="font-mono text-xs font-black">
                          {dec.processScore >= 80 ? (
                            <span className="text-emerald-400">+{dec.processScore} PQS</span>
                          ) : (
                            <span className="text-red-400">{dec.processScore} PQS</span>
                          )}
                        </div>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Optional Step 2 (if present) */}
            {currentScenario.secondStep && !isRevealed && (
              <div className="mt-4 rounded-xl border border-cyan-500/30 bg-cyan-950/30 p-3.5">
                <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-300">
                  Второй шаг: {currentScenario.secondStep.prompt}
                </span>
                <div className="mt-2 space-y-1.5">
                  {currentScenario.secondStep.options.map((opt) => (
                    <button
                      key={opt.id}
                      onClick={() => {
                        setSelectedSecondStep(opt.id);
                        soundManager.playCardClick();
                      }}
                      className={`w-full rounded-lg border px-3 py-2 text-left text-xs transition-all ${
                        selectedSecondStep === opt.id
                          ? 'border-cyan-400 bg-cyan-900/60 text-cyan-200 font-bold'
                          : 'border-white/10 bg-[#040a14] text-slate-300 hover:border-white/20'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Action Bar: Submit or Reveal */}
            {!isRevealed ? (
              <button
                disabled={!selectedDecision}
                onClick={handleReveal}
                className="primary-button mt-5 w-full justify-center disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <Play size={16} fill="currentColor" />
                <span>Зафиксировать решение & Раскрыть рынок</span>
              </button>
            ) : (
              <div className="mt-4 flex gap-2">
                <button
                  onClick={resetCurrent}
                  className="secondary-button flex-1 justify-center text-xs"
                >
                  Повторить сценарий
                </button>
                <button
                  onClick={handleNextScenario}
                  className="primary-button flex-1 justify-center text-xs"
                >
                  Следующий кейс <Zap size={15} />
                </button>
              </div>
            )}

          </div>

        </div>

      </div>

      {/* 3-LAYER RESULT REVEAL MODAL / BOTTOM EXPANDER */}
      <AnimatePresence>
        {isRevealed && selectedDecision && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 30 }}
            className="mt-8 rounded-2xl border border-cyan-400/40 bg-gradient-to-b from-[#08182b] to-[#040c16] p-5 sm:p-8 shadow-[0_0_50px_rgba(34,211,238,0.15)]"
          >
            {/* Header of Results */}
            <div className="flex flex-col justify-between gap-4 border-b border-white/10 pb-6 sm:flex-row sm:items-center">
              <div>
                <div className="flex items-center gap-2">
                  {selectedDecision.processScore >= 80 ? (
                    <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/20 px-3 py-1 font-mono text-xs font-black text-emerald-300 border border-emerald-500/40">
                      <CheckCircle2 size={15} /> ПРЕВОСХОДНЫЙ ПРОЦЕСС
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5 rounded-full bg-red-500/20 px-3 py-1 font-mono text-xs font-black text-red-300 border border-red-500/40">
                      <XCircle size={15} /> ЛОВУШКА МЫШЛЕНИЯ
                    </span>
                  )}
                  <span className="font-mono text-xs text-slate-400">
                    Дата: {currentScenario.historicalFact.date}
                  </span>
                </div>
                <h2 className="font-display mt-2 text-2xl font-black uppercase text-white sm:text-3xl">
                  Разбор решения: {selectedDecision.title}
                </h2>
              </div>

              {/* PQS Score Pill */}
              <div className="flex items-center gap-4 rounded-xl border border-white/10 bg-[#040a14] p-3 text-right">
                <div>
                  <div className="text-[10px] uppercase font-bold text-slate-400">Качество решения (PQS)</div>
                  <div className="font-display text-3xl font-black text-cyan-300">
                    {selectedDecision.processScore} <span className="text-sm text-slate-500">/ 100</span>
                  </div>
                </div>
                <div className="grid h-12 w-12 place-items-center rounded-lg bg-cyan-400/10 text-cyan-400">
                  <Award size={26} />
                </div>
              </div>
            </div>

            {/* 3 Feedback Layers */}
            <div className="mt-6 grid gap-5 lg:grid-cols-3">
              
              {/* Layer 1: Historical Fact */}
              <div className="rounded-xl border border-white/10 bg-[#06111f] p-4">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-400">
                  <TrendingUp size={16} />
                  <span>1. Реальный исторический факт</span>
                </div>
                <p className="mt-2 text-xs font-medium leading-relaxed text-slate-200">
                  {currentScenario.historicalFact.whatHappened}
                </p>
                <div className="mt-3 font-mono text-xs font-bold text-amber-300">
                  Движение: {currentScenario.historicalFact.actualPriceMove}
                </div>
                <div className="mt-1 text-[10px] text-slate-500">
                  Источник: {currentScenario.historicalFact.verifiedSource}
                </div>
              </div>

              {/* Layer 2: Long-Term Consequence */}
              <div className="rounded-xl border border-white/10 bg-[#06111f] p-4">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-300">
                  <BarChart3 size={16} />
                  <span>2. Последствие на дистанции</span>
                </div>
                <p className="mt-2 text-xs font-medium leading-relaxed text-slate-200">
                  {selectedDecision.explanation}
                </p>
                <div className="mt-3 rounded bg-white/[0.03] p-2 text-[11px] text-slate-400">
                  Правило: Оценка не зависит от того, повезло ли вам в отдельной сделке. Оценивается устойчивость мат. ожидания на 100 повторений.
                </div>
              </div>

              {/* Layer 3: Main Learning Takeaway */}
              <div className="rounded-xl border border-cyan-500/30 bg-cyan-950/40 p-4">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-300">
                  <Crown size={16} />
                  <span>3. Переносимый принцип</span>
                </div>
                <p className="mt-2 text-xs font-medium leading-relaxed text-cyan-100">
                  {currentScenario.learningTakeaway}
                </p>
                <div className="mt-4 flex items-center justify-between border-t border-cyan-500/20 pt-2 text-xs text-amber-300 font-mono">
                  <span>+140 XP опыта</span>
                  <span>+60 💎 Кристаллов</span>
                </div>
              </div>

            </div>

            {/* Bottom Actions */}
            <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-4">
              <button
                onClick={() => soundManager.playSuccessChime()}
                className="flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-white"
              >
                <Share2 size={15} />
                <span>Поделиться качеством решения в Лиге Аналитиков</span>
              </button>

              <button
                onClick={handleNextScenario}
                className="primary-button"
              >
                <span>Перейти к следующему испытанию</span>
                <Play size={15} fill="currentColor" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Card Inspection Modal */}
      <AnimatePresence>
        {inspectedCard && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md rounded-2xl border border-cyan-400/40 bg-[#081524] p-6 shadow-2xl"
            >
              <div className="flex items-start justify-between">
                <span className="rounded-full bg-cyan-950 px-3 py-0.5 text-[10px] font-mono font-bold uppercase text-cyan-400 border border-cyan-500/30">
                  {inspectedCard.categoryName} • {inspectedCard.rarity}
                </span>
                <button onClick={() => setInspectedCardId(null)} className="text-slate-400 hover:text-white">
                  ✕
                </button>
              </div>

              <h3 className="font-display mt-3 text-2xl font-black uppercase text-white">
                {inspectedCard.name}
              </h3>

              <p className="mt-2 text-sm text-slate-300 leading-relaxed">
                {inspectedCard.description}
              </p>

              <div className="mt-4 rounded-xl border border-white/10 bg-[#040a14] p-3 text-xs space-y-1.5">
                <div className="text-cyan-300 font-bold">Крипто-принцип:</div>
                <div className="text-slate-300">{inspectedCard.principle}</div>
                <div className="mt-2 text-amber-300 font-bold">Применение в реальном рынке:</div>
                <div className="text-slate-400">{inspectedCard.cryptoContext}</div>
              </div>

              <blockquote className="mt-4 rounded border-l-2 border-cyan-400 bg-cyan-500/[0.06] p-2.5 text-xs italic text-cyan-200">
                {inspectedCard.flavorQuote}
              </blockquote>

              <button
                onClick={() => setInspectedCardId(null)}
                className="primary-button mt-5 w-full justify-center"
              >
                Понятно
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
