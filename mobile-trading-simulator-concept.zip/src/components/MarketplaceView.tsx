import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ShoppingBag,
  Crown,
  Sparkles,
  CheckCircle2,
  Gem,
  Coins,
  ShieldCheck,
  Cpu
} from 'lucide-react';
import { marketplaceItems, gameFi20Manifesto } from '../data/tournaments';
import { MarketItem, PlayerProfile } from '../types/game';
import { soundManager } from '../utils/audio';

interface MarketplaceViewProps {
  profile: PlayerProfile;
  onUpdateProfile: (updated: Partial<PlayerProfile>) => void;
}

export function MarketplaceView({ profile, onUpdateProfile }: MarketplaceViewProps) {
  const [activeTab, setActiveTab] = useState<'pro' | 'themes' | 'campaigns' | 'manifesto'>('pro');
  const [purchasedModal, setPurchasedModal] = useState<MarketItem | null>(null);

  const handleBuy = (item: MarketItem) => {
    soundManager.playSuccessChime();
    setPurchasedModal(item);
    if (item.id === 'pass_pro_annual') {
      onUpdateProfile({ isPremium: true });
    } else if (item.currency === 'crystals') {
      onUpdateProfile({ crystals: Math.max(0, profile.crystals - item.price) });
    } else if (item.currency === 'tokens') {
      onUpdateProfile({ arenaTokens: Math.max(0, profile.arenaTokens - item.price) });
    }
  };

  return (
    <div className="mx-auto max-w-[1520px] px-3 py-6 sm:px-6">
      
      {/* Header Banner */}
      <div className="mb-6 flex flex-col justify-between gap-4 rounded-2xl border border-amber-500/20 bg-gradient-to-r from-amber-950/40 via-[#071322] to-[#141208] p-5 sm:p-6 shadow-xl md:flex-row md:items-center">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 rounded-full bg-amber-500/20 px-3 py-0.5 text-[10px] font-mono font-bold uppercase tracking-wider text-amber-300 border border-amber-500/30">
              <ShoppingBag size={14} /> Маркетплейс & GameFi 2.0 Экосистема
            </span>
          </div>
          <h1 className="font-display mt-2 text-2xl font-black uppercase tracking-tight text-white sm:text-3xl">
            Магазин Аналитика & Манифест GameFi 2.0
          </h1>
          <p className="mt-1 text-xs text-slate-300 sm:text-sm">
            Платные опции расширяют возможности и дают уникальную кастомизацию, но никогда не продают правильные ответы или торговые преимущества.
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex flex-wrap gap-1.5 rounded-xl border border-white/10 bg-[#040a14] p-1">
          {[
            { id: 'pro', label: 'PRO Pass' },
            { id: 'themes', label: 'Темы & Оформление' },
            { id: 'campaigns', label: 'Пакеты Кампаний' },
            { id: 'manifesto', label: 'GameFi 2.0 Манифест' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as typeof activeTab);
                soundManager.playCardClick();
              }}
              className={`rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
                activeTab === tab.id
                  ? 'bg-amber-400 text-slate-950 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: PRO PASS Showcase */}
      {activeTab === 'pro' && (
        <div className="grid gap-6 lg:grid-cols-[1.3fr_1fr]">
          <div className="rounded-2xl border border-amber-400/40 bg-gradient-to-br from-[#1c140a] via-[#0b1424] to-[#071322] p-6 sm:p-8 shadow-2xl">
            <div className="flex items-center gap-2 text-amber-400 font-mono text-xs font-bold uppercase tracking-wider">
              <Crown size={18} />
              <span>SIGNAL ARENA PRO PASS</span>
            </div>

            <h2 className="font-display mt-3 text-3xl font-black uppercase text-white sm:text-4xl">
              Институциональный уровень подготовки
            </h2>

            <p className="mt-2 text-sm text-slate-300 leading-relaxed">
              Разблокируй полный архив из 100+ исторических крипто-кризисов, продвинутые ончейн-разборы от реальных фондов, закрытые турниры и статус Verified Analyst.
            </p>

            <div className="mt-6 space-y-3 border-y border-white/10 py-5 text-xs text-slate-200">
              {[
                'Неограниченный доступ ко всем закрытым кампаниям (2011–2025)',
                'Глубокий аудит когнитивных искажений и персональный ИИ-разбор ошибок',
                'Участие в закрытых Pro-турнирах с крупными призовыми фондами',
                'Золотая рамка профиля, анимация радара и VIP статус в таблице лидеров',
                'Soulbound сертификат подтвержденной торговой дисциплины (GameFi 2.0)'
              ].map((feature, idx) => (
                <div key={idx} className="flex items-start gap-2.5">
                  <CheckCircle2 size={16} className="text-amber-400 shrink-0 mt-0.5" />
                  <span className="leading-snug">{feature}</span>
                </div>
              ))}
            </div>

            <div className="mt-6 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400">Стоимость подписки:</span>
                <div className="font-display text-2xl font-black text-amber-300">$9.99 / месяц</div>
              </div>

              <button
                onClick={() => handleBuy(marketplaceItems[0])}
                className="primary-button"
              >
                <Crown size={16} fill="currentColor" />
                <span>{profile.isPremium ? 'PRO Pass Активен' : 'Оформить PRO Pass'}</span>
              </button>
            </div>
          </div>

          <div className="space-y-4">
            <div className="rounded-2xl border border-white/10 bg-[#071322] p-6 shadow-xl">
              <h3 className="font-display text-lg font-black uppercase text-white">
                Гарантии прозрачности монетизации
              </h3>
              <p className="mt-2 text-xs leading-relaxed text-slate-400">
                В Signal Arena действует жесткий кодекс: мы никогда не продаем торговые сигналы, покупку правильных ответов в сценариях или преимущество над другими игроками. PRO Pass расширяет учебный материал и эстетику, сохраняя честность соревнований.
              </p>
            </div>

            <div className="rounded-2xl border border-cyan-500/20 bg-cyan-950/20 p-5 text-xs text-cyan-200 space-y-2">
              <div className="font-bold flex items-center gap-1.5 text-cyan-300">
                <ShieldCheck size={16} />
                <span>Признание Pro-профилей</span>
              </div>
              <p className="text-slate-300 leading-relaxed">
                Топ-100 игроков рейтинга Signal Arena регулярно приглашаются на собеседования в партнерские проп-трейдинговые криптофонды без прохождения базовых тестов.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Themes & Cosmetics */}
      {activeTab === 'themes' && (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {marketplaceItems.filter((i) => i.category === 'profile_theme' || i.category === 'avatar').map((item) => (
            <div
              key={item.id}
              className="flex flex-col justify-between rounded-2xl border border-white/10 bg-[#071322] p-5 shadow-xl transition-all hover:border-cyan-400/40"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="rounded bg-white/10 px-2 py-0.5 font-mono text-[10px] font-bold text-white">
                    {item.rarity}
                  </span>
                  <div className="flex items-center gap-1 font-mono text-xs font-bold text-violet-400">
                    <Gem size={13} fill="currentColor" />
                    <span>{item.price}</span>
                  </div>
                </div>

                <div className="my-4 grid place-items-center">
                  <div className="grid h-16 w-16 place-items-center rounded-2xl border border-cyan-500/30 bg-cyan-950/40 text-cyan-300 shadow-[0_0_20px_rgba(34,211,238,0.2)]">
                    <Sparkles size={28} />
                  </div>
                </div>

                <h3 className="font-display text-lg font-black uppercase text-white">
                  {item.name}
                </h3>
                <p className="mt-1 text-xs text-slate-400 leading-relaxed">
                  {item.description}
                </p>

                <ul className="mt-3 space-y-1 text-[11px] text-slate-300 border-t border-white/5 pt-2">
                  {item.features.map((f, idx) => (
                    <li key={idx} className="flex items-center gap-1.5">
                      <span className="text-cyan-400">✓</span>
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-5">
                {item.isOwned ? (
                  <button disabled className="secondary-button w-full justify-center text-xs opacity-60 cursor-default">
                    Уже в инвентаре
                  </button>
                ) : (
                  <button
                    onClick={() => handleBuy(item)}
                    className="primary-button w-full justify-center text-xs"
                  >
                    <span>Купить за {item.price} 💎</span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 3: Campaign Packs */}
      {activeTab === 'campaigns' && (
        <div className="grid gap-5 sm:grid-cols-2">
          {marketplaceItems.filter((i) => i.category === 'campaign_pack').map((item) => (
            <div
              key={item.id}
              className="flex flex-col justify-between rounded-2xl border border-white/10 bg-[#071322] p-6 shadow-xl"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="rounded bg-cyan-950 px-2.5 py-0.5 font-mono text-[10px] font-bold text-cyan-300 border border-cyan-500/30">
                    Тематический пак сценариев
                  </span>
                  <div className="flex items-center gap-1 font-mono text-xs font-bold text-cyan-300">
                    <Coins size={14} />
                    <span>{item.price} Токенов</span>
                  </div>
                </div>

                <h3 className="font-display mt-3 text-2xl font-black uppercase text-white">
                  {item.name}
                </h3>
                <p className="mt-2 text-xs leading-relaxed text-slate-300">
                  {item.description}
                </p>

                <div className="mt-4 rounded-xl border border-white/5 bg-[#040a14] p-3 text-xs space-y-1.5">
                  {item.features.map((f, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-slate-300">
                      <span className="text-amber-400 font-bold">★</span>
                      <span>{f}</span>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={() => handleBuy(item)}
                className="primary-button mt-6 w-full justify-center"
              >
                <span>Разблокировать пак ({item.price} 🪙)</span>
              </button>
            </div>
          ))}
        </div>
      )}

      {/* TAB 4: GameFi 2.0 Manifesto */}
      {activeTab === 'manifesto' && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-cyan-500/30 bg-gradient-to-br from-[#06182c] via-[#071322] to-[#0d1624] p-6 sm:p-8 shadow-2xl">
            <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs font-bold uppercase tracking-wider">
              <Cpu size={16} />
              <span>WHITE PAPER • СТАНДАРТ GAMEFI 2.0</span>
            </div>

            <h2 className="font-display mt-2 text-2xl font-black uppercase text-white sm:text-3xl">
              {gameFi20Manifesto.title}
            </h2>
            <p className="mt-1 text-sm text-cyan-200">
              {gameFi20Manifesto.subtitle}
            </p>

            <div className="mt-6 space-y-5">
              {gameFi20Manifesto.pillars.map((pillar, idx) => (
                <div key={idx} className="rounded-xl border border-white/10 bg-[#040a14] p-4 sm:p-5">
                  <h3 className="font-bold text-base text-amber-300">{pillar.heading}</h3>
                  <p className="mt-2 text-xs leading-relaxed text-slate-300 sm:text-sm">
                    {pillar.body}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Purchase Success Modal */}
      <AnimatePresence>
        {purchasedModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md rounded-2xl border border-emerald-400/40 bg-[#081524] p-6 text-center shadow-2xl"
            >
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-emerald-500/20 text-emerald-400">
                <CheckCircle2 size={32} />
              </div>
              <h3 className="font-display mt-3 text-2xl font-black uppercase text-white">
                Покупка успешна!
              </h3>
              <p className="mt-2 text-xs text-slate-300">
                Товар «{purchasedModal.name}» успешно активирован в вашем профиле Signal Arena.
              </p>
              <button
                onClick={() => setPurchasedModal(null)}
                className="primary-button mt-6 w-full justify-center"
              >
                Отлично
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
