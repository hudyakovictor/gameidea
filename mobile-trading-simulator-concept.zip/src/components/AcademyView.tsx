import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  CheckCircle2,
  Play,
  HelpCircle,
  Clock,
  ChevronRight,
  GraduationCap
} from 'lucide-react';
import { academyLessons } from '../data/academy';
import { AcademyLesson } from '../types/game';
import { soundManager } from '../utils/audio';

interface AcademyViewProps {
  onStartScenarioFromLesson?: (scenarioId: string) => void;
}

export function AcademyView({ onStartScenarioFromLesson }: AcademyViewProps) {
  const [selectedLesson, setSelectedLesson] = useState<AcademyLesson | null>(null);
  const [activeQuizAnswer, setActiveQuizAnswer] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'basics' | 'structure' | 'onchain' | 'risk' | 'psychology' | 'institutional'>('all');

  const filteredLessons = academyLessons.filter(
    (l) => categoryFilter === 'all' || l.category === categoryFilter
  );

  const handleOpenLesson = (lesson: AcademyLesson) => {
    soundManager.playCardClick();
    setSelectedLesson(lesson);
    setActiveQuizAnswer(null);
    setQuizSubmitted(false);
  };

  const handleSelectQuiz = (index: number) => {
    if (quizSubmitted) return;
    soundManager.playDecisionSelect();
    setActiveQuizAnswer(index);
  };

  const handleSubmitQuiz = () => {
    if (activeQuizAnswer === null) return;
    setQuizSubmitted(true);
    const isCorrect = selectedLesson?.quiz.options[activeQuizAnswer]?.isCorrect;
    if (isCorrect) {
      soundManager.playSuccessChime();
    } else {
      soundManager.playThreatAlert();
    }
  };

  return (
    <div className="mx-auto max-w-[1520px] px-3 py-6 sm:px-6">
      
      {/* Header Banner */}
      <div className="mb-6 flex flex-col justify-between gap-4 rounded-2xl border border-cyan-500/20 bg-gradient-to-r from-cyan-950/40 via-[#071322] to-[#0a1b2d] p-5 sm:p-6 shadow-xl md:flex-row md:items-center">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 rounded-full bg-cyan-500/20 px-3 py-0.5 text-[10px] font-mono font-bold uppercase tracking-wider text-cyan-300 border border-cyan-500/30">
              <GraduationCap size={14} /> Академия Трейдинга • Duolingo Модель
            </span>
            <span className="rounded bg-amber-500/20 px-2 py-0.5 text-[10px] font-bold text-amber-300">
              Lv. 1 – 99 Pro
            </span>
          </div>
          <h1 className="font-display mt-2 text-2xl font-black uppercase tracking-tight text-white sm:text-3xl">
            Древо знаний: от стакана до институционалов
          </h1>
          <p className="mt-1 text-xs text-slate-300 sm:text-sm">
            Короткие 5-минутные модули. Теория объясняет принцип, сценарии на Арене проверяют навык под давлением.
          </p>
        </div>

        {/* Level Filters */}
        <div className="flex flex-wrap gap-1.5">
          {[
            { id: 'all', label: 'Все ветки' },
            { id: 'basics', label: 'Стакан & База' },
            { id: 'structure', label: 'Структура' },
            { id: 'onchain', label: 'On-Chain' },
            { id: 'risk', label: 'Риск (EV)' },
            { id: 'psychology', label: 'Психология' },
            { id: 'institutional', label: 'Smart Money' }
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setCategoryFilter(cat.id as typeof categoryFilter);
                soundManager.playCardClick();
              }}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-bold transition-all ${
                categoryFilter === cat.id
                  ? 'bg-cyan-400 text-slate-950 shadow-[0_0_12px_rgba(34,211,238,0.4)]'
                  : 'border border-white/10 bg-white/[0.03] text-slate-400 hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Lesson Modules Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filteredLessons.map((lesson) => {
          return (
            <motion.div
              key={lesson.id}
              whileHover={{ y: -3 }}
              onClick={() => handleOpenLesson(lesson)}
              className="group cursor-pointer rounded-2xl border border-white/10 bg-[#071322] p-5 shadow-lg transition-all hover:border-cyan-400/50 hover:bg-[#08182b]"
            >
              <div className="flex items-center justify-between">
                <span className="rounded bg-cyan-950/80 px-2 py-0.5 font-mono text-[10px] font-bold text-cyan-400 border border-cyan-500/20">
                  Уровень {lesson.level}
                </span>
                <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
                  <Clock size={13} />
                  <span>{lesson.estimatedMinutes} мин</span>
                  {lesson.isCompleted && <CheckCircle2 size={16} className="text-emerald-400 ml-1" />}
                </div>
              </div>

              <h3 className="font-display mt-3 text-lg font-black uppercase text-white group-hover:text-cyan-200">
                {lesson.title}
              </h3>

              <p className="mt-2 text-xs text-slate-400 line-clamp-2 leading-relaxed">
                {lesson.summary}
              </p>

              <div className="mt-4 flex items-center justify-between border-t border-white/5 pt-3 text-xs">
                <span className="font-mono font-bold text-amber-300">+{lesson.xpReward} XP</span>
                <span className="flex items-center gap-1 text-cyan-400 font-bold group-hover:translate-x-1 transition-transform">
                  <span>Изучить</span>
                  <ChevronRight size={14} />
                </span>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Interactive Lesson Modal Viewer */}
      <AnimatePresence>
        {selectedLesson && (
          <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/85 p-3 sm:p-6 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative my-8 w-full max-w-3xl rounded-2xl border border-cyan-500/40 bg-[#081524] p-5 sm:p-8 shadow-2xl"
            >
              <button
                onClick={() => setSelectedLesson(null)}
                className="absolute top-4 right-4 grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/5 text-slate-400 hover:text-white"
              >
                ✕
              </button>

              {/* Lesson Header */}
              <div className="flex items-center gap-2">
                <span className="rounded bg-cyan-950 px-2.5 py-0.5 font-mono text-xs font-bold text-cyan-400 border border-cyan-500/30">
                  {selectedLesson.treeName} • Lv. {selectedLesson.level}
                </span>
                <span className="font-mono text-xs text-amber-300">+{selectedLesson.xpReward} XP</span>
              </div>

              <h2 className="font-display mt-2 text-2xl font-black uppercase text-white sm:text-3xl">
                {selectedLesson.title}
              </h2>

              {/* Theory Sections */}
              <div className="mt-6 space-y-5 text-slate-200">
                {selectedLesson.theorySections.map((sec, i) => (
                  <div key={i} className="rounded-xl border border-white/10 bg-[#040a14] p-4 sm:p-5">
                    <h3 className="font-bold text-base text-cyan-300">{sec.heading}</h3>
                    <p className="mt-2 text-xs leading-relaxed text-slate-300 sm:text-sm">
                      {sec.body}
                    </p>

                    {sec.bulletPoints && (
                      <ul className="mt-3 space-y-1.5 border-t border-white/5 pt-3 text-xs text-slate-400">
                        {sec.bulletPoints.map((pt, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="text-cyan-400">✓</span>
                            <span>{pt}</span>
                          </li>
                        ))}
                      </ul>
                    )}

                    {sec.diagramNote && (
                      <div className="mt-3 rounded-lg border border-amber-500/30 bg-amber-500/10 p-2.5 text-xs font-mono text-amber-200">
                        {sec.diagramNote}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Interactive Micro-Quiz */}
              <div className="mt-6 rounded-xl border border-cyan-500/30 bg-gradient-to-br from-cyan-950/40 to-[#06101c] p-5">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-300">
                  <HelpCircle size={16} />
                  <span>Проверочный вопрос на понимание принципа:</span>
                </div>
                <h4 className="mt-2 text-sm font-bold text-white sm:text-base">
                  {selectedLesson.quiz.question}
                </h4>

                <div className="mt-4 space-y-2">
                  {selectedLesson.quiz.options.map((opt, optIdx) => {
                    const isSelected = activeQuizAnswer === optIdx;
                    return (
                      <button
                        key={optIdx}
                        disabled={quizSubmitted}
                        onClick={() => handleSelectQuiz(optIdx)}
                        className={`w-full rounded-xl border p-3 text-left text-xs sm:text-sm transition-all ${
                          isSelected
                            ? quizSubmitted
                              ? opt.isCorrect
                                ? 'border-emerald-400 bg-emerald-950/80 text-emerald-200 font-bold'
                                : 'border-red-500 bg-red-950/80 text-red-200'
                              : 'border-cyan-400 bg-cyan-900/60 text-white font-bold'
                            : quizSubmitted && opt.isCorrect
                            ? 'border-emerald-400/60 bg-emerald-950/40 text-emerald-300'
                            : 'border-white/10 bg-[#040a14] text-slate-300 hover:border-white/20'
                        }`}
                      >
                        <div className="flex items-start gap-2.5">
                          <span className="font-mono text-xs font-bold text-slate-500">{String.fromCharCode(65 + optIdx)}.</span>
                          <span>{opt.text}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Quiz Feedback */}
                {quizSubmitted && activeQuizAnswer !== null && (
                  <div className="mt-4 rounded-lg border border-white/10 bg-[#040a14] p-3 text-xs">
                    <div className="font-bold text-slate-200">
                      {selectedLesson.quiz.options[activeQuizAnswer]?.isCorrect ? '✅ Верно!' : '❌ Ошибка мышления:'}
                    </div>
                    <p className="mt-1 text-slate-400">
                      {selectedLesson.quiz.options[activeQuizAnswer]?.feedback}
                    </p>
                  </div>
                )}

                {/* Submit Quiz button */}
                {!quizSubmitted ? (
                  <button
                    disabled={activeQuizAnswer === null}
                    onClick={handleSubmitQuiz}
                    className="primary-button mt-4 w-full justify-center disabled:opacity-40"
                  >
                    <span>Проверить ответ</span>
                  </button>
                ) : (
                  <div className="mt-4 flex gap-2">
                    <button
                      onClick={() => {
                        setSelectedLesson(null);
                        if (onStartScenarioFromLesson) {
                          onStartScenarioFromLesson(selectedLesson.linkedScenarioId);
                        }
                      }}
                      className="primary-button flex-1 justify-center text-xs"
                    >
                      <Play size={14} fill="currentColor" />
                      <span>Закрепить на Арене</span>
                    </button>
                  </div>
                )}
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
