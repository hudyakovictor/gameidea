import { MarketEntity } from '../types/game';

export const marketEntities: MarketEntity[] = [
  {
    id: 'entity_leverage_goblin',
    name: 'Leverage Goblin',
    title: 'Гоблин 100x Плеча & Ликвидаций',
    category: 'risk',
    categoryLabel: 'Риск и Позиция',
    image: '/images/entity-leverage-goblin.jpg',
    threatLevel: 92,
    cognitiveTrap: 'Жадность, иллюзия быстрого богатства и недооценка математики ликвидаций.',
    marketBehavior: 'Шепчет трейдеру: «Зачем брать 2x плечо, если можно взять 100x и стать миллионером за вечер?». Атакует в моменты эйфории и заставляет открывать сделки без стопа на весь депозит.',
    counterMeasures: [
      'Расчет точного долларового риска на сделку (не более 1-2% от депозита)',
      'Использование изолированной маржи с жестким защитным стоп-ордером',
      'Протокол «Risk-First Mode» и карта «Don\'t Average Losers»'
    ],
    recommendedCards: ['proto_risk_first_mode', 'dec_risk_first_then_entry', 'def_daily_risk_limit'],
    quote: '«Давай, нажми 100x! Один зеленый импульс — и ты на яхте! А стоп-лосс придумали трусы!»',
    defeatedCount: 1420
  },
  {
    id: 'entity_fomo_wraith',
    name: 'FOMO Wraith',
    title: 'Призрак Упущенной Выгоды (ATH Pump)',
    category: 'emotions',
    categoryLabel: 'Эмоции и Поведение',
    image: '/images/entity-fomo-wraith.jpg',
    threatLevel: 88,
    cognitiveTrap: 'Страх остаться в стороне (Fear Of Missing Out), социальное давление, зависть к чужой прибыли.',
    marketBehavior: 'Появляется, когда токен уже вырос на 500% и летит вертикально вверх. Заставляет залетать на самом пике свечи по маркету прямо перед институциональной фиксацией прибыли.',
    counterMeasures: [
      'Осознание, что упущенная прибыль — это не реальный убыток',
      'Запрет на покупки при Extreme Greed (индекс жадности > 80)',
      'Протокол «Anti-FOMO» и ожидание глубокого ретеста структуры'
    ],
    recommendedCards: ['proto_anti_fomo', 'def_dont_chase', 'def_fomo_control', 'dec_staying_out_decision'],
    quote: '«Все твои друзья уже заработали 10 иксов, а ты сидишь в стейблах! Залетай прямо сейчас, иначе останешься ни с чем!»',
    defeatedCount: 2180
  },
  {
    id: 'entity_headline_titan',
    name: 'Headline Titan',
    title: 'Титан Инфошума & FUD-Паники',
    category: 'noise',
    categoryLabel: 'Инфошум и Нарративы',
    image: '/images/entity-headline-titan.jpg',
    threatLevel: 85,
    cognitiveTrap: 'Реактивность на заголовки, паника толпы, неспособность фильтровать первоисточники.',
    marketBehavior: 'Соткан из кричащих заголовков: «КРИПТА ВСЁ! БАНКРОТСТВО! ЗАПРЕТ!». Внушает ужас и заставляет продавать активы на самом дне капитуляции прямо в руки умных денег.',
    counterMeasures: [
      'Проверка транзакций в ончейне (покупают или продают киты на самом деле)',
      'Протокол «Noise Quarantine» и отключение алертов новостных каналов',
      'Сверка с картой «News is Not a Signal»'
    ],
    recommendedCards: ['proto_noise_quarantine', 'def_news_not_signal', 'read_onchain_web3', 'proto_evidence_only'],
    quote: '«ВСЁ ПОТЕРЯНО! ЛИКВИДАЦИЯ ВСЕЙ ИНДУСТРИИ! СРОЧНО СЛИВАЙ В МИНУС, ПОКА НЕ ПОЗДНО!»',
    defeatedCount: 1750
  },
  {
    id: 'entity_pattern_phantom',
    name: 'Pattern Phantom',
    title: 'Фантом Ложного Пробоя (Smart Money Trap)',
    category: 'signals',
    categoryLabel: 'Структура и Сигналы',
    image: '/images/entity-pattern-phantom.jpg',
    threatLevel: 79,
    cognitiveTrap: 'Слепая вера в простые графические фигуры из учебников без учета ликвидности и объемов.',
    marketBehavior: 'Рисует идеальный треугольник или уровень сопротивления, заманивает розничных трейдеров в пробой, а затем снимает их стоп-лоссы резким движением в противоположную сторону.',
    counterMeasures: [
      'Поиск подтверждения истинного объема и дельты покупок/продаж',
      'Ожидание закрепления (Close) свечи на старшем таймфрейме',
      'Использование карт «Volume & Liquidity» и «No Confirmation, No Trade»'
    ],
    recommendedCards: ['read_volume_liquidity', 'read_market_structure', 'dec_no_confirmation_no_trade'],
    quote: '«Смотри, какой красивый флаг! Просто нажми бай, фигуры теханализа никогда не врут... хе-хе.»',
    defeatedCount: 3100
  },
  {
    id: 'entity_rug_pull_phantom',
    name: 'Rug Pull Phantom',
    title: 'Фантом Скам-Токенов & Web3-Ловушек',
    category: 'web3',
    categoryLabel: 'Web3 и Инфраструктура',
    image: '/images/entity-pattern-phantom.jpg',
    threatLevel: 95,
    cognitiveTrap: 'Иллюзия инсайда, слепое доверие анонимным разработчикам и фальшивой ликвидности.',
    marketBehavior: 'Создает токен с 99% налогом на продажу (Honeypot) или заблокированной возможностью вывода средств. Заманивает обещаниями 1000x в децентрализованных пулах.',
    counterMeasures: [
      'Аудит смарт-контракта через обозреватель блокчейна (Etherscan/Solscan)',
      'Проверка блокировки ликвидности (LP Lock) и прав владельца (Mint/Freeze authority)',
      'Карта «On-Chain / Web3» и категорический отказ от сомнительных ссылок'
    ],
    recommendedCards: ['read_onchain_web3', 'proto_evidence_only', 'dec_staying_out_decision'],
    quote: '«Секретный пресейл от топовых фондов! Только для тебя! Ликвидность 100% честная, клянусь кодом!»',
    defeatedCount: 980
  },
  {
    id: 'entity_revenge_wraith',
    name: 'Revenge Wraith',
    title: 'Мстительный Дух Тильта (Tilt Demon)',
    category: 'emotions',
    categoryLabel: 'Эмоции и Поведение',
    image: '/images/entity-fomo-wraith.jpg',
    threatLevel: 90,
    cognitiveTrap: 'Отрицание убытка, оскорбленное эго, желание немедленно отыграться.',
    marketBehavior: 'Вселяется в трейдера сразу после обидного стоп-лосса. Заставляет отключать риск-менеджмент, удваивать ставки и нажимать кнопки с яростью, пока баланс не станет равен нулю.',
    counterMeasures: [
      'Обязательный тайм-аут на 1 час после любого стопа',
      'Запись эмоций в Журнал Решений',
      'Протокол «After a Loss» и карта «Avoid Revenge Trading»'
    ],
    recommendedCards: ['proto_after_a_loss', 'def_avoid_revenge', 'dec_pause_after_loss'],
    quote: '«Рынок тебя оскорбил! Ты не можешь это так оставить! Заходи на всю котлету в обратку, забери свое назад!»',
    defeatedCount: 1640
  },
  {
    id: 'entity_liquidity_hydra',
    name: 'Liquidity Hydra',
    title: 'Гидра Охоты за Стопами (Stop-Hunt Kraken)',
    category: 'signals',
    categoryLabel: 'Структура и Сигналы',
    image: '/images/entity-headline-titan.jpg',
    threatLevel: 84,
    cognitiveTrap: 'Размещение стоп-лоссов в очевидных местах, видимых всему рынку на тепловой карте ликвидаций.',
    marketBehavior: 'Умные деньги собирают стоп-лоссы толпы перед истинным движением тренда, оставляя за собой длинные тени свечей (Wicks).',
    counterMeasures: [
      'Выставление стопов за пределы зон ликвидности и Fair Value Gaps',
      'Использование карты «Volume & Liquidity»',
      'Вход после снятия ликвидности, а не до него'
    ],
    recommendedCards: ['read_volume_liquidity', 'read_market_structure', 'dec_invalidation_conditions'],
    quote: '«Ставь свой стоп ровно за этот локальный лой... Я аккуратно заберу его и полечу наверх без тебя!»',
    defeatedCount: 2450
  },
  {
    id: 'entity_whale_syndicate',
    name: 'Whale Syndicate',
    title: 'Синдикат Институциональных Китов',
    category: 'risk',
    categoryLabel: 'Риск и Позиция',
    image: '/images/entity-leverage-goblin.jpg',
    threatLevel: 89,
    cognitiveTrap: 'Попытка бороться с крупным игроком вместо следования за его следами ликвидности.',
    marketBehavior: 'Искусственно удерживают цену в боковике, создавая ложное чувство стабильности, пока распределяют гигантские объемы монет в розничных покупателей.',
    counterMeasures: [
      'Мониторинг кошельков китов через On-Chain метрики',
      'Оценка открытого интереса (Open Interest) и дельты биржевых стаканов',
      'Карта «Correlations» и протокол «Discipline Over Profit»'
    ],
    recommendedCards: ['read_onchain_web3', 'read_macro_context', 'proto_discipline_over_profit'],
    quote: '«Мы накапливаем позицию месяцами. Ты никогда не увидишь наших истинных ордеров в простом стакане.»',
    defeatedCount: 1120
  }
];
