import { TournamentMatch, MarketItem, PlayerProfile } from '../types/game';

export const initialPlayerProfile: PlayerProfile = {
  name: 'NovaTrader',
  handle: '@novatrader_pro',
  level: 24,
  currentXp: 4850,
  nextLevelXp: 6000,
  title: 'Старший Ончейн-Аналитик',
  league: 'Лига Аналитиков (Дивизион II)',
  leagueRank: 14,
  totalDecisions: 184,
  averagePQS: 84.6,
  disciplineStreak: 14,
  crystals: 2450,
  arenaTokens: 8650,
  isPremium: true,
  theme: 'theme_cyber_neon',
  avatar: 'avatar_cyber_hoodie',
  skills: {
    marketStructure: 88,
    riskManagement: 94,
    psychologyControl: 76,
    onChainReading: 82,
    disciplineProtocol: 90,
    macroSynthesis: 78
  },
  cognitiveBiasesAudit: [
    { name: 'Устойчивость к FOMO на ATH', trapRate: 12, status: 'Контролируется' },
    { name: 'Защита от усреднения (Averaging Down)', trapRate: 6, status: 'Контролируется' },
    { name: 'Реакция на инфошум и FUD', trapRate: 24, status: 'Требует внимания' },
    { name: 'Принятие убытка без попытки отыграться', trapRate: 15, status: 'Контролируется' },
    { name: 'Склонность к ранней фиксации (Paper Hands)', trapRate: 38, status: 'Требует внимания' }
  ]
};

export const activeTournaments: TournamentMatch[] = [
  {
    id: 'tourney_week_liquidation_hunt',
    title: 'Турнир Недели: Охота за Ликвидациями 2022',
    badge: 'Квалификация Элиты',
    endTime: '2 дня 14 часов',
    participantsCount: 4210,
    scenarioId: 'scenario_luna_death_spiral_2022',
    topScore: 98.4,
    playerRank: 14,
    playerScore: 94.0,
    rewards: { crystals: 1500, tokens: 5000, badgeTitle: 'Золотой Оракул Ликвидности' },
    isEntered: true
  },
  {
    id: 'tourney_etf_mania',
    title: 'Кубок Аналитиков: Битва за Биткоин ETF',
    badge: 'Институциональный Рейд',
    endTime: '5 дней 8 часов',
    participantsCount: 8940,
    scenarioId: 'scenario_btc_etf_sell_news_2024',
    topScore: 99.2,
    playerRank: 42,
    playerScore: 89.5,
    rewards: { crystals: 2500, tokens: 10000, badgeTitle: 'Гроссмейстер Новостного Шума' },
    isEntered: true
  },
  {
    id: 'tourney_solana_frenzy',
    title: 'Спидран Дисциплины: Мемкоин Безумие',
    badge: 'Hardcore Mode',
    endTime: '6 дней 20 часов',
    participantsCount: 1240,
    scenarioId: 'scenario_ftx_collapse_2022',
    topScore: 97.0,
    rewards: { crystals: 3000, tokens: 15000, badgeTitle: 'Иммунитет к Мем-Лихорадке' },
    isEntered: false
  }
];

export const leaderboardPlayers = [
  { rank: 1, name: 'QuantumMind', handle: '@quantum_alpha', pqs: 98.6, streak: 42, title: 'Легендарный Стратег', tier: 'Grandmaster', avatarBg: '#f2bd55', decisionsCount: 420 },
  { rank: 2, name: 'RiskMaster_99', handle: '@risk_first', pqs: 97.4, streak: 35, title: 'Архитектор Риска', tier: 'Master', avatarBg: '#69e7df', decisionsCount: 380 },
  { rank: 3, name: 'SatoshiProtocol', handle: '@onchain_seer', pqs: 96.8, streak: 28, title: 'Ончейн-Оракул', tier: 'Master', avatarBg: '#a88bff', decisionsCount: 310 },
  { rank: 4, name: 'AntiFOMO_Bot', handle: '@cold_mind', pqs: 95.9, streak: 21, title: 'Хранитель Спокойствия', tier: 'Diamond', avatarBg: '#54dda4', decisionsCount: 290 },
  { rank: 14, name: 'NovaTrader (Вы)', handle: '@novatrader_pro', pqs: 94.0, streak: 14, title: 'Старший Аналитик', tier: 'Diamond', avatarBg: '#33e0ae', you: true, decisionsCount: 184 },
  { rank: 15, name: 'GreyFox_Trading', handle: '@fox_charts', pqs: 93.8, streak: 11, title: 'Мастер Структуры', tier: 'Diamond', avatarBg: '#e2725b', decisionsCount: 175 },
  { rank: 16, name: 'MarketSoul', handle: '@zen_crypto', pqs: 92.4, streak: 9, title: 'Аналитик Ликвидности', tier: 'Platinum', avatarBg: '#4ac1e9', decisionsCount: 160 }
];

export const marketplaceItems: MarketItem[] = [
  {
    id: 'pass_pro_annual',
    name: 'SIGNAL PRO Pass (Годовой доступ)',
    category: 'pro',
    price: 99,
    currency: 'usd',
    priceUsd: '$9.99/мес',
    description: 'Полный профессиональный арсенал аналитика: доступ ко всем 100+ историческим сценариям, расширенный аудит когнитивных искажений, закрытые турниры с денежными фондами и золотой статус профиля.',
    features: [
      'Неограниченный доступ ко всем закрытым архивам (2011–2025)',
      'Персональный ИИ-разбор каждого решения на уровне институционального фонда',
      'Участие в закрытых Pro-турнирах с эксклюзивными наградами',
      'Анимированный голографический профиль и статус «Verified Analyst»',
      'Ранний доступ к GameFi 2.0 механике репутации'
    ],
    imageIcon: 'Crown',
    rarity: 'Legendary'
  },
  {
    id: 'theme_dark_gold_oracle',
    name: 'Оформление «Золотой Оракул»',
    category: 'profile_theme',
    price: 1800,
    currency: 'crystals',
    description: 'Элитная темная тема с переливающимся золотым свечением, гравированными рамками и винтажными виньетками.',
    features: ['Золотая окантовка карт протоколов', 'Анимированный золотой радар навыков', 'Эксклюзивный значок в таблицах лидеров'],
    imageIcon: 'Sparkles',
    rarity: 'Epic',
    isOwned: false
  },
  {
    id: 'theme_cyber_matrix',
    name: 'Оформление «Cyber Matrix Neo»',
    category: 'profile_theme',
    price: 1200,
    currency: 'crystals',
    description: 'Киберпанк-эстетика: неоновые зеленые и бирюзовые линии, глитч-эффекты и вид терминала будущего.',
    features: ['Неоновые индикаторы в виджете браузера', 'Глитч-анимация при победе над сущностью'],
    imageIcon: 'Cpu',
    rarity: 'Rare',
    isOwned: true
  },
  {
    id: 'campaign_pack_ico_bubble',
    name: 'Кампания: «Великий Бум ICO 2017»',
    category: 'campaign_pack',
    price: 3500,
    currency: 'tokens',
    description: '15 исторических сценариев эпохи зарождения альткоинов: уайтпейперы на салфетках, пампы 100x и последующий крах 2018 года.',
    features: ['15 уникальных заданий', '3 новые сущности (Meme Mirage, Whitepaper Ghost, Fork Titan)', 'Уникальная памятная карта протокола'],
    imageIcon: 'FolderGit2',
    rarity: 'Epic',
    isOwned: false
  },
  {
    id: 'campaign_pack_defi_summer',
    name: 'Кампания: «DeFi Summer 2020 & Yield Wars»',
    category: 'campaign_pack',
    price: 4500,
    currency: 'tokens',
    description: 'Кейсы создания Uniswap, Compound, флеш-кредитов (Flash Loans) и первых масштабных эксплойтов смарт-контрактов.',
    features: ['20 продвинутых ончейн-кейсов', 'Экзамен на звание DeFi-Аудитора'],
    imageIcon: 'Layers',
    rarity: 'Legendary',
    isOwned: false
  },
  {
    id: 'avatar_cyber_hoodie',
    name: 'Аватар «Dark Hood Analyst»',
    category: 'avatar',
    price: 800,
    currency: 'crystals',
    description: 'Анимированный аватар в темном капюшоне с голографической маской ликвидности.',
    features: ['Голографическое свечение глаз', 'Реакция на высокий Process Score'],
    imageIcon: 'User',
    rarity: 'Rare',
    isOwned: true
  }
];

export const gameFi20Manifesto = {
  title: 'GameFi 2.0 & Proof-of-Discipline: Революция без Пирамид',
  subtitle: 'Почему Signal Arena создает новую парадигму монетизации и мастерства в Web3',
  pillars: [
    {
      heading: '1. Отказ от P2E-пирамид (Play-to-Earn -> Play-and-Master)',
      body: 'Классический GameFi 1.0 рухнул, потому что платил за клики необеспеченными токенами, привлекая ботоводов и спекулянтов. В Signal Arena игровой процесс не генерирует «бесплатные деньги». Ценность продукта заключается в реальном прокачанном навыке трейдера, который предотвращает потери сотен тысяч долларов в реальном рынке.'
    },
    {
      heading: '2. Proof-of-Discipline & Soulbound Репутация',
      body: 'Достижения и уровень мастерства игрока (PQS) фиксируются в виде непередаваемых Soulbound-токенов (SBT). Проп-трейдинговые компании, Web3-фонды и криптосообщества используют профиль Signal Arena как объективное резюме дисциплины и аналитического IQ соискателя.'
    },
    {
      heading: '3. Устойчивая токеномика будущего',
      body: 'Будущий экосистемный токен $SIGNAL будет использоваться исключительно для стейкинга в турнирах, курирования пользовательских сценариев в DAO, доступа к институциональным датасетам и вознаграждения авторов лучших исторических разборов, без создания искусственной инфляции и зависимости от курса.'
    }
  ]
};
