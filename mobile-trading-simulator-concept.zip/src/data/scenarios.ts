import { CryptoScenario } from '../types/game';

export const cryptoScenarios: CryptoScenario[] = [
  {
    id: 'scenario_luna_death_spiral_2022',
    title: 'Спираль смерти Terra LUNA & UST',
    epoch: 'Криптозима & Крах Алгоритмиков',
    year: 'Май 2022',
    difficulty: 'Профи',
    difficultyLevel: 75,
    asset: 'LUNA / USDT',
    situationType: 'before_entry',
    situationTypeLabel: 'До входа (Поиск точки)',
    summary: 'Стейблкоин UST потерял привязку и торгуется по $0.88. Токен LUNA упал с $85 до $32 (-62%). Толпа в чатах кричит: «Это фундаментальный проект топ-10, скидка века, покупаем на всю котлету!». График показывает гигантскую красную свечу.',
    keyQuestion: 'Как поступить профессиональному аналитику при виде кажущейся «супер-скидки»?',
    activeEntityId: 'entity_leverage_goblin',
    activeProtocol: {
      id: 'proto_no_averaging',
      title: 'No Averaging & Falling Knife Lock',
      rule: 'Категорический запрет на лотерейный выкуп активов с компрометацией базовой математической модели.'
    },
    equippedCards: ['read_onchain_web3', 'def_falling_knife', 'proto_evidence_only', 'dec_staying_out_decision'],
    tabs: {
      chartData: {
        symbol: 'LUNA/USDT (Binance)',
        timeframe: '4H (4-часовой таймфрейм)',
        candles: [
          { time: '06.05 00:00', open: 86.4, high: 88.2, low: 84.1, close: 85.3, volume: 1420000 },
          { time: '07.05 08:00', open: 85.3, high: 86.0, low: 78.4, close: 79.2, volume: 3850000 },
          { time: '08.05 16:00', open: 79.2, high: 80.5, low: 64.3, close: 65.1, volume: 8900000 },
          { time: '09.05 00:00', open: 65.1, high: 66.8, low: 48.0, close: 51.4, volume: 18400000 },
          { time: '09.05 12:00', open: 51.4, high: 54.2, low: 30.5, close: 32.8, volume: 42100000 },
          // Hidden future candles to reveal after decision
          { time: '10.05 00:00', open: 32.8, high: 34.1, low: 14.2, close: 15.6, volume: 68000000, isFuture: true },
          { time: '11.05 00:00', open: 15.6, high: 16.5, low: 1.1, close: 1.8, volume: 125000000, isFuture: true },
          { time: '12.05 00:00', open: 1.8, high: 2.1, low: 0.00005, close: 0.00008, volume: 450000000, isFuture: true }
        ],
        levels: [
          { price: 85.0, label: 'Бывшая поддержка (Сломлена)', type: 'resistance' },
          { price: 50.0, label: 'Психологический уровень (Пробит)', type: 'resistance' },
          { price: 30.0, label: 'Текущий отскок', type: 'invalidation' }
        ],
        notes: [
          'Слом структуры на всех таймфреймах',
          'Объемы растут лавинообразно на стороне продаж',
          'Спред стакана расширен до аномальных 4%'
        ]
      },
      onChain: {
        whaleExchangeFlow: '+45,000,000 LUNA заведено на Binance за 6 часов',
        exchangeReserveChange: 'Резервы бирж выросли на +340% (Аномальный дамп)',
        smartMoneyDivergence: 'Смарт-мани полностью ликвидировали стейкинг в Anchor Protocol',
        gasSpike: 'Сеть Terra перегружена, транзакции арбитражеров забивают блоки',
        notableTransfers: [
          'Terra Mint Module сгенерировал +120,000,000 новых LUNA для защиты UST',
          'Jump Trading и Alameda выводят остатки ликвидности из Curve pool 3pool',
          'Кит 0x38a... вывел 84,000,000 UST с дисконтом в USDC'
        ],
        riskScore: 99
      },
      orderBook: {
        bidAskRatio: '1 : 14 (Абсолютное доминирование продавцов)',
        fundingRate: '-2.00% (Максимальный шорт-фандинг на всех биржах)',
        openInterestTrend: 'OI вырос на 85% — толпа шортит и пытается ловить дно лонгами',
        liquidationWall: 'Стенка ликвидаций лонгистов на $25, $15, $5',
        depthImbalance: 'В стакане на покупку пустые дыры ликвидности'
      },
      newsNarrative: {
        mainHeadline: 'До Квон: «UST восстановит привязку, держитесь, план спасения готов!»',
        sourceReliability: 'Сомнительная',
        sentiment: 'Паника / FUD',
        articles: [
          { time: '10 мин назад', title: 'Yellen комментирует депег UST в Сенате США', tag: 'Регуляция' },
          { time: '45 мин назад', title: 'Curve Pool UST/3Pool перекошен на 92%', tag: 'DeFi' },
          { time: '2 часа назад', title: 'LFG переводит 28,000 BTC на биржу Gemini', tag: 'Ончейн' }
        ]
      },
      socialFunding: {
        fearGreedIndex: 11, // Экстремальный страх
        socialVolumeSpike: '+940% упоминаний в Twitter/X',
        longRatio: 68, // 68% розничных трейдеров пытаются поймать дно в лонг!
        twitterHype: 'Тренды: #BuyLUNA, #TerraComeback, #DoKwon'
      }
    },
    decisions: [
      {
        id: 'stay_out',
        title: 'Остаться вне рынка (Защитная пауза)',
        subtitle: 'Полный запрет на покупку токена с гиперинфляционной эмиссией',
        rationale: 'Ончейн показывает эмиссию сотен миллионов новых токенов. Алгоритм сжигает UST за счет печати триллионов LUNA.',
        processScore: 98,
        riskImpact: 'optimal',
        isCorrectProcess: true,
        explanation: 'Идеальное решение. Вы распознали гиперинфляционный крах алгоритмического механизма. Никакой теханализ не работает против бесконечной эмиссии монеты.'
      },
      {
        id: 'reduce_risk',
        title: 'Шорт только с минимальным риском (0.25%)',
        subtitle: 'Следование за трендом с жестким стопом за локальный свинг',
        rationale: 'Шорт логичен фундаментально, но шорт-фандинг -2% и риск волатильных отскоков требуют микро-размера позиции.',
        processScore: 82,
        riskImpact: 'cautious',
        isCorrectProcess: false,
        explanation: 'Допустимо с точки зрения направления, но шорт переполнен (фандинг сжигает баланс), а биржа может отключить торги в любой момент.'
      },
      {
        id: 'wait_confirmation',
        title: 'Ждать подтверждения восстановления UST до $0.99',
        subtitle: 'Не совершать сделок до устранения первопричины кризиса',
        rationale: 'Пока стейблкоин депегнут, токен LUNA будет бесконечно размываться эмиссией.',
        processScore: 90,
        riskImpact: 'optimal',
        isCorrectProcess: true,
        explanation: 'Отличная логика фильтрации первопричины. Поскольку UST так и не вернулся к $1, вы избежали полной потери средств.'
      },
      {
        id: 'aggressive_entry',
        title: 'Агрессивный лонг на отскок («Скидка 65%!»)',
        subtitle: 'Покупка на локальном уровне $30 в надежде на возврат к $80',
        rationale: '«Актив упал слишком сильно, отскок на 50% гарантирован».',
        processScore: 8,
        riskImpact: 'reckless',
        isCorrectProcess: false,
        explanation: 'Критическая когнитивная ошибка (Anchoring & Falling Knife). Токен LUNA упал с $30 до $0.00001 за следующие 48 часов, уничтожив 100% вложенного капитала.'
      }
    ],
    secondStep: {
      prompt: 'Укажи критическое ончейн-доказательство, запрещающее покупку LUNA:',
      type: 'evidence_select',
      options: [
        { id: 'opt_mint', label: 'Смарт-контракт непрерывно генерирует миллионы новых LUNA в секунду', isOptimal: true, note: 'Гиперинфляция предложения математически гарантирует обнуление цены' },
        { id: 'opt_twitter', label: 'В Twitter много негативных мемов про До Квона', isOptimal: false, note: 'Эмоциональный шум в соцсетях не является ончейн-фактом' },
        { id: 'opt_rsi', label: 'Индикатор RSI находится в зоне перепроданности (12)', isOptimal: false, note: 'RSI не учитывает изменение общего количества токенов в обращении' }
      ]
    },
    historicalFact: {
      date: '10–13 мая 2022 года',
      whatHappened: 'Эмиссия LUNA выросла с 350 миллионов до 6.5 триллионов токенов за 72 часа. Цена LUNA рухнула с $80 до $0.00005 (-99.9999%). Капитализация экосистемы в $40 млрд испарилась полностью.',
      actualPriceMove: 'Падение с $32.80 до $0.00008 (-99.99%)',
      verifiedSource: 'On-chain блокчейн Terra Classic, архивы торгов Binance LUNA/BUSD'
    },
    learningTakeaway: 'Когда нарушена базовая токеномика проекта или алгоритм создает бесконечную эмиссию, концепции «перепроданности» и «скидки» перестают существовать. Единственное верное действие — полная изоляция от актива.'
  },
  {
    id: 'scenario_btc_etf_sell_news_2024',
    title: 'Запуск Спотовых Bitcoin ETF (Sell the News)',
    epoch: 'Институциональная Эра & ETF',
    year: 'Январь 2024',
    difficulty: 'Аналитик',
    difficultyLevel: 55,
    asset: 'BTC / USDT',
    situationType: 'before_entry',
    situationTypeLabel: 'До входа (Вершина импульса)',
    summary: 'SEC США официально одобрила 11 спотовых заявок на Bitcoin ETF. Цена мгновенно взлетает до $48,900. В соцсетях эйфория, розничные инвесторы уверены, что коррекций больше не будет и $100k наступит к концу недели. Ставки фандинга зашкаливают.',
    keyQuestion: 'Как реагировать на долгожданное фундаментальное событие на вершине многомесячного ралли?',
    activeEntityId: 'entity_fomo_wraith',
    activeProtocol: {
      id: 'proto_anti_fomo',
      title: 'Anti-FOMO & Evidence Only',
      rule: 'Запрет на покупку в момент всеобщей эйфории без учета давления фиксации прибыли фондами.'
    },
    equippedCards: ['read_news_context', 'read_social_sentiment', 'def_dont_chase', 'dec_take_partial_profits'],
    tabs: {
      chartData: {
        symbol: 'BTC/USDT (Coinbase)',
        timeframe: '1D (Дневной таймфрейм)',
        candles: [
          { time: '05.01 00:00', open: 44100, high: 44700, low: 43200, close: 44300, volume: 22000 },
          { time: '08.01 00:00', open: 44300, high: 47200, low: 43900, close: 46900, volume: 48000 },
          { time: '10.01 00:00', open: 46900, high: 47900, low: 45600, close: 46600, volume: 56000 },
          { time: '11.01 00:00', open: 46600, high: 48969, low: 45700, close: 46300, volume: 84000 },
          // Future candles
          { time: '12.01 00:00', open: 46300, high: 46500, low: 41500, close: 42800, volume: 92000, isFuture: true },
          { time: '18.01 00:00', open: 42800, high: 43200, low: 40200, close: 41200, volume: 64000, isFuture: true },
          { time: '22.01 00:00', open: 41200, high: 41500, low: 38550, close: 38800, volume: 78000, isFuture: true }
        ],
        levels: [
          { price: 48900, label: 'Макро-сопротивление 0.618 Фибоначчи', type: 'resistance' },
          { price: 44000, label: 'Прежняя зона пробоя', type: 'support' },
          { price: 38500, label: 'Институциональный пул ликвидности', type: 'support' }
        ],
        notes: [
          'Дневная свеча оставляет длинную тень сверху (Rejection Wick)',
          'Медвежья дивергенция на дневном RSI',
          'Снятие ликвидности за хаем марта 2022 года ($48.2k)'
        ]
      },
      onChain: {
        whaleExchangeFlow: '+18,000 BTC заведено на биржи с кошельков Grayscale GBTC',
        exchangeReserveChange: 'Резервы бирж растут за счет фиксации прибыли ранних инвесторов',
        smartMoneyDivergence: 'Фонды с высоким дисконтом по GBTC начали арбитражный сброс',
        gasSpike: 'В сети Биткоина комиссии выросли из-за активности арбитражеров',
        notableTransfers: [
          'Grayscale переместил 40,000 BTC на адреса Coinbase Prime Custody',
          'Майнеры продали 8,400 BTC за 48 часов для фиксации операционных расходов'
        ],
        riskScore: 78
      },
      orderBook: {
        bidAskRatio: '1 : 2.8 (Плотные блоки лимитных ордеров на продажу выше $48,000)',
        fundingRate: '+0.095% каждые 8 часов (Экстремально высокая плата за лонг)',
        openInterestTrend: 'Открытый интерес на рекордных $20 млрд — рынок перегружен плечами',
        liquidationWall: 'Огромный кластер ликвидаций лонгов расположен в диапазоне $42,000 - $39,000',
        depthImbalance: 'Розничные покупатели давят по маркету в лимиты маркет-мейкеров'
      },
      newsNarrative: {
        mainHeadline: '«Исторический день: SEC одобрила спотовые биткоин-ETF для BlackRock и Fidelity»',
        sourceReliability: 'Высокая',
        sentiment: 'Экстремальная жадность',
        articles: [
          { time: '1 час назад', title: 'Объем торгов ETF превысил $4.6 млрд в первый день', tag: 'Институционалы' },
          { time: '3 часа назад', title: 'Аналитики Bloomberg: Приток капитала будет рекордным', tag: 'Медиа' },
          { time: '5 часов назад', title: 'Гэри Генслер предупреждает о волатильности криптоактивов', tag: 'SEC' }
        ]
      },
      socialFunding: {
        fearGreedIndex: 84, // Extreme Greed
        socialVolumeSpike: '+450% упоминаний в соцсетях',
        longRatio: 79, // 79% трейдеров стоят в лонгах
        twitterHype: '«$100k до конца месяца неизбежно, шортистов вынесут!»'
      }
    },
    decisions: [
      {
        id: 'reduce_risk',
        title: 'Зафиксировать 50-70% прибыли и защитить стопы',
        subtitle: 'Классическая отработка сценария «Покупай на слухах, продавай на фактах»',
        rationale: 'Все ожидания одобрения ETF уже были заложены в 100% рост Биткоина с $25k до $48k.',
        processScore: 96,
        riskImpact: 'optimal',
        isCorrectProcess: true,
        explanation: 'Великолепное понимание рыночной механики. Когда позитивная новость наконец выходит, крупный капитал использует волну розничной эйфории для выхода в кэш.'
      },
      {
        id: 'stay_out',
        title: 'Остаться вне новых позиций и ждать охлаждения фандинга',
        subtitle: 'Не открывать лонги на хаях при перегруженных ставках финансирования',
        rationale: 'Фандинг +0.1% и Grayscale оттоки создают сильное краткосрочное давление на цену.',
        processScore: 88,
        riskImpact: 'cautious',
        isCorrectProcess: true,
        explanation: 'Дисциплинированный шаг. Переждать разгрузку деривативов позволило войти по цене на $10,000 дешевле.'
      },
      {
        id: 'wait_confirmation',
        title: 'Ждать закрепления выше $49,000 с закрытием дневной свечи',
        subtitle: 'Не гадать о вершине, а входить только при подтвержденном истинном пробое',
        rationale: 'Пока цена не закрепилась выше макро-уровня $48.9k, вход в лонг — это игра в рулетку.',
        processScore: 85,
        riskImpact: 'optimal',
        isCorrectProcess: true,
        explanation: 'Отличный фильтр риска. Так как дневная свеча закрылась с длинным фитилем вниз, вы не вошли в ловушку.'
      },
      {
        id: 'aggressive_entry',
        title: 'Открыть лонг с плечом на новости («BlackRock купит всё!»)',
        subtitle: 'Покупка на пробое $48,500 по рынку',
        rationale: '«Одобрение ETF — величайшее событие, цена никогда не упадет ниже $45k».',
        processScore: 12,
        riskImpact: 'reckless',
        isCorrectProcess: false,
        explanation: 'Грубая ошибка следования за эмоциями толпы (FOMO Trap). Биткоин скорректировался с $48,900 до $38,500 (-21%) за последующие 10 дней из-за сброса GBTC.'
      }
    ],
    secondStep: {
      prompt: 'Какое условие аннулирует бычий сценарий на младших таймфреймах?',
      type: 'invalidation',
      options: [
        { id: 'inv_44k', label: 'Потеря уровня $44,000 с уходом под дневную поддержку', isOptimal: true, note: 'Подтверждает переход инициативы к продавцам и запуск сквиза ликвидаций' },
        { id: 'inv_news', label: 'Очередное интервью аналитика на CNBC', isOptimal: false, note: 'Слова аналитиков не являются триггером рыночной структуры' },
        { id: 'inv_tweet', label: 'Падение активности в комментариях X', isOptimal: false, note: 'Косвенный признак, не заменяющий графический уровень' }
      ]
    },
    historicalFact: {
      date: '11–23 января 2024 года',
      whatHappened: 'После достижения пика $48,969 в день старта торгов ETF, Биткоин столкнулся с масштабным давлением продаж из фонда GBTC ($5 млрд оттока) и упал до $38,550 к 23 января.',
      actualPriceMove: 'Снижение с $48,969 до $38,550 (-21.3%)',
      verifiedSource: 'Официальные данные спотовых торгов ETF и балансы Grayscale Trust'
    },
    learningTakeaway: 'События категории «Sell the News» происходят потому, что смарт-мани накапливают позицию за месяцы до анонса и закрывают ее об ликвидность толпы в момент кульминации заголовков.'
  },
  {
    id: 'scenario_ftx_collapse_2022',
    title: 'Крах биржи FTX & Каскад ликвидаций Alameda',
    epoch: 'Криптозима & Инфраструктурный Шок',
    year: 'Ноябрь 2022',
    difficulty: 'Грандмастер',
    difficultyLevel: 90,
    asset: 'SOL / USDT',
    situationType: 'in_position',
    situationTypeLabel: 'Внутри позиции (Экстренное управление)',
    summary: 'У вас открыт среднесрочный лонг по Solana от уровня $36. Появились слухи о неплатежеспособности биржи FTX и Alameda Research. SBF твитит «FTX is fine. Assets are fine». Однако ончейн показывает, что резервы биржи иссякают, а Binance объявил о полной продаже токенов FTT.',
    keyQuestion: 'Как поступить с открытой позицией, когда фундаментальный риск инфраструктуры превышает любые графические сигналы?',
    activeEntityId: 'entity_headline_titan',
    activeProtocol: {
      id: 'proto_preserve_capital',
      title: 'Preserve Capital & Risk First',
      rule: 'При угрозе неплатежеспособности контрагента или платформы приоритет номер один — эвакуация капитала в холодные хранилища.'
    },
    equippedCards: ['proto_preserve_capital', 'read_position_history', 'read_onchain_web3', 'dec_invalidation_conditions'],
    tabs: {
      chartData: {
        symbol: 'SOL/USDT (FTX / Binance)',
        timeframe: '4H (4-часовой график)',
        candles: [
          { time: '05.11 00:00', open: 34.2, high: 38.5, low: 33.8, close: 36.8, volume: 1200000 },
          { time: '06.11 00:00', open: 36.8, high: 37.2, low: 34.5, close: 35.1, volume: 2400000 },
          { time: '07.11 00:00', open: 35.1, high: 35.6, low: 29.8, close: 31.4, volume: 6800000 },
          { time: '08.11 00:00', open: 31.4, high: 32.0, low: 21.5, close: 24.2, volume: 18500000 },
          // Future candles
          { time: '09.11 00:00', open: 24.2, high: 25.1, low: 12.0, close: 13.8, volume: 34000000, isFuture: true },
          { time: '10.11 00:00', open: 13.8, high: 18.2, low: 11.5, close: 14.1, volume: 28000000, isFuture: true },
          { time: '20.11 00:00', open: 14.1, high: 14.8, low: 8.0, close: 9.6, volume: 21000000, isFuture: true }
        ],
        levels: [
          { price: 36.0, label: 'Ваша точка входа (L = $36)', type: 'invalidation' },
          { price: 30.0, label: 'Ключевая поддержка диапазона (Сломана)', type: 'resistance' },
          { price: 10.0, label: 'Зона паники ликвидаторов', type: 'support' }
        ],
        notes: [
          'Аномальный всплеск объема на продажу',
          'Solana падает в 3 раза быстрее всего остального рынка из-за прямой связи с Alameda',
          'Остановка вывода средств на бирже FTX'
        ]
      },
      onChain: {
        whaleExchangeFlow: 'Отток $1.2 млрд стейблкоинов с кошельков FTX за 24 часа',
        exchangeReserveChange: 'Резервы ETH на FTX упали практически до нуля',
        smartMoneyDivergence: 'Nansen фиксирует массовый вывод средств венчурными фондами',
        gasSpike: 'Сеть Ethereum перегружена срочными транзакциями вывода',
        notableTransfers: [
          'Alameda выводит ликвидность со всех DeFi-протоколов для закрытия дыр',
          'Разработчики Solana Foundation хранили часть казначейства на FTX'
        ],
        riskScore: 100
      },
      orderBook: {
        bidAskRatio: '1 : 22 (Полное исчезновение маркет-мейкеров Alameda)',
        fundingRate: '-3.50% (Исторический антирекорд)',
        openInterestTrend: 'OI стремительно сжимается из-за ликвидаций',
        liquidationWall: 'Стены маржин-коллов на $20, $15, $10',
        depthImbalance: 'В стакане отсутствуют институциональные биды'
      },
      newsNarrative: {
        mainHeadline: '«CZ Binance объявляет о продаже FTT; FTX приостанавливает обработку заявок на вывод»',
        sourceReliability: 'Высокая',
        sentiment: 'Паника / FUD',
        articles: [
          { time: '30 мин назад', title: 'Очередь на вывод с FTX превысила $5 млрд', tag: 'Экстренно' },
          { time: '2 часа назад', title: 'CoinDesk публикует аудит баланса Alameda Research', tag: 'Расследование' }
        ]
      },
      socialFunding: {
        fearGreedIndex: 9, // Экстремальная паника
        socialVolumeSpike: '+1200% упоминаний',
        longRatio: 52,
        twitterHype: '«Банкрутство биржи топ-2? Это конец крипты?»'
      },
      positionHistory: {
        entryPrice: 36.0,
        currentUnrealizedPnL: '-32.7% (Текущая цена $24.2)',
        timeInPosition: '4 дня',
        initialPlan: 'Трендовый лонг с целью $50 при условии стабильности экосистемы',
        maxAllowedDrawdown: '-5% от депозита (Системный стоп уже нарушен!)'
      }
    },
    decisions: [
      {
        id: 'reduce_risk',
        title: 'Немедленно закрыть позицию по рынку и зафиксировать убыток',
        subtitle: 'Признать аннулирование фундаментального тезиса и спасти остаток депозита',
        rationale: 'Угроза банкротства биржи и ликвидации миллиардных запасов SOL со стороны Alameda отменяет любой теханализ.',
        processScore: 99,
        riskImpact: 'high_defense',
        isCorrectProcess: true,
        explanation: 'Идеальное хладнокровное решение. Фиксация убытка в -32% на $24 спасла позицию от дальнейшего падения до $8 (-78% дополнительного убытка).'
      },
      {
        id: 'stay_out',
        title: 'Закрыть сделку и вывести все средства на некастодиальный кошелек',
        subtitle: 'Полная эвакуация капитала с централизованных бирж в холодное хранение',
        rationale: 'Риск блокировки вывода средств на бирже является экзистенциальным.',
        processScore: 98,
        riskImpact: 'optimal',
        isCorrectProcess: true,
        explanation: 'Высший пилотаж риск-менеджмента в Web3. Защита капитала от риска контрагента важнее любой спекулятивной сделки.'
      },
      {
        id: 'wait_confirmation',
        title: 'Установить жесткий стоп на $20 и ждать официального аудита',
        subtitle: 'Попытка дать позиции еще один шанс на удержание психологического уровня',
        rationale: '«Вдруг Binance выкупит FTX и рынок развернется обратно?».',
        processScore: 45,
        riskImpact: 'reckless',
        isCorrectProcess: false,
        explanation: 'Опасное промедление (Hope Trap). Надежда на внешнее спасение привела к проскальзыванию стопа из-за дыр в ликвидности стакана.'
      },
      {
        id: 'aggressive_entry',
        title: 'Усреднить позицию на $24 («Solana стоит слишком дешево!»)',
        subtitle: 'Докупить еще монет, чтобы снизить среднюю цену входа до $30',
        rationale: '«SBF сказал, что активы в порядке, это просто FUD от конкурентов».',
        processScore: 5,
        riskImpact: 'reckless',
        isCorrectProcess: false,
        explanation: 'Катастрофическая ошибка (Denial & Averaging Down). Solana обвалилась до $8.20, а биржа FTX заблокировала миллиарды долларов пользователей.'
      }
    ],
    secondStep: {
      prompt: 'Что является главным приоритетом трейдера в моменты системного кризиса инфраструктуры?',
      type: 'evidence_select',
      options: [
        { id: 'ev_cap', label: 'Сохранение капитала и вывод активов на собственный некастодиальный кошелек', isOptimal: true, note: 'Не твои ключи — не твоя криптовалюта' },
        { id: 'ev_chart', label: 'Поиск фигуры двойного дна на 5-минутном графике', isOptimal: false, note: 'Графики теряют смысл, когда биржа не отдает депозиты' },
        { id: 'ev_tweet', label: 'Ожидание успокаивающих твитов от руководства биржи', isOptimal: false, note: 'Менеджмент тонущих компаний всегда отрицает проблемы до последней минуты' }
      ]
    },
    historicalFact: {
      date: '8–11 ноября 2022 года',
      whatHappened: 'FTX полностью остановила вывод средств и подала на банкротство по Главе 11 с дырой в $8.8 млрд. Solana рухнула с $36 до минимума в $8.05 (-77%), а общая капитализация крипторынка потеряла сотни миллиардов долларов.',
      actualPriceMove: 'Обвал SOL с $24.20 до $8.05 (-66.7%)',
      verifiedSource: 'Судебные документы банкротства FTX/Alameda, архивы ончейн-аналитики Nansen'
    },
    learningTakeaway: 'Когда возникает риск контрагента (банкротство биржи или эмитента), никакие графические уровни не действуют. Профессионал режет убыток немедленно и спасает капитал, не надеясь на чудо.'
  }
];
