import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Play,
  BrainCircuit
} from 'lucide-react';
import { GameMode, CryptoScenario, PlayerProfile } from './types/game';
import { cryptoScenarios } from './data/scenarios';
import { initialPlayerProfile } from './data/tournaments';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { ArenaView } from './components/ArenaView';
import { CampaignView } from './components/CampaignView';
import { AcademyView } from './components/AcademyView';
import { BestiaryView } from './components/BestiaryView';
import { DeckView } from './components/DeckView';
import { TournamentsView } from './components/TournamentsView';
import { ProfileJournalView } from './components/ProfileJournalView';
import { MarketplaceView } from './components/MarketplaceView';

export default function App() {
  const [currentMode, setCurrentMode] = useState<GameMode>('arena');
  const [scenarios] = useState<CryptoScenario[]>(cryptoScenarios);
  const [currentScenario, setCurrentScenario] = useState<CryptoScenario>(cryptoScenarios[0]);
  const [profile, setProfile] = useState<PlayerProfile>(initialPlayerProfile);
  const [showHeroBanner, setShowHeroBanner] = useState(true);

  const handleSelectMode = (mode: GameMode) => {
    setCurrentMode(mode);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleStartScenario = (scenario: CryptoScenario) => {
    setCurrentScenario(scenario);
    setCurrentMode('arena');
    setShowHeroBanner(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleStartScenarioFromId = (scenarioId: string) => {
    const sc = scenarios.find((s) => s.id === scenarioId) || scenarios[0];
    handleStartScenario(sc);
  };

  const handleCompleteScenario = (_scenarioId: string, score: number) => {
    // Update player profile stats
    setProfile((prev) => {
      const newDecisions = prev.totalDecisions + 1;
      const newPqs = Number(((prev.averagePQS * prev.totalDecisions + score) / newDecisions).toFixed(1));
      const addedXp = score >= 80 ? 140 : 60;
      const addedCrystals = score >= 80 ? 50 : 15;
      const addedTokens = score >= 80 ? 100 : 30;

      let nextXp = prev.currentXp + addedXp;
      let nextLevel = prev.level;
      let nextLevelCap = prev.nextLevelXp;

      if (nextXp >= nextLevelCap) {
        nextLevel += 1;
        nextXp -= nextLevelCap;
        nextLevelCap = Math.round(nextLevelCap * 1.25);
      }

      return {
        ...prev,
        level: nextLevel,
        currentXp: nextXp,
        nextLevelXp: nextLevelCap,
        totalDecisions: newDecisions,
        averagePQS: newPqs,
        crystals: prev.crystals + addedCrystals,
        arenaTokens: prev.arenaTokens + addedTokens
      };
    });
  };

  const handleUpdateProfile = (updated: Partial<PlayerProfile>) => {
    setProfile((prev) => ({ ...prev, ...updated }));
  };

  return (
    <div className="min-h-screen bg-[#050c18] text-slate-100 selection:bg-cyan-400 selection:text-slate-950 pb-20 lg:pb-12">
      
      {/* Top Bar with Profile Stats & Quick Scenario */}
      <Header
        profile={profile}
        currentMode={currentMode}
        onSelectMode={handleSelectMode}
        onOpenQuickScenario={() => {
          handleStartScenario(scenarios[0]);
        }}
      />

      {/* Sub-Nav / Mode Switcher */}
      <Navigation
        currentMode={currentMode}
        onSelectMode={handleSelectMode}
      />

      {/* Main Mode Viewport */}
      <main>
        {/* Optional Collapsible Hero Intro Banner on Arena mode */}
        {showHeroBanner && currentMode === 'arena' && (
          <section className="relative overflow-hidden border-b border-cyan-500/20 bg-[#061220]">
            <div className="absolute inset-0 bg-[url('/images/signal-arena-hero.jpg')] bg-cover bg-[70%_center] opacity-25 mix-blend-luminosity" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#061220] via-[#061220]/90 to-transparent" />
            
            <div className="relative z-10 mx-auto max-w-[1520px] px-4 py-8 sm:px-6 sm:py-12">
              <div className="max-w-2xl">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.2em] text-cyan-400 font-mono">
                  <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
                  <span>Тренажер торгового мышления в крипте</span>
                </div>

                <h1 className="font-display mt-2 text-3xl font-black uppercase tracking-tight text-white sm:text-5xl">
                  SIGNAL <span className="text-cyan-400">ARENA</span>
                </h1>

                <p className="mt-3 text-sm text-slate-300 leading-relaxed sm:text-base">
                  Оценивается качество решений (Process Quality), а не удача. Без терминала, ордеров и угадывания свечей.
                </p>

                <div className="mt-5 flex flex-wrap gap-3">
                  <button
                    onClick={() => setShowHeroBanner(false)}
                    className="primary-button text-xs"
                  >
                    <Play size={15} fill="currentColor" />
                    <span>Перейти к активному сценарию</span>
                  </button>

                  <button
                    onClick={() => handleSelectMode('academy')}
                    className="secondary-button text-xs"
                  >
                    <BrainCircuit size={15} className="text-cyan-400" />
                    <span>Пройти Duolingo-курс</span>
                  </button>

                  <button
                    onClick={() => setShowHeroBanner(false)}
                    className="rounded-lg border border-white/10 px-3 py-2 text-xs text-slate-400 hover:text-white"
                  >
                    Скрыть баннер
                  </button>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* View Routing */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentMode}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.2 }}
          >
            {currentMode === 'arena' && (
              <ArenaView
                scenarios={scenarios}
                currentScenario={currentScenario}
                onSelectScenario={(s) => setCurrentScenario(s)}
                onCompleteScenario={handleCompleteScenario}
              />
            )}

            {currentMode === 'campaign' && (
              <CampaignView
                scenarios={scenarios}
                onStartScenario={handleStartScenario}
              />
            )}

            {currentMode === 'academy' && (
              <AcademyView
                onStartScenarioFromLesson={handleStartScenarioFromId}
              />
            )}

            {currentMode === 'bestiary' && (
              <BestiaryView />
            )}

            {currentMode === 'deck' && (
              <DeckView />
            )}

            {currentMode === 'tournaments' && (
              <TournamentsView
                scenarios={scenarios}
                onStartScenario={handleStartScenario}
              />
            )}

            {currentMode === 'profile' && (
              <ProfileJournalView
                profile={profile}
              />
            )}

            {currentMode === 'marketplace' && (
              <MarketplaceView
                profile={profile}
                onUpdateProfile={handleUpdateProfile}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="mt-16 border-t border-white/[0.07] bg-[#03070e] text-slate-500">
        <div className="mx-auto flex max-w-[1520px] flex-col gap-4 px-4 py-8 sm:px-6 md:flex-row md:items-center md:justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="font-display font-black text-white">SIGNAL ARENA</span>
            <span>• Игровой тренажер качества решений</span>
          </div>
          <p className="max-w-xl text-[11px] leading-relaxed text-slate-500">
            Продукт оценивает соблюдение протоколов риска и системной логики. Не является инвестиционной рекомендацией. Внутриигровые баллы PQS не имеют денежной стоимости.
          </p>
          <span className="font-mono text-[10px] uppercase text-slate-600">GameFi 2.0 Spec • 2026</span>
        </div>
      </footer>

    </div>
  );
}
