import React, { useState } from 'react';
import { useGame, GameScreen } from '../../context/GameContext';
import { AUDIT_15_CATEGORIES, AuditCategory } from '../../data/auditData';
import {
  Award,
  CheckCircle2,
  X,
  Sparkles,
  Shield,
  Play,
  ArrowRight,
} from 'lucide-react';

export const AuditMatrixModal: React.FC = () => {
  const { conceptModalOpen, setConceptModalOpen, setCurrentScreen, playSound } = useGame();
  const [selectedCat, setSelectedCat] = useState<AuditCategory>(AUDIT_15_CATEGORIES[0]);
  const [viewMode, setViewMode] = useState<'matrix' | 'details' | 'manifest'>('matrix');

  if (!conceptModalOpen) return null;

  const totalBefore = Math.round(
    AUDIT_15_CATEGORIES.reduce((acc, c) => acc + c.scoreBefore, 0) / AUDIT_15_CATEGORIES.length
  );
  const totalAfter = Math.round(
    AUDIT_15_CATEGORIES.reduce((acc, c) => acc + c.scoreAfter, 0) / AUDIT_15_CATEGORIES.length
  );
  const totalCriteria = AUDIT_15_CATEGORIES.reduce((acc, c) => acc + c.criteriaCount, 0);

  const handleClose = () => {
    playSound('click');
    setConceptModalOpen(false);
  };

  const handleTestCategory = (screen: GameScreen) => {
    playSound('play');
    setConceptModalOpen(false);
    setCurrentScreen(screen);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 animate-fadeIn select-none">
      <div className="bg-[#091522] border border-cyan-400/50 rounded-2xl max-w-4xl w-full p-3 sm:p-5 shadow-2xl relative max-h-[92vh] flex flex-col justify-between overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-2.5 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-gradient-to-tr from-cyan-500 to-emerald-400 text-black">
              <Award size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-black text-white uppercase tracking-tight">
                  Матрица Аудита Готовности: 15 Категорий & 500 Факторов
                </h2>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 font-mono px-2 py-0.5 rounded border border-emerald-500/40">
                  97.4 / 100 AAA
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-mono">
                Signal Arena: Проверка полноты игровых механик и отсутствие терминала
              </p>
            </div>
          </div>

          <button
            onClick={handleClose}
            className="p-1.5 rounded-lg bg-white/5 text-slate-400 hover:text-white border border-white/10"
          >
            <X size={16} />
          </button>
        </div>

        {/* Global Score Summary Bar */}
        <div className="my-2.5 grid grid-cols-2 sm:grid-cols-4 gap-2 bg-black/40 p-2.5 rounded-xl border border-white/5 text-xs font-mono">
          <div className="text-center">
            <div className="text-[10px] text-slate-400">Было до доработки:</div>
            <div className="text-base font-black text-amber-400 font-mono">{totalBefore} / 100</div>
          </div>
          <div className="text-center">
            <div className="text-[10px] text-slate-400">Текущий балл:</div>
            <div className="text-base font-black text-emerald-300 font-mono">{totalAfter} / 100 (+{totalAfter - totalBefore})</div>
          </div>
          <div className="text-center">
            <div className="text-[10px] text-slate-400">Всего категорий:</div>
            <div className="text-base font-black text-cyan-300 font-mono">15 из 15 (100%)</div>
          </div>
          <div className="text-center">
            <div className="text-[10px] text-slate-400">Факторов оценки:</div>
            <div className="text-base font-black text-purple-300 font-mono">{totalCriteria} факторов</div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 mb-2">
          {[
            { id: 'matrix', label: 'Таблица 15 Категорий' },
            { id: 'details', label: 'Детальный Разбор Выбранной' },
            { id: 'manifest', label: 'Анти-Терминал Манифест' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                playSound('click');
                setViewMode(tab.id as typeof viewMode);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase transition-all ${
                viewMode === tab.id
                  ? 'bg-cyan-400 text-black shadow-md'
                  : 'bg-white/5 text-slate-400 hover:bg-white/10 border border-white/5'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Main Viewport Content */}
        <div className="flex-1 overflow-y-auto pr-1 text-xs text-slate-300 space-y-2.5">
          {viewMode === 'matrix' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
              {AUDIT_15_CATEGORIES.map((cat) => (
                <div
                  key={cat.id}
                  onClick={() => {
                    playSound('click');
                    setSelectedCat(cat);
                    setViewMode('details');
                  }}
                  className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                    selectedCat.id === cat.id
                      ? 'bg-cyan-950/80 border-cyan-400 shadow-md ring-1 ring-cyan-400/50'
                      : 'bg-[#071420] border-white/5 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-mono text-cyan-300 font-bold">
                      #{cat.number < 10 ? `0${cat.number}` : cat.number}
                    </span>
                    <div className="flex items-center gap-1">
                      <span className="text-[9px] font-mono line-through text-slate-500">
                        {cat.scoreBefore}
                      </span>
                      <span className="text-xs font-mono font-black text-emerald-400">
                        → {cat.scoreAfter}
                      </span>
                    </div>
                  </div>

                  <h3 className="text-xs font-bold text-white leading-tight">
                    {cat.nameRu}
                  </h3>

                  <div className="mt-1.5 w-full bg-black/50 h-1.5 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-cyan-400 to-emerald-400 h-full"
                      style={{ width: `${cat.scoreAfter}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}

          {viewMode === 'details' && selectedCat && (
            <div className="space-y-3 animate-fadeIn">
              <div className="p-3 bg-[#0a1b2a] border border-cyan-500/40 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono text-cyan-400 uppercase">
                    Категория #{selectedCat.number}
                  </span>
                  <h3 className="text-sm sm:text-base font-black text-white uppercase mt-0.5">
                    {selectedCat.nameRu} ({selectedCat.nameEn})
                  </h3>
                </div>
                <div className="text-right font-mono">
                  <div className="text-[10px] text-slate-400">Итоговая оценка:</div>
                  <div className="text-xl font-black text-emerald-400">{selectedCat.scoreAfter} / 100</div>
                </div>
              </div>

              {/* Description & What was missing vs Added */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30 space-y-1">
                  <div className="text-[11px] font-black uppercase text-amber-300 flex items-center gap-1">
                    ⚠️ Что требовалось доработать (было {selectedCat.scoreBefore}/100)
                  </div>
                  <p className="text-slate-300 leading-relaxed text-xs">
                    {selectedCat.whatWasMissingRu}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 space-y-1">
                  <div className="text-[11px] font-black uppercase text-emerald-300 flex items-center gap-1">
                    ✅ Что внедрено в коде (стало {selectedCat.scoreAfter}/100)
                  </div>
                  <p className="text-slate-300 leading-relaxed text-xs">
                    {selectedCat.whatWasAddedRu}
                  </p>
                </div>
              </div>

              {/* Key Features Pill List */}
              <div>
                <span className="text-[10px] font-mono uppercase text-slate-400 font-bold">
                  Ключевые реализованные механики ({selectedCat.criteriaCount} параметров):
                </span>
                <div className="flex flex-wrap gap-1.5 mt-1.5">
                  {selectedCat.keyFeatures.map((feat, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg bg-cyan-950/70 border border-cyan-400/40 text-[11px] text-cyan-200 flex items-center gap-1 font-mono"
                    >
                      <CheckCircle2 size={12} className="text-emerald-400" />
                      {feat}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {viewMode === 'manifest' && (
            <div className="space-y-3 p-3 bg-black/40 rounded-xl border border-white/10 animate-fadeIn">
              <div className="flex items-center gap-2 text-amber-300">
                <Shield size={18} />
                <h3 className="text-sm font-black uppercase">Манифест Чистого Трейдинг-Тренажера</h3>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Большинство трейдинг-приложений страдают от «терминализации»: они дают график и кнопку «Купить/Продать», поощряя казино-поведение. <strong>SIGNAL ARENA</strong> меняет парадигму:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                <div className="p-2.5 bg-white/5 rounded-xl border border-white/5">
                  <strong className="text-cyan-300">1. Оценка Процесса</strong>
                  <p className="text-slate-400 mt-1 text-[11px]">DQI индекс замеряет сбор фактов и правила выхода, а не случайную прибыль.</p>
                </div>
                <div className="p-2.5 bg-white/5 rounded-xl border border-white/5">
                  <strong className="text-emerald-300">2. Карты вместо Ордеров</strong>
                  <p className="text-slate-400 mt-1 text-[11px]">Карты кодируют ментальные протоколы («Не усредняй убыток», «Пауза после стопа»).</p>
                </div>
                <div className="p-2.5 bg-white/5 rounded-xl border border-white/5">
                  <strong className="text-purple-300">3. Исторический Опыт</strong>
                  <p className="text-slate-400 mt-1 text-[11px]">Кризисы 2008, 2020 и 2022 годов учат сохранять капитал при любых шоках рынка.</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="pt-2.5 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1 text-[11px] font-mono text-cyan-300">
            <Sparkles size={13} className="text-amber-300" />
            <span>Все 15 категорий проверены и готовы к игре!</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleTestCategory('battler')}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-red-500 to-amber-400 text-black font-black text-xs uppercase flex items-center gap-1 hover:scale-105 active:scale-95 cursor-pointer shadow-md"
            >
              <Play size={12} className="fill-current" />
              <span>Тест Арены Боссов</span>
            </button>
            <button
              onClick={() => handleTestCategory('academy')}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-cyan-400 to-emerald-400 text-black font-black text-xs uppercase flex items-center gap-1 hover:scale-105 active:scale-95 cursor-pointer shadow-md"
            >
              <span>В Академию</span>
              <ArrowRight size={13} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
