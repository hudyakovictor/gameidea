import React, { useState } from 'react';
import { useGame } from '../../context/GameContext';
import { CardCategory, GameCard } from '../../types/game';
import { CardView } from '../common/CardView';
import {
  Layers,
  Sparkles,
} from 'lucide-react';

export const DeckScreen: React.FC = () => {
  const {
    inventoryCards,
    equippedDeck,
    equipCard,
    unequipCard,
    setInspectedCard,
    playSound,
  } = useGame();

  const [activeCategory, setActiveCategory] = useState<CardCategory | 'all'>('all');

  const filteredCards = inventoryCards.filter((card) =>
    activeCategory === 'all' ? true : card.category === activeCategory
  );

  const equippedCardsList = inventoryCards.filter((c) =>
    equippedDeck.includes(c.id)
  );

  // Deck Synergy Analysis calculation
  const protoCount = equippedCardsList.filter((c) => c.category === 'protocol').length;
  const decCount = equippedCardsList.filter((c) => c.category === 'decision').length;
  const readCount = equippedCardsList.filter((c) => c.category === 'reading').length;
  const defCount = equippedCardsList.filter((c) => c.category === 'defense').length;

  const synergyScore = Math.min(
    100,
    Math.round(
      (protoCount * 22 + decCount * 20 + readCount * 18 + defCount * 25) *
        (equippedCardsList.length / 6)
    )
  );

  const handleCardClick = (card: GameCard) => {
    playSound('click');
    setInspectedCard(card);
  };

  return (
    <div className="h-full flex flex-col justify-between overflow-y-auto p-3 sm:p-4 max-w-5xl mx-auto w-full select-none pb-2">
      {/* Top Deck Slots & Synergy Score Box */}
      <div className="bg-[#091522] border border-cyan-500/30 p-3 rounded-xl shadow-lg">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Layers size={18} className="text-cyan-300" />
            <h2 className="text-xs sm:text-sm font-black text-white uppercase">
              Боевая Колода Протоколов ({equippedDeck.length}/6 слотов)
            </h2>
          </div>

          <div className="flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-emerald-950/80 px-2.5 py-0.5 rounded border border-emerald-500/30">
            <Sparkles size={11} className="text-amber-300" />
            <span>Синергия Колоды: {synergyScore}%</span>
          </div>
        </div>

        {/* 6 Deck Slots */}
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {Array.from({ length: 6 }).map((_, idx) => {
            const card = equippedCardsList[idx];
            return (
              <div
                key={idx}
                onClick={() => card && unequipCard(card.id)}
                className={`min-h-[72px] rounded-xl border flex flex-col items-center justify-center p-1.5 transition-all cursor-pointer ${
                  card
                    ? 'bg-cyan-950/80 border-cyan-400/60 shadow-md hover:border-red-400 group'
                    : 'bg-black/40 border-dashed border-white/10 text-slate-600'
                }`}
              >
                {card ? (
                  <>
                    <span className="text-[9px] font-black uppercase text-cyan-300 truncate w-full text-center">
                      {card.nameRu}
                    </span>
                    <div className="flex items-center gap-1 text-[8px] text-slate-400 font-mono mt-0.5">
                      <span className="text-amber-300 font-bold">Ур. {card.level}</span>
                      <span>•</span>
                      <span className="text-emerald-300">+{card.clarityBonus} Ясн.</span>
                    </div>
                    <span className="text-[8px] text-red-400 opacity-0 group-hover:opacity-100 transition-opacity font-bold mt-0.5">
                      ✕ Снять
                    </span>
                  </>
                ) : (
                  <span className="text-[10px] font-mono font-bold text-slate-500">+ Слот {idx + 1}</span>
                )}
              </div>
            );
          })}
        </div>

        {/* Archetype Balance Indicator */}
        <div className="mt-2.5 pt-2 border-t border-white/10 flex items-center justify-between text-[10px] font-mono text-slate-400">
          <span className="text-purple-400">Протоколы: {protoCount}</span>
          <span className="text-emerald-400">Решения: {decCount}</span>
          <span className="text-cyan-400">Чтение: {readCount}</span>
          <span className="text-amber-400">Защита: {defCount}</span>
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto py-2">
        {(['all', 'protocol', 'decision', 'reading', 'defense'] as const).map((cat) => (
          <button
            key={cat}
            onClick={() => {
              playSound('click');
              setActiveCategory(cat);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase transition-all whitespace-nowrap ${
              activeCategory === cat
                ? 'bg-cyan-400 text-black shadow-md shadow-cyan-400/40'
                : 'bg-white/5 text-slate-400 hover:bg-white/10 border border-white/5'
            }`}
          >
            {cat === 'all'
              ? 'Все карты'
              : cat === 'protocol'
              ? 'Протоколы (Purple)'
              : cat === 'decision'
              ? 'Решения (Green)'
              : cat === 'reading'
              ? 'Чтение (Cyan)'
              : 'Защита (Gold)'}
          </button>
        ))}
      </div>

      {/* Cards Catalog Grid */}
      <div className="flex-1 overflow-y-auto pr-1">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {filteredCards.map((card) => {
            const isEquipped = equippedDeck.includes(card.id);
            return (
              <div key={card.id} className="relative">
                <CardView
                  card={card}
                  selected={isEquipped}
                  onClick={() => handleCardClick(card)}
                  onInspect={() => setInspectedCard(card)}
                />
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (isEquipped) unequipCard(card.id);
                    else equipCard(card.id);
                  }}
                  className={`absolute top-2 right-2 px-2 py-0.5 rounded text-[9px] font-black uppercase shadow-md transition-all ${
                    isEquipped
                      ? 'bg-emerald-400 text-black'
                      : 'bg-black/80 text-white border border-white/20 hover:bg-cyan-400 hover:text-black cursor-pointer'
                  }`}
                >
                  {isEquipped ? 'В колоде' : '+ Взять'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
