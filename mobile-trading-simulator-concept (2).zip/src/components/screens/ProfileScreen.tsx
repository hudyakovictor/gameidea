import React, { useState } from 'react';
import { useGame } from '../../context/GameContext';
import { PlayerStats } from '../../types/game';
import {
  Shield,
  Scale,
  LineChart,
  HeartHandshake,
  ArrowUpCircle,
  Sparkles,
  Award,
  Zap,
} from 'lucide-react';

export const ProfileScreen: React.FC = () => {
  const { playerStats, upgradeSkill, playSound } = useGame();
  const [activeTab, setActiveTab] = useState<'radar' | 'skills' | 'perks' | 'achievements'>('radar');

  type SkillKey = keyof Pick<
    PlayerStats,
    'analysis' | 'psychology' | 'strategy' | 'discipline' | 'riskManagement'
  >;

  const skillsConfig: {
    key: SkillKey;
    labelRu: string;
    icon: React.ElementType;
    color: string;
    descriptionRu: string;
    levelName: string;
  }[] = [
    {
      key: 'analysis',
      labelRu: 'Анализ Структуры & BOS',
      icon: LineChart,
      color: 'text-cyan-400',
      descriptionRu: 'Чтение сломов тренда, зон ликвидности и объемов аукциона.',
      levelName: 'Уровень 3 / 5',
    },
    {
      key: 'riskManagement',
      labelRu: 'Управление Рисками & R:R',
      icon: Scale,
      color: 'text-amber-400',
      descriptionRu: 'Математический расчет объема от стопа и сохранение депозита.',
      levelName: 'Уровень 2 / 5',
    },
    {
      key: 'discipline',
      labelRu: 'Дисциплина & Чек-листы',
      icon: Shield,
      color: 'text-emerald-400',
      descriptionRu: 'Железный самоконтроль: «Нет подтверждения — нет сделки».',
      levelName: 'Уровень 4 / 5',
    },
    {
      key: 'psychology',
      labelRu: 'Психология & Анти-Тильт',
      icon: HeartHandshake,
      color: 'text-purple-400',
      descriptionRu: 'Хладнокровие после убытков и иммунитет к зеленому FOMO.',
      levelName: 'Уровень 2 / 5',
    },
    {
      key: 'strategy',
      labelRu: 'Макроэкономика & Циклы',
      icon: Zap,
      color: 'text-blue-400',
      descriptionRu: 'Денежно-кредитная политика ФРС, инфляция и потоки ликвидности.',
      levelName: 'Уровень 2 / 5',
    },
  ];

  // Radar chart points coordinates calculation
  const values = [
    playerStats.analysis,
    playerStats.riskManagement,
    playerStats.discipline,
    playerStats.psychology,
    playerStats.strategy,
  ];

  // 5 vertices of pentagon in 200x200 viewBox (center at 100, 100, radius max 75)
  const angleStep = (Math.PI * 2) / 5;
  const getCoordinates = (value: number, index: number) => {
    const angle = index * angleStep - Math.PI / 2;
    const r = (value / 100) * 75;
    const x = 100 + r * Math.cos(angle);
    const y = 100 + r * Math.sin(angle);
    return `${x},${y}`;
  };

  const radarPolygonPoints = values.map((v, i) => getCoordinates(v, i)).join(' ');
  const gridLevel50Points = [50, 50, 50, 50, 50].map((v, i) => getCoordinates(v, i)).join(' ');
  const gridLevel100Points = [100, 100, 100, 100, 100].map((v, i) => getCoordinates(v, i)).join(' ');

  return (
    <div className="h-full flex flex-col justify-between overflow-y-auto p-3 sm:p-4 max-w-5xl mx-auto w-full select-none pb-2">
      {/* Profile Header */}
      <div className="bg-[#091522] border border-cyan-500/30 rounded-2xl p-3 sm:p-4 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3.5">
          <div className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 to-emerald-400 p-0.5 shadow-lg shadow-cyan-950/60">
            <div className="w-full h-full bg-[#06101c] rounded-2xl flex items-center justify-center font-black text-xl sm:text-2xl text-cyan-300">
              NT
            </div>
            <span className="absolute -bottom-1 -right-1 bg-amber-400 text-black font-black text-[10px] px-1.5 rounded-full border border-black">
              Ур. {playerStats.level}
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black text-white">NovaTrader</h2>
              <span className="text-[9px] sm:text-[10px] font-mono text-cyan-300 uppercase bg-cyan-950 px-2 py-0.5 rounded border border-cyan-500/30">
                Ученик Аналитика
              </span>
            </div>
            <div className="text-xs text-slate-400 font-mono mt-0.5">
              XP: {playerStats.xp} / {playerStats.nextLevelXp} • Золото: {playerStats.gold.toLocaleString()} 🪙
            </div>
            <div className="text-[11px] text-amber-300 font-mono mt-0.5 flex items-center gap-1 font-bold">
              <Sparkles size={12} /> DQI Профиля: {playerStats.decisionQualityAvg}% (Высокая дисциплина)
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 bg-black/50 p-1 rounded-xl border border-white/10 overflow-x-auto w-full sm:w-auto">
          {[
            { id: 'radar', label: 'Радар RPG' },
            { id: 'skills', label: 'Навыки' },
            { id: 'perks', label: 'Перки' },
            { id: 'achievements', label: 'Ачивки' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                playSound('click');
                setActiveTab(tab.id as typeof activeTab);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-cyan-400 text-black shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Tab Area */}
      <div className="my-2.5 flex-1 bg-[#06101c]/90 border border-white/10 rounded-2xl p-3 sm:p-4 overflow-y-auto shadow-inner">
        {activeTab === 'radar' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
            {/* Interactive SVG Radar Spider Chart */}
            <div className="flex flex-col items-center justify-center p-2 bg-black/40 rounded-xl border border-white/5">
              <div className="text-[10px] font-mono uppercase text-cyan-300 font-bold mb-1">
                Паутинная Диаграмма 5 Навыков
              </div>
              <svg className="w-56 h-56 sm:w-64 sm:h-64" viewBox="0 0 200 200">
                {/* 100% outer grid */}
                <polygon points={gridLevel100Points} fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="1" />
                {/* 50% inner grid */}
                <polygon points={gridLevel50Points} fill="none" stroke="rgba(105,231,223,0.15)" strokeWidth="1" strokeDasharray="3,3" />

                {/* Axes lines from center */}
                {Array.from({ length: 5 }).map((_, i) => {
                  const angle = i * angleStep - Math.PI / 2;
                  return (
                    <line
                      key={i}
                      x1="100"
                      y1="100"
                      x2={100 + 75 * Math.cos(angle)}
                      y2={100 + 75 * Math.sin(angle)}
                      stroke="rgba(255,255,255,0.1)"
                      strokeWidth="1"
                    />
                  );
                })}

                {/* Player Radar Polygon Area */}
                <polygon
                  points={radarPolygonPoints}
                  fill="rgba(105, 231, 223, 0.25)"
                  stroke="#69e7df"
                  strokeWidth="2.5"
                />

                {/* Node Points */}
                {values.map((val, i) => {
                  const angle = i * angleStep - Math.PI / 2;
                  const r = (val / 100) * 75;
                  return (
                    <circle
                      key={i}
                      cx={100 + r * Math.cos(angle)}
                      cy={100 + r * Math.sin(angle)}
                      r="4"
                      fill="#f59e0b"
                      stroke="#06101c"
                      strokeWidth="1.5"
                    />
                  );
                })}

                {/* Labels */}
                <text x="100" y="15" fill="#69e7df" fontSize="8" fontWeight="bold" textAnchor="middle">АНАЛИЗ ({playerStats.analysis})</text>
                <text x="185" y="75" fill="#f59e0b" fontSize="8" fontWeight="bold" textAnchor="start">РИСК ({playerStats.riskManagement})</text>
                <text x="155" y="190" fill="#10b981" fontSize="8" fontWeight="bold" textAnchor="middle">ДИСЦИПЛИНА ({playerStats.discipline})</text>
                <text x="45" y="190" fill="#a855f7" fontSize="8" fontWeight="bold" textAnchor="middle">ПСИХОЛОГИЯ ({playerStats.psychology})</text>
                <text x="15" y="75" fill="#38bdf8" fontSize="8" fontWeight="bold" textAnchor="end">СТРАТЕГИЯ ({playerStats.strategy})</text>
              </svg>
            </div>

            {/* RPG Stats Summary Breakdown */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-white uppercase flex items-center justify-between pb-1 border-b border-white/10">
                <span>Прокачка характеристик</span>
                <span className="text-[10px] text-amber-300 font-mono">500 🪙 за +5 пунктов</span>
              </div>

              {skillsConfig.map((skill) => {
                const val = playerStats[skill.key];
                return (
                  <div key={skill.key} className="p-2.5 rounded-xl bg-[#0a1724] border border-white/5 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        <span className={skill.color}>●</span>
                        <span>{skill.labelRu}</span>
                      </div>
                      <div className="text-[9px] text-slate-400 font-mono mt-0.5">{skill.levelName}</div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-mono font-black text-xs text-amber-300">{val}/100</span>
                      <button
                        disabled={playerStats.gold < 500 || val >= 100}
                        onClick={() => upgradeSkill(skill.key)}
                        className={`p-1.5 rounded-lg text-[10px] font-black uppercase flex items-center gap-1 ${
                          playerStats.gold >= 500 && val < 100
                            ? 'bg-amber-400 text-black hover:bg-amber-300 cursor-pointer shadow-sm'
                            : 'bg-white/5 text-slate-600 cursor-not-allowed'
                        }`}
                      >
                        <ArrowUpCircle size={13} />
                        <span>+5</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'skills' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {skillsConfig.map((skill) => {
              const value = playerStats[skill.key];
              const Icon = skill.icon;
              return (
                <div
                  key={skill.key}
                  className="p-3 rounded-xl bg-[#0a1726] border border-white/10 flex flex-col justify-between shadow-md"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Icon size={18} className={skill.color} />
                        <span className="text-xs font-bold text-white">{skill.labelRu}</span>
                      </div>
                      <span className="text-xs font-mono font-black text-amber-300">{value}/100</span>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1 leading-tight">{skill.descriptionRu}</p>
                    <div className="w-full bg-black/60 h-2 rounded-full mt-2 overflow-hidden border border-white/5">
                      <div className="bg-gradient-to-r from-cyan-400 to-emerald-400 h-full" style={{ width: `${value}%` }} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {activeTab === 'perks' && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {[
              { nameRu: 'Холодный Разум', descRu: 'Иммунитет к штрафу за серию из 2 убытков', status: 'Активен', icon: '❄️' },
              { nameRu: 'Щит Ликвидности', descRu: '+20% к поглощению урона новостных паник', status: 'Активен', icon: '🛡️' },
              { nameRu: 'Глаз Китов', descRu: 'Подсвечивает скрытые зоны стоп-лоссов на графиках', status: 'Ур. 15', icon: '👁️' },
            ].map((perk, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-[#081724] border border-cyan-500/30">
                <span className="text-2xl">{perk.icon}</span>
                <h4 className="text-xs font-black text-white mt-1">{perk.nameRu}</h4>
                <p className="text-[10px] text-slate-400 mt-0.5 leading-tight">{perk.descRu}</p>
                <span className="text-[9px] font-mono font-bold text-emerald-400 mt-2 inline-block bg-emerald-950 px-2 py-0.5 rounded">
                  {perk.status}
                </span>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'achievements' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {[
              { title: 'Стальные нервы', desc: 'Пропустил 10 ложных пробоев подряд', icon: Shield, unlocked: true },
              { title: 'Анти-Ликвидатор', desc: 'Победил Леверидж-Гоблина без потери капитала', icon: Zap, unlocked: true },
              { title: 'Мастер Контекста', desc: 'Получил 95+ DQI в 5 исторических кризисах', icon: Award, unlocked: true },
              { title: 'Хладнокровие 2008', desc: 'Выбрал кэш и хеджи в разгар паники Lehman', icon: Sparkles, unlocked: true },
            ].map((ach, idx) => {
              const Icon = ach.icon;
              return (
                <div
                  key={idx}
                  className={`p-3 rounded-xl border flex items-center gap-3 ${
                    ach.unlocked
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                      : 'bg-white/5 border-white/5 text-slate-500 opacity-50'
                  }`}
                >
                  <div className={`p-2.5 rounded-xl ${ach.unlocked ? 'bg-emerald-500/20 text-emerald-300' : 'bg-white/5 text-slate-600'}`}>
                    <Icon size={22} />
                  </div>
                  <div>
                    <div className="text-xs font-black text-white">{ach.title}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">{ach.desc}</div>
                    <span className="text-[9px] font-mono mt-1 inline-block text-emerald-400 font-bold">
                      ✅ Разблокировано
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
