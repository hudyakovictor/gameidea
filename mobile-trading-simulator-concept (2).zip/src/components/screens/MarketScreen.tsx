import React, { useState } from 'react';
import { useGame } from '../../context/GameContext';
import {
  ShoppingBag,
  Sparkles,
  Zap,
  Gem,
  Coins,
  Shield,
  Layers,
  Check,
  User,
  Flame,
} from 'lucide-react';

export interface ShopItem {
  id: string;
  nameRu: string;
  category: 'pack' | 'avatar' | 'booster' | 'energy';
  cost: number;
  currency: 'gold' | 'gems';
  descriptionRu: string;
  iconName: string;
  rarityRu: string;
  bonusRu: string;
}

const SHOP_ITEMS: ShopItem[] = [
  {
    id: 'pack-basic',
    nameRu: 'Набор Протоколов: Новичок',
    category: 'pack',
    cost: 1200,
    currency: 'gold',
    descriptionRu: 'Содержит 3 случайные карты навыков с гарантированной Редкой картой.',
    iconName: 'Layers',
    rarityRu: 'Редкий',
    bonusRu: '3 карты в коллекцию',
  },
  {
    id: 'pack-elite',
    nameRu: 'Архивный Пак: Магистр Риска',
    category: 'pack',
    cost: 350,
    currency: 'gems',
    descriptionRu: 'Содержит 5 карт с шансом выпадения Легендарного протокола «Сначала Риск».',
    iconName: 'Sparkles',
    rarityRu: 'Легендарный',
    bonusRu: '5 карт + 1 Эпическая',
  },
  {
    id: 'avatar-cyber-owl',
    nameRu: 'Аватар: Кибер-Сова Аналитик',
    category: 'avatar',
    cost: 2500,
    currency: 'gold',
    descriptionRu: 'Эксклюзивный неоновый аватар с голографическим моноклем для профиля и лиг.',
    iconName: 'User',
    rarityRu: 'Эпический',
    bonusRu: '+5% к получаемому XP',
  },
  {
    id: 'avatar-zen-master',
    nameRu: 'Аватар: Дзен-Стратег',
    category: 'avatar',
    cost: 500,
    currency: 'gems',
    descriptionRu: 'Особый аватар хладнокровного наставника. Открывает уникальную рамку в таблице лидеров.',
    iconName: 'Shield',
    rarityRu: 'Легендарный',
    bonusRu: '+10% к стойкости от тильта',
  },
  {
    id: 'booster-xp-double',
    nameRu: 'Нейро-Бустер Опыта (x2 XP)',
    category: 'booster',
    cost: 800,
    currency: 'gold',
    descriptionRu: 'Удваивает весь опыт за решение пазлов и победу над боссами на 24 часа.',
    iconName: 'Flame',
    rarityRu: 'Редкий',
    bonusRu: 'Действует 24 часа',
  },
  {
    id: 'energy-full-refill',
    nameRu: 'Энергетический Кристалл',
    category: 'energy',
    cost: 150,
    currency: 'gems',
    descriptionRu: 'Мгновенно восстанавливает 100% энергии решений для непрерывных тренировок.',
    iconName: 'Zap',
    rarityRu: 'Обычный',
    bonusRu: '+100 Энергии',
  },
];

export const MarketScreen: React.FC = () => {
  const { playerStats, playSound, recordScenarioResult } = useGame();
  const [activeFilter, setActiveFilter] = useState<'all' | 'pack' | 'avatar' | 'booster' | 'energy'>('all');
  const [boughtItems, setBoughtItems] = useState<string[]>([]);
  const [purchaseSuccessMessage, setPurchaseSuccessMessage] = useState<string | null>(null);

  const filteredItems = SHOP_ITEMS.filter((item) =>
    activeFilter === 'all' ? true : item.category === activeFilter
  );

  const handleBuy = (item: ShopItem) => {
    if (boughtItems.includes(item.id) && item.category === 'avatar') {
      playSound('error');
      return;
    }

    const canAfford =
      item.currency === 'gold'
        ? playerStats.gold >= item.cost
        : playerStats.gems >= item.cost;

    if (!canAfford) {
      playSound('error');
      setPurchaseSuccessMessage(`Недостаточно ${item.currency === 'gold' ? 'золота' : 'кристаллов'}!`);
      setTimeout(() => setPurchaseSuccessMessage(null), 2500);
      return;
    }

    playSound('success');
    setBoughtItems([...boughtItems, item.id]);

    if (item.category === 'pack') {
      recordScenarioResult(
        95,
        150,
        0,
        `Открытие пака: ${item.nameRu}`,
        [
          { labelRu: 'Приобрел архивный набор карт', isPositive: true },
          { labelRu: 'Пополнил тактический арсенал', isPositive: true },
        ],
        'proto-risk-first'
      );
    }

    setPurchaseSuccessMessage(`Успешно приобретено: ${item.nameRu}!`);
    setTimeout(() => setPurchaseSuccessMessage(null), 3000);
  };

  return (
    <div className="h-full flex flex-col justify-between overflow-y-auto p-3 sm:p-4 max-w-5xl mx-auto w-full select-none pb-2">
      {/* Top Banner: In-Game Ethical Store */}
      <div className="bg-gradient-to-r from-[#17210e] via-[#102418] to-[#0a1811] border border-emerald-500/40 rounded-2xl p-3 sm:p-4 shadow-xl flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-300 p-0.5 shadow-lg shadow-emerald-500/30 flex-shrink-0 flex items-center justify-center">
            <div className="w-full h-full bg-[#07140e] rounded-2xl flex items-center justify-center text-emerald-300">
              <ShoppingBag size={24} />
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30">
                Игровой Маркет (Play-to-Learn)
              </span>
              <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">
                0% реального доната
              </span>
            </div>
            <h2 className="text-sm sm:text-base font-black text-white uppercase mt-0.5">
              Арсенал Мышления & Бустеры
            </h2>
            <p className="text-xs text-slate-300">
              Покупайте паки карт, аватары и усиления за заработанные в сценариях монеты.
            </p>
          </div>
        </div>

        {/* Currency Display */}
        <div className="flex items-center gap-2 text-xs font-mono">
          <div className="bg-amber-950/80 border border-amber-500/40 px-2.5 py-1.5 rounded-xl flex items-center gap-1.5 text-amber-300 font-bold">
            <Coins size={14} />
            <span>{playerStats.gold.toLocaleString()}</span>
          </div>
          <div className="bg-purple-950/80 border border-purple-500/40 px-2.5 py-1.5 rounded-xl flex items-center gap-1.5 text-purple-300 font-bold">
            <Gem size={14} />
            <span>{playerStats.gems.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Notification Bar */}
      {purchaseSuccessMessage && (
        <div className="my-2 p-2.5 rounded-xl bg-emerald-950/90 border border-emerald-400 text-xs text-emerald-200 text-center font-bold animate-fadeIn">
          🎉 {purchaseSuccessMessage}
        </div>
      )}

      {/* Filters */}
      <div className="flex items-center gap-1.5 overflow-x-auto py-2">
        {[
          { id: 'all', label: 'Все товары' },
          { id: 'pack', label: 'Паки карт' },
          { id: 'avatar', label: 'Аватары' },
          { id: 'booster', label: 'Бустеры' },
          { id: 'energy', label: 'Энергия' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              playSound('click');
              setActiveFilter(tab.id as typeof activeFilter);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase transition-all whitespace-nowrap ${
              activeFilter === tab.id
                ? 'bg-emerald-400 text-black shadow-md shadow-emerald-400/30'
                : 'bg-white/5 text-slate-400 hover:bg-white/10 border border-white/5'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Shop Catalog Grid */}
      <div className="flex-1 overflow-y-auto pr-1">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
          {filteredItems.map((item) => {
            const isOwned = boughtItems.includes(item.id) && item.category === 'avatar';
            return (
              <div
                key={item.id}
                className="p-3.5 rounded-2xl bg-[#07161e] border border-white/10 hover:border-emerald-500/40 transition-all flex flex-col justify-between shadow-lg relative group"
              >
                <div>
                  {/* Top Badge: Rarity & Category */}
                  <div className="flex items-center justify-between mb-2">
                    <span
                      className={`text-[9px] font-black uppercase px-2 py-0.5 rounded font-mono border ${
                        item.rarityRu === 'Легендарный'
                          ? 'bg-amber-950 border-amber-500/40 text-amber-300'
                          : item.rarityRu === 'Эпический'
                          ? 'bg-purple-950 border-purple-500/40 text-purple-300'
                          : 'bg-cyan-950 border-cyan-500/40 text-cyan-300'
                      }`}
                    >
                      {item.rarityRu}
                    </span>
                    <span className="text-[10px] text-emerald-300 font-mono font-bold">
                      {item.bonusRu}
                    </span>
                  </div>

                  {/* Icon & Title */}
                  <div className="flex items-start gap-2.5 my-2">
                    <div className="p-2.5 rounded-xl bg-black/50 border border-white/10 text-emerald-300 group-hover:scale-110 transition-transform">
                      {item.iconName === 'Layers' && <Layers size={22} />}
                      {item.iconName === 'Sparkles' && <Sparkles size={22} />}
                      {item.iconName === 'User' && <User size={22} />}
                      {item.iconName === 'Shield' && <Shield size={22} />}
                      {item.iconName === 'Flame' && <Flame size={22} />}
                      {item.iconName === 'Zap' && <Zap size={22} />}
                    </div>
                    <div>
                      <h3 className="text-xs sm:text-sm font-black text-white leading-snug">
                        {item.nameRu}
                      </h3>
                      <p className="text-[10px] text-slate-400 mt-1 leading-tight">
                        {item.descriptionRu}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Price & Buy Button */}
                <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-1 font-mono font-black text-xs">
                    {item.currency === 'gold' ? (
                      <span className="text-amber-300 flex items-center gap-1">
                        <Coins size={14} /> {item.cost.toLocaleString()} 🪙
                      </span>
                    ) : (
                      <span className="text-purple-300 flex items-center gap-1">
                        <Gem size={14} /> {item.cost} 💎
                      </span>
                    )}
                  </div>

                  <button
                    disabled={isOwned}
                    onClick={() => handleBuy(item)}
                    className={`px-4 py-1.5 rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-1 transition-all ${
                      isOwned
                        ? 'bg-white/10 text-slate-500 cursor-not-allowed'
                        : 'bg-gradient-to-r from-emerald-400 to-teal-300 text-black hover:scale-105 active:scale-95 cursor-pointer shadow-md shadow-emerald-500/30'
                    }`}
                  >
                    {isOwned ? (
                      <>
                        <Check size={13} />
                        <span>Куплено</span>
                      </>
                    ) : (
                      <span>Купить</span>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
