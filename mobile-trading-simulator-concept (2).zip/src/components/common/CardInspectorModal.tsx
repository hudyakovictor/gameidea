import React from 'react';
import { GameCard } from '../../types/game';
import {
  X,
  ShieldCheck,
  Zap,
  Scale,
  Sparkles,
  ArrowUpCircle,
} from 'lucide-react';
import { useGame } from '../../context/GameContext';

interface CardInspectorModalProps {
  card: GameCard | null;
  onClose: () => void;
}

export const CardInspectorModal: React.FC<CardInspectorModalProps> = ({
  card,
  onClose,
}) => {
  const { equipCard, unequipCard, equippedDeck, upgradeCard, playerStats, playSound } = useGame();

  if (!card) return null;

  const isEquipped = equippedDeck.includes(card.id);

  const handleEquipToggle = () => {
    playSound('click');
    if (isEquipped) unequipCard(card.id);
    else equipCard(card.id);
  };

  const handleUpgrade = () => {
    upgradeCard(card.id);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 animate-fadeIn select-none">
      <div className="bg-[#091522] border border-cyan-400/50 rounded-2xl max-w-sm w-full p-4 sm:p-5 shadow-2xl relative overflow-hidden">
        {/* Top Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 p-1 rounded-lg bg-white/5 text-slate-400 hover:text-white border border-white/10"
        >
          <X size={16} />
        </button>

        {/* Card Header & Rarity Badge */}
        <div className="flex items-center gap-2 mb-2">
          <span
            className={`text-[9px] font-black uppercase px-2 py-0.5 rounded font-mono border ${
              card.rarity === 'legendary'
                ? 'bg-amber-950 border-amber-500/40 text-amber-300'
                : card.rarity === 'epic'
                ? 'bg-purple-950 border-purple-500/40 text-purple-300'
                : 'bg-cyan-950 border-cyan-500/40 text-cyan-300'
            }`}
          >
            {card.category.toUpperCase()} • {card.rarity.toUpperCase()}
          </span>
          <span className="text-[10px] font-mono text-amber-300 flex items-center gap-0.5">
            <Zap size={11} className="fill-amber-300" /> {card.cost} Энергии
          </span>
        </div>

        {/* Title */}
        <h2 className="text-base font-black text-white uppercase leading-tight">
          {card.nameRu}
        </h2>
        <p className="text-[10px] font-mono text-slate-400">{card.name}</p>

        {/* Card Lore Quote */}
        <div className="my-3 p-3 bg-black/50 border border-white/10 rounded-xl text-xs text-slate-300 italic leading-relaxed font-serif">
          «{card.loreRu}»
        </div>

        {/* Card Stat Modifiers */}
        <div className="space-y-1.5 bg-[#050e18] p-3 rounded-xl border border-white/5 text-xs font-mono mb-4">
          <div className="flex items-center justify-between text-slate-300">
            <span className="flex items-center gap-1">
              <Sparkles size={12} className="text-cyan-400" /> Бонус к Ясности:
            </span>
            <strong className="text-cyan-300 font-bold">+{card.clarityBonus}</strong>
          </div>
          <div className="flex items-center justify-between text-slate-300">
            <span className="flex items-center gap-1">
              <ShieldCheck size={12} className="text-emerald-400" /> Щит от Шума:
            </span>
            <strong className="text-emerald-300 font-bold">+{card.noiseShield}</strong>
          </div>
          <div className="flex items-center justify-between text-slate-300">
            <span className="flex items-center gap-1">
              <Scale size={12} className="text-amber-400" /> Снижение Риска:
            </span>
            <strong className="text-amber-300 font-bold">+{card.riskReduction}%</strong>
          </div>
          <div className="flex items-center justify-between text-slate-300 pt-1 border-t border-white/10">
            <span>Уровень карты:</span>
            <span className="text-amber-400 font-bold">
              {card.level} / {card.maxLevel}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            disabled={card.level >= card.maxLevel || playerStats.gold < 750}
            onClick={handleUpgrade}
            className={`flex-1 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-md ${
              card.level < card.maxLevel && playerStats.gold >= 750
                ? 'bg-amber-400 text-black hover:scale-105 active:scale-95 cursor-pointer'
                : 'bg-white/10 text-slate-500 cursor-not-allowed'
            }`}
          >
            <ArrowUpCircle size={14} />
            <span>Прокачать (750 🪙)</span>
          </button>

          <button
            onClick={handleEquipToggle}
            className={`px-4 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all ${
              isEquipped
                ? 'bg-red-950/80 border border-red-500/40 text-red-300 hover:bg-red-900/80'
                : 'bg-emerald-400 text-black hover:scale-105'
            }`}
          >
            {isEquipped ? 'Снять' : 'В бой'}
          </button>
        </div>
      </div>
    </div>
  );
};
